export const environment = {
  production: true,
  oktaClientId: 'XXXXXXXXXXXXXXX',
  oktaIssuer: 'https://dev-demo.okta.com/oauth2/default',
  oktaRedirectUri: window.location.origin,
};
