import { BrowserModule } from '@angular/platform-browser';
import {
  CUSTOM_ELEMENTS_SCHEMA,
  InjectionToken,
  NgModule,
  NO_ERRORS_SCHEMA,
  ɵINJECTOR_IMPL__POST_R3__,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrganisationComponent } from './organisation/organisation.component';

import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { MenuComponent } from './_shared/menu/menu.component';
import { EventguideComponent } from './eventguide/eventguide.component';
import { ErrormessagemnmgtComponent } from './errormessagemnmgt/errormessagemnmgt.component';
//export let APP_CONFIG=new InjectionToken<AppConfig>('app.config');
import {
  HttpClient,
  HttpClientModule,
  HTTP_INTERCEPTORS,
} from '@angular/common/http';
import { UsersComponent } from './user-management/users/users.component';
import { OAuthModule } from 'angular-oauth2-oidc';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { CodeManagementComponent } from './code-management/code-management/code-management.component';
import { NotificationManagementComponent } from './notification-management/notification-management.component';
import { EditorModule } from 'primeng/editor';
import { InputSwitchModule } from 'primeng/inputswitch';
import { FileUploadModule } from 'primeng/fileupload';
import { NgRxModule } from './store/ngrx.module';
import { InputTextModule } from 'primeng/inputtext';
import { AccessManagementComponent } from './access-management/access-management/access-management.component';
import { ProductManagementComponent } from './product-management/product-management.component';
import { MenuManagementComponent } from './menu-management/menu-management.component';
import { AuthManagementComponent } from './auth-management/auth-management.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { ValueSettingsComponent } from './value-settings/value-settings.component';
import { HomepageComponent } from './homepage/homepage.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import { CalendarModule } from 'primeng/calendar';
import { NotificationComponent } from './notification/notification.component';
import { DropdownModule } from 'primeng/dropdown';
import { MarketingAdminComponent } from './marketing-admin/marketing-admin.component';
import { ConferenceDetailsComponent } from './conference-details/conference-details.component';
import { ChangeRequestView } from './changerequestview/changerequestview.component';
import { ViewChangeRequest } from './viewchangerequest/viewchangerequest.component';
import { ChangeRequestApproval } from './changerequestapproval/changerequestapproval.component';
import { ViewChangeRequestApproval } from './viewchangerequestapproval/viewchangerequestapproval.component';
import { DatePipe } from '@angular/common';
import { DndDirective } from './directives/dnd.directive';
import { ProgessBarComponent } from './progress/progess-bar/progess-bar.component';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { DragDropModule } from 'primeng/dragdrop';
import { NgxPrintModule } from 'ngx-print';
import { CardModule } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { ToastModule } from 'primeng/toast';
import { MenuModule } from 'primeng/menu';
import { ConditionalSearchComponent } from './conditionalsearch/conditionalsearch.component';
import { CheckboxModule } from 'primeng/checkbox';
import { KRPIAReportComponent } from './KRPIA_report/krpia_report.component';
import { OtherEventsComponent } from './other_events/otherevents.component';
import { ViewOtherEventsComponent } from './view-other-events/view-other-events.component';
import { PmEventsComponent } from './pm-events/pm-events.component';
import { LoginComponent } from './login/login.component';
import { LoaderComponent } from './loader/loader.component';
import { LoaderInterceptor } from './interceptors/loader.interceptor';
import { PmConferenceDetailsComponent } from './pm-conference-details/pm-conference-details.component';
import { CrViewComponent } from './cr-view/cr-view.component';
import { ChangeRequestApprovalViewComponent } from './change-request-approval-view/change-request-approval-view.component';
import { EventSearchComponent } from './event-search/event-search.component';
import { EventSearchViewComponent } from './event-search-view/event-search-view.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    OrganisationComponent,
    MenuComponent,
    EventguideComponent,
    ErrormessagemnmgtComponent,
    UsersComponent,
    CodeManagementComponent,
    NotificationManagementComponent,
    AccessManagementComponent,
    ProductManagementComponent,
    MenuManagementComponent,
    AuthManagementComponent,
    AccessDeniedComponent,
    UserRegisterComponent,
    ValueSettingsComponent,
    HomepageComponent,
    NotificationComponent,
    MarketingAdminComponent,
    ConferenceDetailsComponent,
    DndDirective,
    ProgessBarComponent,
    ChangeRequestView,
    ViewChangeRequest,
    ChangeRequestApproval,
    ViewChangeRequestApproval,
    ConditionalSearchComponent,
    KRPIAReportComponent,
    OtherEventsComponent,
    ViewOtherEventsComponent,
    PmEventsComponent,
    LoginComponent,
    LoaderComponent,
    PmConferenceDetailsComponent,
    CrViewComponent,
    ChangeRequestApprovalViewComponent,
    EventSearchComponent,
    EventSearchViewComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    TableModule,
    ButtonModule,
    DialogModule,
    BrowserAnimationsModule,
    HttpClientModule,
    OAuthModule.forRoot(),
    ProgressSpinnerModule,
    EditorModule,
    InputSwitchModule,
    FileUploadModule,
    NgRxModule,
    InputTextModule,
    FullCalendarModule,
    CalendarModule,
    AutoCompleteModule,
    MultiSelectModule,
    DropdownModule,
    DragDropModule,
    NgxPrintModule,
    CardModule,
    PanelModule,
    ToastModule,
    MenuModule,
    CheckboxModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
  ],
  providers: [
    DatePipe,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
  ],

  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
})
export class AppModule {}
