import { Component, OnInit } from '@angular/core';
import { organisation } from './../_models/index';
import { OrganisationService } from './../_services/organisation.service';
import { SortEvent } from 'primeng/api';

@Component({
  selector: 'app-organisation',
  templateUrl: './organisation.component.html',
  styleUrls: ['./organisation.component.scss'],
})
export class OrganisationComponent implements OnInit {
  status = [
    { name: "Active" },
    { name: "Inactive" },
  ];
  orgData: organisation[] = [];
  organisation: organisation = <organisation>{};
  display: boolean = false;
  serachAll = true;
  searchBy: string;
  orgTypes: any = [];
  constructor(private orgService: OrganisationService) {}

  ngOnInit(): void {
    this.loadOrganisation();
    this.loadcodeWithGroup();
  }
  loadcodeWithGroup() {
    this.orgService.getcodeWithGroup(7).then((result) => {
      this.orgTypes = result;
      this.orgTypes = this.orgTypes.filter((item)=>item.status)
    });
  }
  loadOrganisation() {
    this.orgService.getOrgData().then((result) => {
      this.orgData = result;
      this.orgTypes = this.orgTypes.filter((item)=>item.status)
    });
  }
  customSort(event: SortEvent) {
    event.data.sort((data1, data2) => {
      let value1 = data1[event.field];
      let value2 = data2[event.field];
      let result = null;

      if (value1 == null && value2 != null) result = -1;
      else if (value1 != null && value2 == null) result = 1;
      else if (value1 == null && value2 == null) result = 0;
      else if (typeof value1 === 'string' && typeof value2 === 'string')
        result = value1.localeCompare(value2);
      else result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;

      return event.order * result;
    });
  }
  showDialog(id: number) {
    if (id > 0) {
      this.organisation = this.orgData.find((fl) => fl.id === id);
    } else {
      this.organisation.id = 0;
      this.organisation.organizationName = '';
      this.organisation.organizationTypeId = 0;
      this.organisation.remarks = '';
      this.organisation.status = true;
    }
    this.display = true;
  }
  async saveorg(org: organisation) {
    if (org.organizationName == '') {
      alert('Organisation Name Required');
      return;
    } else if (org.organizationTypeId == 0) {
      alert('Please select Organisation type');
      return;
    } else if (org.remarks == '') {
      alert('Remarks Name Required');
      return;
    }

    if (org.id > 0) {
      //update
      await this.orgService.updateOrgData(org);
      this.loadOrganisation();
      this.display = false;
    } else {
      //save
      await this.orgService.saveOrgData(org);
      this.loadOrganisation();
      this.display = false;
    }
  }
  changeActivity(value: boolean) {}

  searchclick(val: string) {
    if (val == 'orgname') {
      this.serachAll = false;
      this.searchBy = 'orgname';
    } else if (val == 'remarks') {
      this.serachAll = false;
      this.searchBy = 'remarks';
    }
  }
  close() {
    this.loadOrganisation();
  }
}
