import { MenuItem } from 'primeng/api';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { State, Store } from '../store';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import {
  addCR,
  Advertisement,
  Banner,
  bannerCR,
  Booth,
  boothCR,
  conference,
  conferenceCR,
  OnlineAdd,
} from '../_models';
import { ConferenceService } from '../_services/conference.service';
import { EventGuideService } from '../_services/eventguide.service';
import { OrganisationService } from '../_services/organisation.service';
import { Product } from '../_services/products/product.service';
import { User, UserService } from '../_services/users/user.service';
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { APP_DI_CONFIG } from '../app-config.modules';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

export interface Car {
  existingdata;
  newdata;
  guidelines;
}

@Component({
  selector: 'app-viewchangerequest',
  templateUrl: './viewchangerequest.component.html',
  styleUrls: ['./viewchangerequest.component.scss'],
})
export class ViewChangeRequest implements OnInit {
  displayBasic: boolean;
  collapsed = false;
  cars = [{}];
  conference: any = {};
  conferencenew: conferenceCR = <conferenceCR>{};
  boothnew: boothCR = <boothCR>{};
  bannernew: bannerCR = <bannerCR>{};
  advertisementnew: addCR = <addCR>{};
  guidelines: any = [];
  products: Product[] = [];
  displayBooth: boolean = false;
  displayBanner: boolean = false;
  displayOnlineAdd: boolean = false;
  displayAdd: boolean = false;
  isSaveBtn: boolean = false;
  displayDelete: boolean = false;
  displayConferenceRemark: boolean = false;
  onlineAdd: OnlineAdd = <OnlineAdd>{};
  booth: Booth = <Booth>{};
  banner: Banner = <Banner>{};
  advertisement: addCR = <addCR>{};
  verifedData: any = [];
  usersAll: any;
  addTypes: any = [];
  users: User[] = [];
  today: any = new Date();
  displayRegister: boolean = false;
  progress: number;
  cities: any = [];
  displayViewBooth: boolean = false;
  displayViewBanner: boolean = false;
  displayViewAdd: boolean = false;
  displayErrorModel: boolean = false;
  filePath: any;
  selectedcategory: any;
  responseRemark: any;
  deleteFlag: any;
  errorData: any = [];
  deleteConferenceParams: any;
  @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;
  files: any[] = [];
  orgData: any[] = [];
  reason: any;
  constructor(
    private route: ActivatedRoute,
    private conferenceService: ConferenceService,
    private orgService: OrganisationService,
    private store: Store<State>,
    private router: Router,
    public datepipe: DatePipe,
    private userService: UserService,
    private http: HttpClient,
    private eventGuideService: EventGuideService
  ) {}

  onClick(event: Event, menu) {
    menu.toggle(event);
    event.stopPropagation();
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.conferenceService.getCRConferenceDetails(id).then((data) => {
      this.conference = data;
      this.loadcodeWithGuildelines();
      this.loadProductsData();
      this.loadUsersData();
      this.loadAddTypes();
      this.loadcodeWithCities();
      this.loadOrganisation();
      this.conferencenew.crOrganizationId = 0;
      this.conferencenew.crCityId = 0;
    });
  }
  showBasicDialog(remark) {
    this.displayBasic = true;
    this.responseRemark = remark;
  }

  close() {
    // this.loadOrganisation();
  }
  onlineAddModel() {
    this.reason = '';
    if (this.conference.onlineAdvertisement.length > 0) {
      this.conferenceService
        .validateOnlineAddCreation(this.route.snapshot.paramMap.get('id'))
        .then((data) => {
          this.errorData = data;
          if (this.errorData.length > 0) {
            this.displayErrorModel = true;
          } else {
            this.displayOnlineAdd = true;
            this.onlineAdd.id = 0;
            this.onlineAdd.productId = 0;
            this.onlineAdd.userId = 0;
          }
        });
    }
  }
  loadOrganisation() {
    this.orgService.getOrgData().then((result) => {
      this.orgData = result;
    });
  }
  loadConferenceData() {
    const id = this.route.snapshot.paramMap.get('id');
    this.conferenceService.getCRConferenceDetails(id).then((data) => {
      this.conference = data;
    });
  }
  loadcodeWithCities() {
    this.orgService.getcodeWithGroup(9).then((result) => {
      this.cities = result;
    });
  }
  loadAddTypes() {
    this.conferenceService.getAddTypesData().then((data) => {
      this.addTypes = data;
    });
  }
  loadUsersData() {
    this.conferenceService.getUserData().then((data) => {
      this.usersAll = data;
      this.users = this.usersAll.users;
      this.users = this.users.filter((item)=> item.roleName==='PM')

    });
  }

  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
      this.products = this.products.filter((item) => item.status);
    });
  }
  loadcodeWithGuildelines() {
    this.eventGuideService.geteventData().then((result) => {
      this.guidelines = result;
    });
  }

  onFileDropped($event) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile(index: number) {
    this.files = [];
  }

  /**
   * Simulate the upload process
   */
  uploadFile(type: any, id) {
    this.progress = 10;
    const formData = new FormData();
    formData.append('file', this.files[0]);
    let path = '';
    if (type == 'conference') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadFileConference +
        '?id=' +
        id;
    } else if (type == 'booth') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadBoothFile +
        '?id=' +
        id;
    } else if (type == 'banner') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadBannerFile +
        '?id=' +
        id;
    } else if (type == 'add') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadAdvertisementFile +
        '?id=' +
        id;
    }

    this.http
      .put(path, formData, {
        reportProgress: true,
        observe: 'events',
      })
      .pipe(
        map((event: any) => {
          if (event.type == HttpEventType.UploadProgress) {
            this.progress = Math.round((100 / event.total) * event.loaded);
          } else if (event.type == HttpEventType.Response) {
            this.files = [];
            this.progress = null;
          }
        }),
        catchError((err: any) => {
          alert(err.message);
          return throwError(err.message);
        })
      )
      .toPromise();
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      item.progress = 0;

      this.files[0] = item;
    }
    this.fileDropEl.nativeElement.value = '';
    //  this.uploadFilesSimulator(0);
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  boothModel() {
    this.reason = '';
    this.conferenceService
      .validateBoothCreation(this.route.snapshot.paramMap.get('id'))
      .then((data) => {
        this.errorData = data;
        if (this.errorData.length > 0 && this.conference.booths.length > 0) {
          this.displayErrorModel = true;
        } else {
          this.displayBooth = true;
          this.booth.id = 0;
          this.booth.productId = 0;
          this.booth.userId = 0;
        }
      });
  }
  bannerModel() {
    this.reason = '';
    if (this.conference.banners.length > 0) {
      this.displayBanner = true;
      this.banner.productId = 0;
      this.banner.userId = 0;
      this.banner.id = 0;
    }
  }
  addModel() {
    this.reason = '';
    if (this.conference.advertisements.length > 0) {
      this.displayAdd = true;
      this.advertisement.id = 0;
      this.advertisement.productId = 0;
      this.advertisement.userId = 0;
      this.advertisement.adTypeId = 0;
    }
  }
  saveOnlineAdd() {
    this.displayConferenceRemark = true;
  }
  saveOnlineAddData() {
    this.conferenceService.validateOnlineAdd(this.onlineAdd).then((data) => {
      this.errorData = data;
      if (this.errorData.length > 0) {
        this.displayErrorModel = true;
      } else {
        this.conferenceService
          .createOnlineAddCR(this.onlineAdd)
          .then((data) => {
            if (this.files.length > 0) {
              this.uploadFile('onlineAdd', data.id);
            }
            this.loadConferenceData();
            this.displayOnlineAdd = false;
            this.displayConferenceRemark = false;
          });
      }
    });
  }
  saveBooth() {
    this.displayConferenceRemark = true;
  }
  saveBoothData() {
    this.conferenceService.validateBooth(this.booth).then((data) => {
      this.errorData = data;
      if (this.errorData.length > 0) {
        this.displayErrorModel = true;
      } else {
        this.conferenceService.createBoothCR(this.booth).then((data) => {
          if (this.files.length > 0) {
            this.uploadFile('booth', data.id);
          }
          this.loadConferenceData();
          this.displayBooth = false;
          this.displayConferenceRemark = false;
        });
      }
    });
  }
  updateBoothData() {
    this.conferenceService.updateBoothData(this.booth).then((data) => {
      this.displayBooth = false;
      if (this.files.length > 0) {
        this.uploadFile('booth', this.booth.id);
      }
      this.loadConferenceData();
      this.displayConferenceRemark = false;
    });
  }
  verify() {
    this.banner.conferenceId = this.route.snapshot.paramMap.get('id')
    this.conferenceService.validateBanner(this.banner).then((data) => {
      this.verifedData = data;
      const arrayLength = this.verifedData.filter(
        (item) => !item.result
      ).length;
      if (arrayLength > 0) {
        this.isSaveBtn = false;
      } else {
        this.isSaveBtn = true;
      }
    });
  }
  saveBanner() {
    this.displayConferenceRemark = true;
  }
  saveBannerData() {
    this.banner['crId'] = this.conference.conferenceDetail.crId;
    this.conferenceService.createBannerCR(this.banner).then((data) => {
      if (this.files.length > 0) {
        this.uploadFile('banner', data.id);
      }
      this.loadConferenceData();
      this.displayBanner = false;
      this.displayConferenceRemark = false;
    });
  }
  updateBannerData() {
    this.conferenceService.updateBannerData(this.banner).then((data) => {
      this.displayBanner = false;
      if (this.files.length > 0) {
        this.uploadFile('banner', this.banner.id);
      }
      this.loadConferenceData();
      this.displayConferenceRemark = false;
    });
  }

  saveAdd() {
    // this.advertisement.crConferenceId = this.route.snapshot.paramMap.get('id');
    this.displayConferenceRemark = true;
  }
  saveAddData() {
    this.conferenceService
      .validateAdvertisement(this.advertisement)
      .then((data) => {
        this.errorData = data;
        if (this.errorData.length > 0) {
          this.displayErrorModel = true;
        } else {
          this.conferenceService.createaddCR(this.advertisement).then((data) => {
            if (this.files.length > 0) {
              this.uploadFile('add', data.id);
            }
            this.loadConferenceData();
            this.displayAdd = false;
            this.displayConferenceRemark = false;
          });
        }
      });
   
  }
  updateAddData() {
    this.conferenceService.updateaddCR(this.advertisement).then((data) => {
      this.displayAdd = false;
      if (this.files.length > 0) {
        this.uploadFile('add', this.advertisement.id);
      }
      this.loadConferenceData();
      this.displayConferenceRemark = false;
    });
  }
  cancel() {
    this.displayDelete = false;
  }
  deleteCR() {
    if (this.deleteFlag === 'conference') {
      this.deleteConferenceParams['remark'] = this.reason;
      this.conferenceService
        .deleteConferenceCR(this.deleteConferenceParams)
        .then((data) => {
          this.displayDelete = false;
          this.loadConferenceData();
        });
    } else if (this.deleteFlag === 'booth') {
      this.deleteConferenceParams['remark'] = this.reason;
      this.conferenceService
        .deleteBoothCR(this.deleteConferenceParams)
        .then((data) => {
          this.displayDelete = false;
          this.loadConferenceData();
        });
    } else if (this.deleteFlag === 'banner') {
      this.deleteConferenceParams['remark'] = this.reason;
      this.conferenceService
        .deleteBannerCR(this.deleteConferenceParams)
        .then((data) => {
          this.displayDelete = false;
          this.loadConferenceData();
        });
    } else if (this.deleteFlag === 'add') {
      this.deleteConferenceParams['remark'] = this.reason;
      this.conferenceService
        .deleteAddCR(this.deleteConferenceParams)
        .then((data) => {
          this.displayDelete = false;
          this.loadConferenceData();
        });
    } else {
      this.deleteConferenceParams['remark'] = this.reason;
      this.conferenceService
        .deleteOnlineAddCR(this.deleteConferenceParams)
        .then((data) => {
          this.displayDelete = false;
          this.loadConferenceData();
        });
    }
  }
  approveBanner(id) {
    let params = {
      id: id,
      approverRemark: this.reason,
    };
    this.conferenceService.approveCRBanner(params).then((data) => {});
  }
  rejectBanner() {}
  aapproveBooth(id) {
    let params = {
      id: id,
      approverRemark: this.reason,
    };
    this.conferenceService.aapproveCRBooth(params).then((data) => {});
  }
  rejecteBooth() {}
  approveAdd(id) {
    let params = {
      id: id,
      approverRemark: this.reason,
    };
    this.conferenceService.approveCRAdd(params).then((data) => {});
  }
  rejectAdd() {}
  deleteConferenceModel(data: any) {
    this.deleteFlag = 'conference';
    let obj = {
      conferenceId: data.conferenceId,
      confDetailId: data.id,
    };
    this.deleteConferenceParams = obj;
    this.displayDelete = true;
  }
  deleteBootCR(data: any) {
    this.deleteFlag = 'booth';
    let obj = {
      conferenceId: data.conferenceId,
      boothId: data.id,
    };
    this.deleteConferenceParams = obj;
    this.displayDelete = true;
  }
  deleteAddCR(data: any) {
    this.deleteFlag = 'add';
    let obj = {
      conferenceId: data.conferenceId,
      boothId: data.id,
    };
    this.deleteConferenceParams = obj;
    this.displayDelete = true;
  }
  deleteOnlineAddCR(data: any) {
    this.deleteFlag = 'onlineadd';
    let obj = {
      conferenceId: data.conferenceId,
      boothId: data.id,
    };
    this.deleteConferenceParams = obj;
    this.displayDelete = true;
  }
  deleteBannerCR(data: any) {
    this.deleteFlag = 'banner';
    let obj = {
      conferenceId: data.conferenceId,
      boothId: data.id,
    };
    this.deleteConferenceParams = obj;
    this.displayDelete = true;
  }
  submittCR() {
    this.conferenceService
      .submittCR(this.conference.conferenceDetail.crId)
      .then((data) => {
        this.router.navigateByUrl('/home/marketing-admin');
      });
  }
  confirmBooth() {
    if (this.displayBanner) {
      this.banner.conferenceId = this.route.snapshot.paramMap.get('id');
      this.banner['remark'] = this.reason;
      if (this.banner.id > 0) {
        if (this.banner.actualAmount == 0) {
          alert('Enster Actual Amount');
        } else if (!this.banner.actualPaymentDate) {
          alert('Select Actual Pay Date');
        } else if (!this.banner.ePay) {
          alert('Enster E-pay code');
        } else {
          this.updateBannerData();
        }
      } else {
        if (this.banner.productId == 0) {
          alert('Select a Product');
        } else if (!this.banner.urlOfSite) {
          alert('Enter URL of site');
        } else if (!this.banner.startDate) {
          alert('Select Start Date');
        } else if (!this.banner.endDate) {
          alert('Select End Date');
        } else if (!this.banner.expectedPaymentDate) {
          alert('Select Expected Pay Date');
        } else if (!this.banner.expectedAmount) {
          alert('Enter Expected Amount');
        } else if (this.banner.userId === 0) {
          alert('Select PM User');
        } else {
          this.saveBannerData();
        }
      }
    } else if (this.displayBooth) {
      this.booth.conferenceId = this.route.snapshot.paramMap.get('id');
      this.booth['remark'] = this.reason;
      if (this.booth.id > 0) {
        if (this.booth.actualAmount == 0) {
          alert('Enster Actual Amount');
        } else if (!this.booth.actualPaymentDate) {
          alert('Select Actual Pay Date');
        } else if (!this.booth.ePay) {
          alert('Enster E-pay code');
        } else {
          this.updateBoothData();
        }
      } else {
        if (this.booth.productId == 0) {
          alert('Select a Product');
        } else if (!this.booth.expectedAmount) {
          alert('Enter Expected Amount');
        } else if (!this.booth.expectedPaymentDate) {
          alert('Select Expected Pay Date');
        } else if (this.booth.userId === 0) {
          alert('Select PM User');
        } else {
          this.saveBoothData();
        }
      }
    } else if (this.displayAdd) {
      this.advertisement.conferenceId = this.route.snapshot.paramMap.get('id');
      this.advertisement['remark'] = this.reason;
      if (this.advertisement.id > 0) {
        if (this.advertisement.actualAmount == 0) {
          alert('Enster Actual Amount');
        } else if (!this.advertisement.actualPaymentDate) {
          alert('Select Actual Pay Date');
        } else if (!this.advertisement.ePayCode) {
          alert('Enster E-pay code');
        } else {
          this.updateAddData();
        }
      } else {
        this.advertisement.ePayCode = 'NA';
        if (this.advertisement.productId == 0) {
          alert('Select a Product');
        } else if (!this.advertisement.expectedAmount) {
          alert('Enter Expected Amount');
        } else if (!this.advertisement.expectedPaymentDate) {
          alert('Select Expected Pay Date');
        } else if (this.advertisement.userId === 0) {
          alert('Select PM User');
        } else {
          this.saveAddData();
        }
      }
    } else {
      this.onlineAdd.conferenceId = this.route.snapshot.paramMap.get('id');
      if (this.onlineAdd.id > 0) {
        if (
          this.onlineAdd.actualAmount == 0 ||
          this.onlineAdd.actualAmount == null
        ) {
          alert('Enter Actual Amount');
        } else if (
          !this.onlineAdd.actualPaymentDate ||
          this.onlineAdd.actualPaymentDate === '0001-01-01T00:00:00'
        ) {
          alert('Select Actual Pay Date');
        } else if (!this.onlineAdd.ePay) {
          alert('Enter E-pay code');
        } else {
          //this.updateOnlineAdd();
        }
      } else {
        if (this.onlineAdd.productId == 0) {
          alert('Select a Product');
        } else if (!this.onlineAdd.expectedAmount) {
          alert('Enter Expected Amount');
        } else if (!this.onlineAdd.expectedPaymentDate) {
          alert('Select Expected Pay Date');
        } else if (this.onlineAdd.userId === 0) {
          alert('Select PM User');
        } else {
          this.saveOnlineAddData();
        }
      }
    }
  }
  saveConference(data) {
    if (this.files.length > 0) {
      data.organizationId =
        this.conference.conferenceDetail.oldConferenceDetail.organizationId;
      this.conferenceService.updateConferenceCR(data).then((data) => {
        this.uploadFile(
          'conference',
          this.conference.conferenceDetail.oldConferenceDetail.conferenceId
        );

        this.loadConferenceData();
      });
    } else {
      alert('File is required ');
    }
  }
  saveBootCR(data1) {
    this.conferenceService.validateBooth(data1).then((data) => {
      this.errorData = data;
      if (this.errorData.length > 0) {
        this.displayErrorModel = true;
      } else {
        this.conferenceService.updateBoothCR(data1).then((data) => {
          this.loadConferenceData();
        });
      }
    });
  }
  verify1(data) {
    
    this.conferenceService.validateBanner(data).then((data1) => {
      this.verifedData = data1;
      data['verifedData'] = this.verifedData
      const arrayLength = this.verifedData.filter(
        (item) => !item.result
      ).length;
      if (arrayLength > 0) {
        this.isSaveBtn = false;
        data['isSaveBtn'] = false;
      } else {
        data['isSaveBtn'] = true;
      }
    });
  }
  saveBannerCR(data1) {
    this.conferenceService.validateBanner(data1).then((data) => {
      this.verifedData = data;
      const arrayLength = this.verifedData.filter(
        (item) => !item.result
      ).length;
      if (arrayLength > 0) {
        this.isSaveBtn = false;
      } else {
        this.conferenceService.updateBannerCR(data1).then((data) => {
          this.loadConferenceData();
        });
      }
    });
  }
  saveAddCR(data1) {
    this.conferenceService.validateAdvertisement(data1).then((data) => {
      this.errorData = data;
      if (this.errorData.length > 0) {
        this.displayErrorModel = true;
      } else {
        this.conferenceService.updateaddCR(data1).then((data) => {
          this.loadConferenceData();
        });
      }
    });
  }
  saveOnlineAddCR(data1) {
    this.conferenceService.validateOnlineAdd(data1).then((data) => {
      this.errorData = data;
      if (this.errorData.length > 0) {
        this.displayErrorModel = true;
      } else {
        this.conferenceService.updateOnlineAddCR(data1).then((data) => {
          this.loadConferenceData();
        });
      }
    });
  }
}
