import { InjectionToken, NgModule } from '@angular/core';
//export let APP_CONFIG=new InjectionToken<AppConfig>('');

export class AppConfig {
  parentDomain: string;
  apiEndPoint: string;
  endPoints: {
    Organisation: {
      getOrganisation: string;
      saveOrganisation: string;
      updateOrganisation: string;
    };
    EventGuide: {
      getevents: string;
      saveevents: string;
      updateevents: string;
    };
    ErrorMessage: {
      geterrors: string;
      saveerrors: string;
      updateerrors: string;
    };
    Role: {
      getRoles: string;
      saveRole: string;
      updateRole: string;
    };
    User: {
      getUsers: string;
      saveUser: string;
      updateUser: string;
      approveRejectUser:string;
      authenticate:string;
    };
    Code: {
      getCodes: string;
      saveCode: string;
      updateCode: string;
      codeWithGroup: string;
    };
    Product: {
      getProducts: string;
      saveProduct: string;
      updateProduct: string;
    };
    Valuesettings: {
      getValuesettings: string;
      updateValuesettings: string;
    };
    Codemanagement: {
      getCodemanagement: string;
      saveCodemanagement: string;
      updateCodemanagement: string;
    };
    Notificationmanagement: {
      getNotificationmanagement: string;
      saveNotificationmanagement: string;
      updateNotificationmanagement: string;
      fileUpload: string;
      fileDownload: string;
    };
    Menumanagement: {
      getMenumanagement: string;
      saveMenumanagement: string;
      updateMenumanagement: string;
      getMenumanagementById:string,
      updateSubMenut: string;
    };
    contenferance: {
      getAllConferences: string;
      saveConference: string;
      updateConference:string;
      saveBooth: string;
      updateBooth: string;
      saveBanner: string;
      saveAdvertisement: string;
      updateAdvertisement: string;
      updateMenumanagement: string;
      getDetails: string;
      updateBanner: string;
      getAddTypes: string;
      uploadFileConference: string;
      getBannerDetails: string;
      getAddDetails: string;
      getBoothDetails: string;
      confereceFileDownload:string;
      uploadBoothFile:string,
      uploadBannerFile:string,
      uploadAdvertisementFile:string,
      deleteAdd:string,
      deleteBooth:string,
      deleteBanner:string,
      deleteOnlineADD:string,
      validateBooth:string,
      validateBoothCreation:string,
      boothCRApproval:string,
      bannerCRApproval:string,
      addCRApproval:string,
      getConferenceDetailedById:string,
      createOnlineAdvertisement:string,
      validateOnlineAdCreation:string,
      validateOnlineAd:string,
      updateOnlineAdvertisement:string,
      uploadOnlineAdd:string,
      validateBannerCreation:string,
      bannerVerification:string,
      getkrpaList:string,
      setPaymentDate:string,
      boothApproval:string,
      bannerApproval:string,
      addApproval:string,
      onlineAddApproval:string,
      changeRequestNew:string,
      onlineAddDetails:string,
      updateOnlineAdd:string,
      downloadAdd:string,
      downloadOnlineAdd:string,
      downloadBanner:string,
      downloadBooth:string,
      validateAdvertisement:string,
      exportKRPIA:string,
      exportAllKRPIAData:string,
      getKRPIADates:string,
      conditionalSearchGet:string,
      conditionalSearch:string,
      editBanner:string,
      editAdvertisement:string,
      editBooth:string,
      editOnlineAdvertisement:string,
      deleteConferenceCR:string,
      deleteBoothCR:string,
      deleteBannerCR:string,
      deleteAddCR:string,
      deleteOnlineAddCR:string,
    };
    changeRequest: {
      createaddCR: string;
      createBoothCR: string;
      createBannerCR: string;
      createOnlineAddCR: string;
      updateaddCR: string;
      updateBoothCR: string;
      updateBannerCR: string;
      updateOnlineAddCR: string;
      approveaddCR: string;
      approveBoothCR: string;
      approveBannerCR: string;
      approveOnlineAddCR: string;
      updateConferenceCR:string;
      submittCR:string;
      crListView:string;
      crListForApprove:string;
      conferenceCRApproval:string;
      cancelCR:string;
      getConferenceCRForView:string;
      CRSubmitApproval:string
    };
  };
}
export const APP_DI_CONFIG: AppConfig = {
  parentDomain: 'http://10.0.1.108:81/',
  apiEndPoint: 'api/',
  endPoints: {
    Organisation: {
      getOrganisation: 'Organization/getAllOrganizations',
      saveOrganisation: 'Organization/createOrganization',
      updateOrganisation: 'Organization/updateOrganization',
    },
    EventGuide: {
      getevents: 'EventGuideline/getAllEventGuidelines',
      saveevents: 'EventGuideline/createEventGuideline',
      updateevents: 'EventGuideline/updateEventGuideline',
    },

    ErrorMessage: {
      geterrors: 'ErrorMessage/getAllErrorMessages',
      saveerrors: 'ErrorMessage/createErrorMessage',
      updateerrors: 'ErrorMessage/updateErrorMessage',
    },
    Role: {
      getRoles: 'Role/getRolesWithUsers',
      saveRole: 'Role/createRole',
      updateRole: 'Role/updateRole',
    },
    User: {
      getUsers: 'User/getAllUsers',
      saveUser: 'User/createUser',
      updateUser: 'User/updateUser',
      approveRejectUser:"User/approveReject",
      authenticate:"Account/authenticate"
    },
    Code: {
      getCodes: 'Code/getAllCodes',
      saveCode: 'Code/createCode',
      updateCode: 'Code/updateCode',
      codeWithGroup: 'Code/getCodesByGroup',
    },
    Product: {
      getProducts: 'Product/getAllProduct',
      saveProduct: 'Product/createProduct',
      updateProduct: 'Product/updateProduct',
    },
    Valuesettings: {
      getValuesettings: 'SystemMenu/getAllSystemMenu',
      updateValuesettings: 'SystemMenu/updateSystemMenu',
    },
    Codemanagement: {
      getCodemanagement: 'CodeGroup/getCodeGroupsWithCodes',
      saveCodemanagement: 'CodeGroup/createCodeGroup',
      updateCodemanagement: 'CodeGroup/updateCodeGroup',
    },
    Notificationmanagement: {
      getNotificationmanagement: 'Notification/getAllNotifications',
      saveNotificationmanagement: 'Notification/createNotification',
      updateNotificationmanagement: 'Notification/updateNotification',
      fileUpload: 'Notification/upload/Notification',
      fileDownload: 'Notification/downloadFile',
    },
    Menumanagement: {
      getMenumanagement: 'Menu/getMenusWithSubMenus',
      saveMenumanagement: 'Menu/createMenu',
      updateMenumanagement: 'Menu/updateMenu',
      getMenumanagementById: 'Menu/getMenuById',
      updateSubMenut:"Menu/updateMenu"
    },
    contenferance: {
      getAllConferences: 'Conference/getAllConferences',
      saveConference: 'Conference/createConference',
      updateConference: 'Conference/updateConference',
      saveBooth: 'Booth/createBooth',
      updateBooth: 'Booth/updatePaymentDetail',
      saveBanner: 'Banner/createBanner',
      updateBanner: 'Banner/updatePaymentDetail',
      saveAdvertisement: 'Advertisement/createAdvertisement',
      updateAdvertisement: 'Advertisement/updatePaymentDetail',
      updateMenumanagement: 'Product/updateProduct',
      getDetails: 'Conference/getConferenceById',
      getAddTypes: 'AdType/getAllAdType',
      uploadFileConference: 'Conference/upload/conference',
      getBannerDetails: 'Banner/getBannerById',
      getAddDetails: 'Advertisement/getAdvertisementById',
      getBoothDetails: 'Booth/getBoothById',
      confereceFileDownload:"Conference/downloadFile",
      uploadBoothFile:"Booth/upload/booth",
      uploadBannerFile:"Banner/upload/banner",
      uploadAdvertisementFile:"Advertisement/upload/advertisement",
      deleteAdd:"Advertisement/deleteAdvertisement",
      validateBooth:"Booth/validateBooth",
      validateBoothCreation:"Booth/validateBoothCreation",
      boothCRApproval:"Booth/boothCRApproval",
      bannerCRApproval:"Banner/bannerCRApproval",
      addCRApproval:"Advertisement/advertisementCRApproval",
      getConferenceDetailedById:"Conference/getConferenceCRById",
      createOnlineAdvertisement:"OnlineAdvetisement/createOnlineAdvertisement",
      validateOnlineAdCreation:"OnlineAdvetisement/validateOnlineAdCreation",
      validateOnlineAd:"OnlineAdvetisement/validateOnlineAd",
      updateOnlineAdvertisement:"OnlineAdvetisement/updatePaymentDetail",
      uploadOnlineAdd:"OnlineAdvetisement/upload/onlineAdvertisement", 
      validateBannerCreation:"Banner/bannerVerification",
      bannerVerification:"Banner/bannerVerification",
      getkrpaList:"MandE/searchEvents",
      setPaymentDate:"MandE/setPaymentDate",
      boothApproval:"Booth/boothApproval",
      bannerApproval:"Banner/bannerApproval",
      addApproval:"Advertisement/advertisementApproval",
      onlineAddApproval:"OnlineAdvetisement/OnlineAdvertisementApproval",
      changeRequestNew:"Conference/changeRequestNew",
      deleteBooth:"Booth/deleteBooth",
      deleteBanner:"Banner/deleteBanner",
      deleteOnlineADD:"OnlineAdvetisement/deleteOnlineAdvertisement",
      onlineAddDetails:"OnlineAdvetisement/getOnlineAdvertisementById",
      updateOnlineAdd:"OnlineAdvetisement/updatePaymentDetail",
      downloadAdd:"Advertisement/downloadFile",
      downloadOnlineAdd:"OnlineAdvetisement/downloadFile",
      downloadBanner:"Banner/downloadFile",
      downloadBooth:"Booth/downloadFile",
      validateAdvertisement:"Advertisement/validateAdvertisement",
      exportKRPIA:"MandE/exportKRPIA",
      exportAllKRPIAData:"MandE/exportAllKRPIAData",
      getKRPIADates:"MandE/getKRPIADates",
      conditionalSearchGet:"MandE/conditionalSearchGet",
      conditionalSearch:"MandE/conditionalSearch",
      editBanner:"Banner/updateBanner",
      editAdvertisement:"Advertisement/updateAdvertisement",
      editBooth:"Booth/updateBooth",
      editOnlineAdvertisement:"OnlineAdvetisement/updateOnlineAdvertisement",
      deleteConferenceCR:"Conference/changeRequestDelete",
      deleteBoothCR:"Booth/changeRequestDelete",
      deleteBannerCR:"Banner/changeRequestDelete",
      deleteAddCR:"Advertisement/deleteAdvertisement",
      deleteOnlineAddCR:"OnlineAdvetisement​/deleteOnlineAdvertisement",
    },
    changeRequest: {
      createaddCR: "Advertisement/changeRequestNew",
      createBoothCR: "Booth/changeRequestNew",
      createBannerCR: "Banner/changeRequestNew",
      createOnlineAddCR: "OnlineAdvetisement/changeRequestNew",
      updateaddCR: "Advertisement/changeRequestEdit",
      updateBoothCR: "Booth/changeRequestEdit",
      updateBannerCR: "Banner/changeRequestEdit",
      updateOnlineAddCR: "OnlineAdvetisement/changeRequestEdit",
      approveaddCR: "Advertisement/advertisementCRApproval",
      approveBoothCR: "Booth/boothCRApproval",
      approveBannerCR: "Banner/bannerCRApproval",
      approveOnlineAddCR: "OnlineAdvetisement/OnlineAdvertisementCRApproval/{id}",
      updateConferenceCR:"Conference/changeRequestEdit",
      submittCR:"Conference/submitCR",
      crListView:"Conference/crListForView",
      crListForApprove:"Conference/crListForApprove",
      conferenceCRApproval:"Conference/conferenceCRApproval",
      cancelCR:"Conference/cancelCR",
      getConferenceCRForView:"Conference/getConferenceCRForView",
      CRSubmitApproval:"Conference/CRSubmitApproval"
     
    }
  },
};

@NgModule({
  //   providers:[
  //       {
  //          // provide:APP_CONFIG,
  //          // useValue:APP_DI_CONFIG
  //           //useClass:AppConfig
  //       }
  //   ]
})
export class AppConfigModules {}
