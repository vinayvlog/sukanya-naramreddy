import { RouterReducerState, routerReducer } from '@ngrx/router-store';
import { ActionReducerMap, MetaReducer } from '@ngrx/store';

import { environment } from '../../environments/environment';
import * as user from './stores/users';
import * as role from './stores/roles';
import * as product from './stores/products';
import * as valuesettings from './stores/valuesettings';
import * as codegroup from './stores/codemanagement';
import * as notificationmanagement from './stores/notificationmanagement';
import * as menumanagement from './stores/menumanagement';
/**
 * Import Stores
 */

export { Store, StoreModule } from '@ngrx/store';

/**
 * State for each store
 */
export interface State {
  router: RouterReducerState;
  user: user.UserState;
  role: role.RoleState;
  product: product.ProductState;
  valuesettings: valuesettings.ValuesettingState;
  codegroup: codegroup.CodeGroupState;
  notificationmanagement: notificationmanagement.NotificationManagementState;
  menumanagement: menumanagement.MenumanagementState;
}

export function getInitialState() {
  return {
    user: user.INITIAL_STATE,
    role: role.INITIAL_STATE,
    product: product.INITIAL_STATE,
    valuesettings: valuesettings.INITIAL_STATE,
    codegroup: codegroup.INITIAL_STATE,
    notificationmanagement: notificationmanagement.INITIAL_STATE,
    menumanagement: menumanagement.INITIAL_STATE,
  } as State;
}

/**
 * Effects for each store
 */
export const effects = [
  role.RoleEffects,
  user.UserEffects,
  product.ProductEffects,
  valuesettings.ValueSettingsEffects,
  codegroup.CodeGroupEffects,
  notificationmanagement.NotificationManagementEffects,
  menumanagement.MenuManagementEffects,
];

/**
 * Reducer for each store
 */
export const reducers: ActionReducerMap<State> = {
  role: role.RoleReducer,
  router: routerReducer,
  user: user.UserReducer,
  product: product.ProductReducer,
  valuesettings: valuesettings.ValueSettingReducer,
  codegroup: codegroup.CodeGroupReducer,
  notificationmanagement: notificationmanagement.NotificationManagementReducer,
  menumanagement: menumanagement.MenumanagementReducer
};

/**
 * MetaReducer for each store
 */
export const metaReducers: MetaReducer<State>[] = !environment.production
  ? []
  : [];
