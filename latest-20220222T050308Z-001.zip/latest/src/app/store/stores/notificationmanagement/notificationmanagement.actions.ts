import { Action } from '@ngrx/store';
import { NotificationManagement } from 'src/app/_services/notificationmanagement/notificationmanagement.service';

export enum NotificationManagementTypes {
  GetNotificationManagement = '[NotificationManagement] GetNotificationManagement',
  GetNotificationManagementsSuccess = '[NotificationManagement] GetNotificationManagementsSuccess',
  GetNotificationManagementsError = '[NotificationManagement] GetNotificationManagementsError',
  CreateNotificationManagement = '[NotificationManagement] CreateNotificationManagement',
  CreateNotificationManagementsuccess = '[NotificationManagement] CreateNotificationManagementsuccess',
  CreateNotificationManagementError = '[NotificationManagement] CreateNotificationManagementError',
  UpdateNotificationManagement = '[NotificationManagement] UpdateNotificationManagement',
  UpdateNotificationManagementsuccess = '[NotificationManagement] UpdateNotificationManagementsuccess',
  UpdateNotificationManagementError = '[NotificationManagement] UpdateNotificationManagementError',

}

export class GetNotificationManagement implements Action {
  readonly type = NotificationManagementTypes.GetNotificationManagement;
  constructor() {}
}

export class GetNotificationManagementsSuccess implements Action {
  readonly type = NotificationManagementTypes.GetNotificationManagementsSuccess;
  constructor(readonly payload: NotificationManagement[]) {}
}
export class GetNotificationManagementsError implements Action {
  readonly type = NotificationManagementTypes.GetNotificationManagementsError;
  constructor(readonly payload: boolean) {}
}

export class CreateNotificationManagement implements Action {
  readonly type = NotificationManagementTypes.CreateNotificationManagement;
  constructor(readonly payload: NotificationManagement) {}
}

export class CreateNotificationManagementsuccess implements Action {
  readonly type =
    NotificationManagementTypes.CreateNotificationManagementsuccess;
  constructor(readonly payload: NotificationManagement) {}
}

export class CreateNotificationManagementError implements Action {
  readonly type = NotificationManagementTypes.CreateNotificationManagementError;
}
export class UpdateNotificationManagement implements Action {
  readonly type = NotificationManagementTypes.UpdateNotificationManagement;
  constructor(readonly payload: NotificationManagement) {}
}

export class UpdateNotificationManagementsuccess implements Action {
  readonly type =
    NotificationManagementTypes.UpdateNotificationManagementsuccess;
  constructor(readonly payload: NotificationManagement) {}
}

export class UpdateNotificationManagementError implements Action {
  readonly type = NotificationManagementTypes.UpdateNotificationManagementError;
}

export type Union =
  | GetNotificationManagement
  | GetNotificationManagementsError
  | GetNotificationManagementsSuccess
  | CreateNotificationManagement
  | CreateNotificationManagementsuccess
  | CreateNotificationManagementError
  | UpdateNotificationManagement
  | UpdateNotificationManagementsuccess
  | UpdateNotificationManagementError;
