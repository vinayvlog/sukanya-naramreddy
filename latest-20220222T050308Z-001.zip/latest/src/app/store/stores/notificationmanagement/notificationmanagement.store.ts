import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from '../..';
import { NotificationManagement } from 'src/app/_services/notificationmanagement/notificationmanagement.service';
import { NotificationManagementTypes, Union } from './notificationmanagement.actions';

export interface NotificationManagementState {
  loading: boolean;
  entities: NotificationManagement[];
  creating: boolean;
  created: boolean;
  updating: boolean;
  updated: boolean;
  error: boolean;
}

export const INITIAL_STATE: NotificationManagementState = {
  loading: false,
  entities: [],
  creating: false,
  created: false,
  error: false,
  updating: false,
  updated: false,
};

export function NotificationManagementReducer(
  state: NotificationManagementState = INITIAL_STATE,
  action: Union
): NotificationManagementState {
  switch (action.type) {
    
    case NotificationManagementTypes.GetNotificationManagement:
      return {
        ...state,
        loading: true,
      };
    case NotificationManagementTypes.GetNotificationManagementsSuccess:
      const notificationManagement = action.payload;
      return {
        ...state,
        loading: false,
        entities: notificationManagement,
      };
    case NotificationManagementTypes.GetNotificationManagementsError:
      const error1: boolean = action.payload;
      return {
        ...state,
        loading: false,
        error: error1,
      };
    case NotificationManagementTypes.CreateNotificationManagement:
      return {
        ...state,
        creating: true,
        created: false,
      };
    case NotificationManagementTypes.CreateNotificationManagementsuccess:
      const createdNotificationManagement: NotificationManagement = action.payload;
      const entitiesAppended = [...state.entities, createdNotificationManagement];
      return {
        ...state,
        creating: false,
        entities: entitiesAppended,
        created: true,
      };
    case NotificationManagementTypes.UpdateNotificationManagement:
      return {
        ...state,
        updating: true,
        updated: false,
      };
    case NotificationManagementTypes.UpdateNotificationManagementsuccess:
      const updatedNotificationManagement: NotificationManagement = action.payload;
      const updatedentitiesAppended = [...state.entities, updatedNotificationManagement];
      return {
        ...state,
        updating: false,
        entities: updatedentitiesAppended,
        updated: true,
      };
    case NotificationManagementTypes.UpdateNotificationManagementError:
      return {
        ...state,
        updated: false,
        updating: false,
      };
    case NotificationManagementTypes.CreateNotificationManagementError:
      return {
        ...state,
        creating: false,
        created: false,
      };

    default:
      return state;
  }
}

export const getNotificationManagementState = createFeatureSelector<State, NotificationManagementState>('notificationmanagement');

export const getNotificationManagementLoading = createSelector(
  getNotificationManagementState,
  (state) => state.loading
);

export const getNotificationManagement = createSelector(getNotificationManagementState, (state) => state.entities);

export const getNotificationManagementCreating = createSelector(
  getNotificationManagementState,
  (state) => state.creating
);

export const getNotificationManagementCreated = createSelector(
  getNotificationManagementState,
  (state) => state.created
);
export const getNotificationManagementUpdating = createSelector(
  getNotificationManagementState,
  (state) => state.updating
);

export const getNotificationManagementUpdated = createSelector(
  getNotificationManagementState,
  (state) => state.updated
);

export const getNotificationManagementError = createSelector(
  getNotificationManagementState,
  (state) => state.error
);
