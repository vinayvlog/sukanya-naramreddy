import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { from, Observable, of } from 'rxjs';
import { catchError, concatMap, exhaustMap, map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { NotificationmanagementService } from 'src/app/_services/notificationmanagement/notificationmanagement.service';
import {
  CreateNotificationManagement,
  CreateNotificationManagementsuccess,
  CreateNotificationManagementError,
  GetNotificationManagement,
  GetNotificationManagementsError,
  GetNotificationManagementsSuccess,
  NotificationManagementTypes,
  UpdateNotificationManagement,
  UpdateNotificationManagementError,
  UpdateNotificationManagementsuccess,
} from './notificationmanagement.actions';

@Injectable()
export class NotificationManagementEffects {
  constructor(
    private actions: Actions,
    private notificationmanagementService: NotificationmanagementService,
    private toastrService: ToastrService
  ) {
    console.log('Notification Management Effect');
  }

  @Effect()
  getNotificationManagement$: Observable<Action> = this.actions.pipe(
    ofType<GetNotificationManagement>(NotificationManagementTypes.GetNotificationManagement),
    map(() => console.log('Effect Notification Management')),
    exhaustMap(() =>
      from(this.notificationmanagementService.list()).pipe(
        map((payload) => {
          return new GetNotificationManagementsSuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to retrieve Notification Management', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new GetNotificationManagementsError(true));
        })
      )
    )
  );

  @Effect()
  createNotificationManagement$: Observable<Action> = this.actions.pipe(
    ofType<CreateNotificationManagement>(NotificationManagementTypes.CreateNotificationManagement),
    concatMap((action) =>
      from(this.notificationmanagementService.create(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Notification Management has been created.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new CreateNotificationManagementsuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to create Notification Management', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new CreateNotificationManagementError());
        })
      )
    )
  );
  @Effect()
  updateNotificationManagement$: Observable<Action> = this.actions.pipe(
    ofType<UpdateNotificationManagement>(NotificationManagementTypes.UpdateNotificationManagement),
    concatMap((action) =>
      from(this.notificationmanagementService.update(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Notification Management has been updated.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new UpdateNotificationManagementsuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to update Notification Management', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new UpdateNotificationManagementError());
        })
      )
    )
  );
}
