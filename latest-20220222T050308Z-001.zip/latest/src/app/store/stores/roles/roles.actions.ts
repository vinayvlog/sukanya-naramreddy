import { Action } from '@ngrx/store';
import { Role } from '../../../_services/roles/role.service';

export enum RoleTypes {
  GetRoles = '[Role] GetRoles',
  GetRolesSuccess = '[Role] GetRolesSuccess',
  GetRolesError = '[Role] GetRolesError',
  CreateRole = '[Role] CreateRole',
  CreateRolesuccess = '[Role] CreateRolesuccess',
  CreateRoleError = '[Role] CreateRoleError',
  UpdateRole = '[Role] UpdateRole',
  UpdateRolesuccess = '[Role] UpdateRolesuccess',
  UpdateRoleError = '[Role] UpdateRoleError',
}

export class GetRoles implements Action {
  
  readonly type = RoleTypes.GetRoles;
  constructor(){
    console.log("Get Roles Actions")
  }
}

export class GetRolesSuccess implements Action {
  readonly type = RoleTypes.GetRolesSuccess;
  constructor(readonly payload: Role[]) {}
}
export class GetRolesError implements Action {
  readonly type = RoleTypes.GetRolesError;
  constructor(readonly payload: boolean) {}
}

export class CreateRole implements Action {
  readonly type = RoleTypes.CreateRole;
  constructor(readonly payload: Role) {}
}

export class CreateRolesuccess implements Action {
  readonly type = RoleTypes.CreateRolesuccess;
  constructor(readonly payload: Role) {}
}

export class CreateRoleError implements Action {
  readonly type = RoleTypes.CreateRoleError;
}
export class UpdateRole implements Action {
  readonly type = RoleTypes.UpdateRole;
  constructor(readonly payload: Role) {}
}

export class UpdateRolesuccess implements Action {
  readonly type = RoleTypes.UpdateRolesuccess;
  constructor(readonly payload: Role) {}
}

export class UpdateRoleError implements Action {
  readonly type = RoleTypes.UpdateRoleError;
}

export type Union =
  | GetRoles
  | GetRolesSuccess
  | GetRolesError
  | CreateRole
  | CreateRolesuccess
  | CreateRoleError
  | UpdateRole
  | UpdateRolesuccess
  | UpdateRoleError;
