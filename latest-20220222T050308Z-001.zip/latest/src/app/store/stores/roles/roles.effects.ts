import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { from, Observable, of } from 'rxjs';
import { catchError, concatMap, exhaustMap, map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

import { RoleService } from '../../../_services/roles/role.service';

import {
  GetRoles,
  GetRolesSuccess,
  GetRolesError,
  CreateRole,
  CreateRolesuccess,
  CreateRoleError,
  RoleTypes,
  UpdateRole,
  UpdateRolesuccess,
  UpdateRoleError,
} from './roles.actions';

@Injectable()
export class RoleEffects {
  constructor(
    private actions: Actions,
    private roleService: RoleService,
    private toastrService: ToastrService
  ) {}

  @Effect()
  getRoles$: Observable<Action> = this.actions.pipe(
    ofType<GetRoles>(RoleTypes.GetRoles),
    map( ()=>console.log("Effect ROle")),
    exhaustMap(() =>
      from(this.roleService.list()).pipe(
        map((payload) => {
          return new GetRolesSuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to retrieve Roles', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new GetRolesError(true));
        })
      )
    )
  );

  @Effect()
  createRole$: Observable<Action> = this.actions.pipe(
    ofType<CreateRole>(RoleTypes.CreateRole),
    concatMap((action) =>
      from(this.roleService.create(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Role has been created.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new CreateRolesuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to create Role', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new CreateRoleError());
        })
      )
    )
  );
  @Effect()
  updateRole$: Observable<Action> = this.actions.pipe(
    ofType<UpdateRole>(RoleTypes.UpdateRole),
    concatMap((action) =>
      from(this.roleService.update(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Role has been updated.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new UpdateRolesuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to update Role', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new UpdateRoleError());
        })
      )
    )
  );
}
