import { Action } from '@ngrx/store';
import { CodeGroup } from 'src/app/_services/codemanagement/codemanagement.service';

export enum CodeTypes {
  GetCodeGroups = '[CodeGroup] GetCodeGroups',
  GetCodeGroupsSuccess = '[CodeGroup] GetCodeGroupsSuccess',
  GetCodeGroupsError = '[CodeGroup] GetCodeGroupsError',
  CreateCodeGroup = '[CodeGroup] CreateCodeGroup',
  CreateCodeGroupsuccess = '[CodeGroup] CreateCodeGroupsuccess',
  CreateCodeGroupError = '[CodeGroup] CreateCodeGroupError',
  UpdateCodeGroup = '[CodeGroup] UpdateCodeGroup',
  UpdateCodeGroupsuccess = '[CodeGroup] UpdateCodeGroupsuccess',
  UpdateCodeGroupError = '[CodeGroup] UpdateCodeGroupError',
}

export class GetCodeGroups implements Action {
  readonly type = CodeTypes.GetCodeGroups;
  constructor() {
    console.log("CodeGroup Action")
  }
}

export class GetCodeGroupsSuccess implements Action {
  readonly type = CodeTypes.GetCodeGroupsSuccess;
  constructor(readonly payload: CodeGroup[]) {}
}
export class GetCodeGroupsError implements Action {
  readonly type = CodeTypes.GetCodeGroupsError;
  constructor(readonly payload: boolean) {}
}

export class CreateCodeGroup implements Action {
  readonly type = CodeTypes.CreateCodeGroup;
  constructor(readonly payload: CodeGroup) {}
}

export class CreateCodeGroupsuccess implements Action {
  readonly type = CodeTypes.CreateCodeGroupsuccess;
  constructor(readonly payload: CodeGroup) {}
}

export class CreateCodeGroupError implements Action {
  readonly type = CodeTypes.CreateCodeGroupError;
}
export class UpdateCodeGroup implements Action {
  readonly type = CodeTypes.UpdateCodeGroup;
  constructor(readonly payload: CodeGroup) {}
}

export class UpdateCodeGroupsuccess implements Action {
  readonly type = CodeTypes.UpdateCodeGroupsuccess;
  constructor(readonly payload: CodeGroup) {}
}

export class UpdateCodeGroupError implements Action {
  readonly type = CodeTypes.UpdateCodeGroupError;
}

export type Union =
  | GetCodeGroups
  | GetCodeGroupsError
  | GetCodeGroupsSuccess
  | CreateCodeGroup
  | CreateCodeGroupsuccess
  | CreateCodeGroupError
  | UpdateCodeGroup
  | UpdateCodeGroupsuccess
  | UpdateCodeGroupError;
