import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { from, Observable, of } from 'rxjs';
import { catchError, concatMap, exhaustMap, map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { CodemanagementService } from 'src/app/_services/codemanagement/codemanagement.service';
import {
  CreateCodeGroup,
  CreateCodeGroupsuccess,
  CreateCodeGroupError,
  GetCodeGroups,
  GetCodeGroupsError,
  GetCodeGroupsSuccess,
  CodeTypes,
  UpdateCodeGroup,
  UpdateCodeGroupError,
  UpdateCodeGroupsuccess,
} from './codemanagement.actions';

@Injectable()
export class CodeGroupEffects {
  constructor(
    private actions: Actions,
    private codemanagementService: CodemanagementService,
    private toastrService: ToastrService
  ) {
    console.log('Code Group Effect');
  }

  @Effect()
  getCodegroup$: Observable<Action> = this.actions.pipe(
    ofType<GetCodeGroups>(CodeTypes.GetCodeGroups),
    map(() => console.log('Effect  Code Groups')),
    exhaustMap(() =>
      from(this.codemanagementService.list()).pipe(
        map((payload) => {
          return new GetCodeGroupsSuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to retrieve Code Groups', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new GetCodeGroupsError(true));
        })
      )
    )
  );

  @Effect()
  createCodegroup$: Observable<Action> = this.actions.pipe(
    ofType<CreateCodeGroup>(CodeTypes.CreateCodeGroup),
    concatMap((action) =>
      from(this.codemanagementService.create(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Code Group has been created.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new CreateCodeGroupsuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to create Code Group', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new CreateCodeGroupError());
        })
      )
    )
  );
  @Effect()
  updateCodegroup$: Observable<Action> = this.actions.pipe(
    ofType<UpdateCodeGroup>(CodeTypes.UpdateCodeGroup),
    concatMap((action) =>
      from(this.codemanagementService.update(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Code Group has been updated.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new UpdateCodeGroupsuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to update Code Group', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new UpdateCodeGroupError());
        })
      )
    )
  );
}
