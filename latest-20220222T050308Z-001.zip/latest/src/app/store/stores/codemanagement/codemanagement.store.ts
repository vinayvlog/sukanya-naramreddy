import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from '../..';
import { CodeGroup } from 'src/app/_services/codemanagement/codemanagement.service';
import { CodeTypes, Union } from './codemanagement.actions';

export interface CodeGroupState {
  loading: boolean;
  entities: CodeGroup[];
  creating: boolean;
  created: boolean;
  updating: boolean;
  updated: boolean;
  error: boolean;
}

export const INITIAL_STATE: CodeGroupState = {
  loading: false,
  entities: [],
  creating: false,
  created: false,
  error: false,
  updating: false,
  updated: false,
};

export function CodeGroupReducer(
  state: CodeGroupState = INITIAL_STATE,
  action: Union
): CodeGroupState {
  switch (action.type) {
    
    case CodeTypes.GetCodeGroups:
      return {
        ...state,
        loading: true,
      };
    case CodeTypes.GetCodeGroupsSuccess:
      const codeGroup = action.payload;
      return {
        ...state,
        loading: false,
        entities: codeGroup,
      };
    case CodeTypes.GetCodeGroupsError:
      const error1: boolean = action.payload;
      return {
        ...state,
        loading: false,
        error: error1,
      };
    case CodeTypes.CreateCodeGroup:
      return {
        ...state,
        creating: true,
        created: false,
      };
    case CodeTypes.CreateCodeGroupsuccess:
      const createdCodeGroup: CodeGroup = action.payload;
      const entitiesAppended = [...state.entities, createdCodeGroup];
      return {
        ...state,
        creating: false,
        entities: entitiesAppended,
        created: true,
      };
    case CodeTypes.UpdateCodeGroup:
      return {
        ...state,
        updating: true,
        updated: false,
      };
    case CodeTypes.UpdateCodeGroupsuccess:
      const updatedCodeGroup: CodeGroup = action.payload;
      const updatedentitiesAppended = [...state.entities, updatedCodeGroup];
      return {
        ...state,
        updating: false,
        entities: updatedentitiesAppended,
        updated: true,
      };
    case CodeTypes.UpdateCodeGroupError:
      return {
        ...state,
        updated: false,
        updating: false,
      };
    case CodeTypes.CreateCodeGroupError:
      return {
        ...state,
        creating: false,
        created: false,
      };

    default:
      return state;
  }
}

export const getCodeGroupState = createFeatureSelector<State, CodeGroupState>('codegroup');

export const getCodeGroupLoading = createSelector(
  getCodeGroupState,
  (state) => state.loading
);

export const getCodeGroup = createSelector(getCodeGroupState, (state) => state.entities);

export const getCodeGroupCreating = createSelector(
  getCodeGroupState,
  (state) => state.creating
);

export const getCodeGroupCreated = createSelector(
  getCodeGroupState,
  (state) => state.created
);
export const getCodeGroupUpdating = createSelector(
  getCodeGroupState,
  (state) => state.updating
);

export const getCodeGroupUpdated = createSelector(
  getCodeGroupState,
  (state) => state.updated
);

export const getCodeGroupError = createSelector(
  getCodeGroupState,
  (state) => state.error
);
