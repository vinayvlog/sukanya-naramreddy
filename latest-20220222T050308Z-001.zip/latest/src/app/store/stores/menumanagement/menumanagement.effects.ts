import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { from, Observable, of } from 'rxjs';
import { catchError, concatMap, exhaustMap, map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { MenumanagementService } from 'src/app/_services/menumanagement/menumanagement.service';
import {
  CreateMenumanagement,
  CreateMenumanagementsuccess,
  CreateMenumanagementError,
  GetMenumanagement,
  GetMenumanagementsError,
  GetMenumanagementsSuccess,
  MenumanagementTypes,
  UpdateMenumanagement,
  UpdateMenumanagementError,
  UpdateMenumanagementsuccess,
} from './menumanagement.actions';

@Injectable()
export class MenuManagementEffects {
  constructor(
    private actions: Actions,
    private menumanagementService: MenumanagementService,
    private toastrService: ToastrService
  ) {
    console.log('Menu Management Effect');
  }

  @Effect()
  getMenuManagement$: Observable<Action> = this.actions.pipe(
    ofType<GetMenumanagement>(MenumanagementTypes.GetMenumanagement),
    map(() => console.log('Effect Menu Management')),
    exhaustMap(() =>
      from(this.menumanagementService.list()).pipe(
        map((payload) => {
          return new GetMenumanagementsSuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to retrieve Menu Management', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new GetMenumanagementsError(true));
        })
      )
    )
  );

  @Effect()
  createMenuManagement$: Observable<Action> = this.actions.pipe(
    ofType<CreateMenumanagement>(MenumanagementTypes.CreateMenumanagement),
    concatMap((action) =>
      from(this.menumanagementService.create(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Menu Management has been created.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new CreateMenumanagementsuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to create Menu Management', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new CreateMenumanagementError());
        })
      )
    )
  );
  @Effect()
  updateMenuManagement$: Observable<Action> = this.actions.pipe(
    ofType<UpdateMenumanagement>(MenumanagementTypes.UpdateMenumanagement),
    concatMap((action) =>
      from(this.menumanagementService.update(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Menu Management has been updated.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new UpdateMenumanagementsuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to update Menu Management', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new UpdateMenumanagementError());
        })
      )
    )
  );
}
