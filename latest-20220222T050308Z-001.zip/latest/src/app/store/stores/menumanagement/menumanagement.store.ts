import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from '../..';
import { Menumanagement } from 'src/app/_services/menumanagement/menumanagement.service';
import { MenumanagementTypes, Union } from './menumanagement.actions';

export interface MenumanagementState {
  loading: boolean;
  entities: Menumanagement[];
  creating: boolean;
  created: boolean;
  updating: boolean;
  updated: boolean;
  error: boolean;
}

export const INITIAL_STATE: MenumanagementState = {
  loading: false,
  entities: [],
  creating: false,
  created: false,
  error: false,
  updating: false,
  updated: false,
};

export function MenumanagementReducer(
  state: MenumanagementState = INITIAL_STATE,
  action: Union
): MenumanagementState {
  switch (action.type) {
    
    case MenumanagementTypes.GetMenumanagement:
      return {
        ...state,
        loading: true,
      };
    case MenumanagementTypes.GetMenumanagementsSuccess:
      const Menumanagement = action.payload;
      return {
        ...state,
        loading: false,
        entities: Menumanagement,
      };
    case MenumanagementTypes.GetMenumanagementsError:
      const error1: boolean = action.payload;
      return {
        ...state,
        loading: false,
        error: error1,
      };
    case MenumanagementTypes.CreateMenumanagement:
      return {
        ...state,
        creating: true,
        created: false,
      };
    case MenumanagementTypes.CreateMenumanagementsuccess:
      const createdMenumanagement: Menumanagement = action.payload;
      const entitiesAppended = [...state.entities, createdMenumanagement];
      return {
        ...state,
        creating: false,
        entities: entitiesAppended,
        created: true,
      };
    case MenumanagementTypes.UpdateMenumanagement:
      return {
        ...state,
        updating: true,
        updated: false,
      };
    case MenumanagementTypes.UpdateMenumanagementsuccess:
      const updatedMenumanagement: Menumanagement = action.payload;
      const updatedentitiesAppended = [...state.entities, updatedMenumanagement];
      return {
        ...state,
        updating: false,
        entities: updatedentitiesAppended,
        updated: true,
      };
    case MenumanagementTypes.UpdateMenumanagementError:
      return {
        ...state,
        updated: false,
        updating: false,
      };
    case MenumanagementTypes.CreateMenumanagementError:
      return {
        ...state,
        creating: false,
        created: false,
      };

    default:
      return state;
  }
}

export const getMenumanagementState = createFeatureSelector<State, MenumanagementState>('menumanagement');

export const getMenumanagementLoading = createSelector(
  getMenumanagementState,
  (state) => state.loading
);

export const getMenumanagement = createSelector(getMenumanagementState, (state) => state.entities);

export const getMenumanagementCreating = createSelector(
  getMenumanagementState,
  (state) => state.creating
);

export const getMenumanagementCreated = createSelector(
  getMenumanagementState,
  (state) => state.created
);
export const getMenumanagementUpdating = createSelector(
  getMenumanagementState,
  (state) => state.updating
);

export const getMenumanagementUpdated = createSelector(
  getMenumanagementState,
  (state) => state.updated
);

export const getMenumanagementError = createSelector(
  getMenumanagementState,
  (state) => state.error
);
