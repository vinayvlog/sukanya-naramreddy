import { Action } from '@ngrx/store';
import { Menumanagement } from 'src/app/_services/menumanagement/menumanagement.service';

export enum MenumanagementTypes {
  GetMenumanagement = '[Menumanagement] GetMenumanagement',
  GetMenumanagementsSuccess = '[Menumanagement] GetMenumanagementsSuccess',
  GetMenumanagementsError = '[Menumanagement] GetMenumanagementsError',
  CreateMenumanagement = '[Menumanagement] CreateMenumanagement',
  CreateMenumanagementsuccess = '[Menumanagement] CreateMenumanagementsuccess',
  CreateMenumanagementError = '[Menumanagement] CreateMenumanagementError',
  UpdateMenumanagement = '[Menumanagement] UpdateMenumanagement',
  UpdateMenumanagementsuccess = '[Menumanagement] UpdateMenumanagementsuccess',
  UpdateMenumanagementError = '[Menumanagement] UpdateMenumanagementError',
}

export class GetMenumanagement implements Action {
  readonly type = MenumanagementTypes.GetMenumanagement;
  constructor() {
    console.log("Menumanagement Action")
  }
}

export class GetMenumanagementsSuccess implements Action {
  readonly type = MenumanagementTypes.GetMenumanagementsSuccess;
  constructor(readonly payload: Menumanagement[]) {}
}
export class GetMenumanagementsError implements Action {
  readonly type = MenumanagementTypes.GetMenumanagementsError;
  constructor(readonly payload: boolean) {}
}

export class CreateMenumanagement implements Action {
  readonly type = MenumanagementTypes.CreateMenumanagement;
  constructor(readonly payload: Menumanagement) {}
}

export class CreateMenumanagementsuccess implements Action {
  readonly type = MenumanagementTypes.CreateMenumanagementsuccess;
  constructor(readonly payload: Menumanagement) {}
}

export class CreateMenumanagementError implements Action {
  readonly type = MenumanagementTypes.CreateMenumanagementError;
}
export class UpdateMenumanagement implements Action {
  readonly type = MenumanagementTypes.UpdateMenumanagement;
  constructor(readonly payload: Menumanagement) {}
}

export class UpdateMenumanagementsuccess implements Action {
  readonly type = MenumanagementTypes.UpdateMenumanagementsuccess;
  constructor(readonly payload: Menumanagement) {}
}

export class UpdateMenumanagementError implements Action {
  readonly type = MenumanagementTypes.UpdateMenumanagementError;
}

export type Union =
  | GetMenumanagement
  | GetMenumanagementsError
  | GetMenumanagementsSuccess
  | CreateMenumanagement
  | CreateMenumanagementsuccess
  | CreateMenumanagementError
  | UpdateMenumanagement
  | UpdateMenumanagementsuccess
  | UpdateMenumanagementError;
