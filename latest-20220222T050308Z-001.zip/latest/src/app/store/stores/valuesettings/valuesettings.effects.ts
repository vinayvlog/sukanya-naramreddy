import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { from, Observable, of } from 'rxjs';
import { catchError, concatMap, exhaustMap, map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { ValuesettingsService } from 'src/app/_services/valuesettings.service';
import {
  GetValuesettings,
  GetValuesettingsError,
  GetValuesettingsSuccess,
  ValuesettingsTypes,
  UpdateValuesettings,
  UpdateValuesettingsError,
  UpdateValuesettingssuccess,
} from './valuesettings.actions';

@Injectable()
export class ValueSettingsEffects {
  constructor(
    private actions: Actions,
    private valuesettingsService: ValuesettingsService,
    private toastrService: ToastrService
  ) {
    console.log('Value Settings Effect');
  }

  @Effect()
  getValuesettings$: Observable<Action> = this.actions.pipe(
    ofType<GetValuesettings>(ValuesettingsTypes.GetValuesettings),
    map(() => console.log('Effect ProdValue Settingsuct')),
    exhaustMap(() =>
      from(this.valuesettingsService.list()).pipe(
        map((payload) => {
          return new GetValuesettingsSuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error(
            'Failed to retrieve Value Settings',
            'Error...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return of(new GetValuesettingsError(true));
        })
      )
    )
  );
  @Effect()
  updateValuesettings$: Observable<Action> = this.actions.pipe(
    ofType<UpdateValuesettings>(ValuesettingsTypes.UpdateValuesettings),
    concatMap((action) =>
      from(this.valuesettingsService.update(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Value Settings has been updated.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new UpdateValuesettingssuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error(
            'Failed to update Value Settings',
            'Error...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return of(new UpdateValuesettingsError());
        })
      )
    )
  );
}
