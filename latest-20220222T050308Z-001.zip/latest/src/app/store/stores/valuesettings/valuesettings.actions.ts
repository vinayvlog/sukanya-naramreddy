import { Action } from '@ngrx/store';
import { Valuesettings } from 'src/app/_services/valuesettings.service';

export enum ValuesettingsTypes {
  GetValuesettings = '[Valuesettings] GetValuesettings',
  GetValuesettingsSuccess = '[Valuesettings] GetValuesettingsSuccess',
  GetValuesettingsError = '[Valuesettings] GetValuesettingsError',
  UpdateValuesettings = '[Valuesettings] UpdateValuesettings',
  UpdateValuesettingssuccess = '[Valuesettings] UpdateValuesettingssuccess',
  UpdateValuesettingsError = '[Valuesettings] UpdateValuesettingsError',
}

export class GetValuesettings implements Action {
  readonly type = ValuesettingsTypes.GetValuesettings;
  constructor() {
    console.log("Valuesettings Action")
  }
}

export class GetValuesettingsSuccess implements Action {
  readonly type = ValuesettingsTypes.GetValuesettingsSuccess;
  constructor(readonly payload: Valuesettings[]) {}
}
export class GetValuesettingsError implements Action {
  readonly type = ValuesettingsTypes.GetValuesettingsError;
  constructor(readonly payload: boolean) {}
}

export class UpdateValuesettings implements Action {
  readonly type = ValuesettingsTypes.UpdateValuesettings;
  constructor(readonly payload: Valuesettings) {}
}

export class UpdateValuesettingssuccess implements Action {
  readonly type = ValuesettingsTypes.UpdateValuesettingssuccess;
  constructor(readonly payload: Valuesettings) {}
}

export class UpdateValuesettingsError implements Action {
  readonly type = ValuesettingsTypes.UpdateValuesettingsError;
}

export type Union =
  | GetValuesettings
  | GetValuesettingsError
  | GetValuesettingsSuccess
  | UpdateValuesettings
  | UpdateValuesettingssuccess
  | UpdateValuesettingsError;
