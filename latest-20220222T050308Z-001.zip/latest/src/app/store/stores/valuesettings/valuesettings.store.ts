import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from '../..';
import { Valuesettings } from 'src/app/_services/valuesettings.service';
import { ValuesettingsTypes, Union } from './valuesettings.actions';

export interface ValuesettingState {
  loading: boolean;
  entities: Valuesettings[];
  creating: boolean;
  created: boolean;
  updating: boolean;
  updated: boolean;
  error: boolean;
}

export const INITIAL_STATE: ValuesettingState = {
  loading: false,
  entities: [],
  creating: false,
  created: false,
  error: false,
  updating: false,
  updated: false,
};

export function ValueSettingReducer(
  state: ValuesettingState = INITIAL_STATE,
  action: Union
): ValuesettingState {
  switch (action.type) {
    
    case ValuesettingsTypes.GetValuesettings:
      return {
        ...state,
        loading: true,
      };
    case ValuesettingsTypes.GetValuesettingsSuccess:
      const valuesettings = action.payload;
      return {
        ...state,
        loading: false,
        entities: valuesettings,
      };
    case ValuesettingsTypes.GetValuesettingsError:
      const error1: boolean = action.payload;
      return {
        ...state,
        loading: false,
        error: error1,
      };
    case ValuesettingsTypes.UpdateValuesettings:
      return {
        ...state,
        updating: true,
        updated: false,
      };
    case ValuesettingsTypes.UpdateValuesettingssuccess:
      const updatedValuesettings: Valuesettings = action.payload;
      const updatedentitiesAppended = [...state.entities, updatedValuesettings];
      return {
        ...state,
        updating: false,
        entities: updatedentitiesAppended,
        updated: true,
      };
    case ValuesettingsTypes.UpdateValuesettingsError:
      return {
        ...state,
        updated: false,
        updating: false,
      };

    default:
      return state;
  }
}

export const getValuesettingState = createFeatureSelector<State, ValuesettingState>('valuesettings');

export const getValuesettingLoading = createSelector(
  getValuesettingState,
  (state) => state.loading
);

export const getValuesetting = createSelector(getValuesettingState, (state) => state.entities);

export const getValuesettingCreating = createSelector(
  getValuesettingState,
  (state) => state.creating
);

export const getValuesettingCreated = createSelector(
  getValuesettingState,
  (state) => state.created
);
export const getValuesettingUpdating = createSelector(
  getValuesettingState,
  (state) => state.updating
);

export const getValuesettingUpdated = createSelector(
  getValuesettingState,
  (state) => state.updated
);

export const getValuesettingError = createSelector(
  getValuesettingState,
  (state) => state.error
);
