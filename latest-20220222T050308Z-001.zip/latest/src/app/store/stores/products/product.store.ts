import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Role } from '../../../_services/roles/role.service';

import { State } from '../..';

import { Product } from 'src/app/_services/products/product.service';
import { ProductTypes, Union } from './product.actions';

export interface ProductState {
  loading: boolean;
  entities: Product[];
  creating: boolean;
  created: boolean;
  updating: boolean;
  updated: boolean;
  error: boolean;
}

export const INITIAL_STATE: ProductState = {
  loading: false,
  entities: [],
  creating: false,
  created: false,
  error: false,
  updating: false,
  updated: false,
};

export function ProductReducer(
  state: ProductState = INITIAL_STATE,
  action: Union
): ProductState {
  switch (action.type) {
    
    case ProductTypes.GetProducts:
      return {
        ...state,
        loading: true,
      };
    case ProductTypes.GetProductsSuccess:
      const products = action.payload;
      return {
        ...state,
        loading: false,
        entities: products,
      };
    case ProductTypes.GetProductsError:
      const error1: boolean = action.payload;
      return {
        ...state,
        loading: false,
        error: error1,
      };
    case ProductTypes.CreateProduct:
      return {
        ...state,
        creating: true,
        created: false,
      };
    case ProductTypes.CreateProductsuccess:
      const createdProduct: Product = action.payload;
      const entitiesAppended = [...state.entities, createdProduct];
      return {
        ...state,
        creating: false,
        entities: entitiesAppended,
        created: true,
      };
    case ProductTypes.UpdateProduct:
      return {
        ...state,
        updating: true,
        updated: false,
      };
    case ProductTypes.UpdateProductsuccess:
      const updatedProduct: Product = action.payload;
      const updatedentitiesAppended = [...state.entities, updatedProduct];
      return {
        ...state,
        updating: false,
        entities: updatedentitiesAppended,
        updated: true,
      };
    case ProductTypes.UpdateProductError:
      return {
        ...state,
        updated: false,
        updating: false,
      };
    case ProductTypes.CreateProductError:
      return {
        ...state,
        creating: false,
        created: false,
      };

    default:
      return state;
  }
}

export const getProductState = createFeatureSelector<State, ProductState>('product');

export const getRolesLoading = createSelector(
  getProductState,
  (state) => state.loading
);

export const getProducts = createSelector(getProductState, (state) => state.entities);

export const getProductCreating = createSelector(
  getProductState,
  (state) => state.creating
);

export const getProductCreated = createSelector(
  getProductState,
  (state) => state.created
);
export const getProductUpdating = createSelector(
  getProductState,
  (state) => state.updating
);

export const getProductUpdated = createSelector(
  getProductState,
  (state) => state.updated
);

export const getProductError = createSelector(
  getProductState,
  (state) => state.error
);
