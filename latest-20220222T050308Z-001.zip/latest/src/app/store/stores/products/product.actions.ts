import { Action } from '@ngrx/store';
import { Product } from 'src/app/_services/products/product.service';

export enum ProductTypes {
  GetProducts = '[Product] GetProducts',
  GetProductsSuccess = '[Product] GetProductsSuccess',
  GetProductsError = '[Product] GetProductsError',
  CreateProduct = '[Product] CreateProduct',
  CreateProductsuccess = '[Product] CreateProductsuccess',
  CreateProductError = '[Product] CreateProductError',
  UpdateProduct = '[Product] UpdateProduct',
  UpdateProductsuccess = '[Product] UpdateProductsuccess',
  UpdateProductError = '[Product] UpdateProductError',
}

export class GetProducts implements Action {
  readonly type = ProductTypes.GetProducts;
  constructor() {
    console.log("prodcuts Action")
  }
}

export class GetProductsSuccess implements Action {
  readonly type = ProductTypes.GetProductsSuccess;
  constructor(readonly payload: Product[]) {}
}
export class GetProductsError implements Action {
  readonly type = ProductTypes.GetProductsError;
  constructor(readonly payload: boolean) {}
}

export class CreateProduct implements Action {
  readonly type = ProductTypes.CreateProduct;
  constructor(readonly payload: Product) {}
}

export class CreateProductsuccess implements Action {
  readonly type = ProductTypes.CreateProductsuccess;
  constructor(readonly payload: Product) {}
}

export class CreateProductError implements Action {
  readonly type = ProductTypes.CreateProductError;
}
export class UpdateProduct implements Action {
  readonly type = ProductTypes.UpdateProduct;
  constructor(readonly payload: Product) {}
}

export class UpdateProductsuccess implements Action {
  readonly type = ProductTypes.UpdateProductsuccess;
  constructor(readonly payload: Product) {}
}

export class UpdateProductError implements Action {
  readonly type = ProductTypes.UpdateProductError;
}

export type Union =
  | GetProducts
  | GetProductsError
  | GetProductsSuccess
  | CreateProduct
  | CreateProductsuccess
  | CreateProductError
  | UpdateProduct
  | UpdateProductsuccess
  | UpdateProductError;
