import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { from, Observable, of } from 'rxjs';
import { catchError, concatMap, exhaustMap, map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { ProductService } from 'src/app/_services/products/product.service';
import {
  CreateProduct,
  CreateProductError,
  CreateProductsuccess,
  GetProducts,
  GetProductsError,
  GetProductsSuccess,
  ProductTypes,
  UpdateProduct,
  UpdateProductError,
  UpdateProductsuccess,
} from './product.actions';

@Injectable()
export class ProductEffects {
  constructor(
    private actions: Actions,
    private productService: ProductService,
    private toastrService: ToastrService
  ) {
    console.log('Product Effect');
  }

  @Effect()
  getProducts$: Observable<Action> = this.actions.pipe(
    ofType<GetProducts>(ProductTypes.GetProducts),
    map(() => console.log('Effect Product')),
    exhaustMap(() =>
      from(this.productService.list()).pipe(
        map((payload) => {
          return new GetProductsSuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to retrieve Products', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new GetProductsError(true));
        })
      )
    )
  );

  @Effect()
  createProduct$: Observable<Action> = this.actions.pipe(
    ofType<CreateProduct>(ProductTypes.CreateProduct),
    concatMap((action) =>
      from(this.productService.create(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Product has been created.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new CreateProductsuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to create Product', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new CreateProductError());
        })
      )
    )
  );
  @Effect()
  updateProduct$: Observable<Action> = this.actions.pipe(
    ofType<UpdateProduct>(ProductTypes.UpdateProduct),
    concatMap((action) =>
      from(this.productService.update(action.payload)).pipe(
        map((payload) => {
          this.toastrService.success(
            'The Product has been updated.',
            'Success...',
            {
              timeOut: 3000,
              positionClass: 'toast-bottom-center',
            }
          );
          return new UpdateProductsuccess(payload);
        }),
        catchError((err) => {
          this.toastrService.error('Failed to update Product', 'Error...', {
            timeOut: 3000,
            positionClass: 'toast-bottom-center',
          });
          return of(new UpdateProductError());
        })
      )
    )
  );
}
