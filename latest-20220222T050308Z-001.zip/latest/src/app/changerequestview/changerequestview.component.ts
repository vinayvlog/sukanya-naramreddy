import { Component, OnInit } from '@angular/core';
import { conference, organisation } from '../_models';
import { OrganisationService } from '../_services/organisation.service';
import { State, Store } from '../store';
import { Product } from '../_services/products/product.service';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import { ConferenceService } from '../_services/conference.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
    selector: 'app-changerequestview',
    templateUrl: './changerequestview.component.html',
    styleUrls: ['./changerequestview.component.scss'],
  })
  export class ChangeRequestView implements OnInit {
  products: Product[] = [];
  orgId: number = 0;
  buId: number = 0;
  orgData: organisation[] = [];
  codeGroups: any = [];
  cities: any = [];
  guidelines: any = [];
  productId: number = 0;
  getAllConference: any = [];
  conferences: any[] = [];
  conference: conference = <conference>{};
  displayRegister: boolean = false;
  TodaysDate:boolean= true;
  CRSubmittedDateFrom:any;
  CRSubmittedDateTo:any
  CRStatus:number=0
  crId:number
  ConfrenceDate:any
  selectedProdcucts: any = [];
  today: any = new Date();
  Requestor:any
    constructor(
      private orgService: OrganisationService,
      private store: Store<State>,
      private conferenceService: ConferenceService,
      private router: Router,
      public datepipe: DatePipe
    ) {
      }

      ngOnInit(): void {
        this.ConfrenceDate = this.datepipe.transform(this.today, 'yyyy-MM-dd');
    
        let obj ={
          PageNo:1,
          PageSize:1000,
         

        }
        this.loadCOnferenceData(obj);
        this.loadOrganisation();
        this.loadcodeWithGroup();
        this.loadProductsData();
        this.loadcodeWithCities();
        this.loadcodeWithGuildelines();
      }

      loadCOnferenceData(obj) {
        
        this.conferenceService.crListView(obj).then((result) => {
          this.getAllConference = result;
          this.conferences = this.getAllConference.conferences;
        });
      }
      loadOrganisation() {
        this.orgService.getOrgData().then((result) => {
          this.orgData = result;
          this.orgData = this.orgData.filter((item) => item.status)
        });
      }
      loadcodeWithGroup() {
        this.orgService.getcodeWithGroup(11).then((result) => {
          this.codeGroups = result;
          this.codeGroups = this.codeGroups.filter((item)=>item.status)
          this.buId = this.codeGroups[0].id
        });
      }
      loadcodeWithCities() {
        this.orgService.getcodeWithGroup(2).then((result) => {
          this.cities = result;
        });
      }
      loadcodeWithGuildelines() {
        this.orgService.getcodeWithGroup(5).then((result) => {
          this.guidelines = result;
        });
      }
      loadProductsData() {
        this.store.dispatch(new GetProducts());
        this.store.select(getProducts).subscribe((data) => {
          this.products = data;
          this.products = this.products.filter((item)=>item.status)
        });
      }
      getDetailsPage(id: any) {
        this.router.navigateByUrl('/home/marketing-admin/' + id);
      }
      register() {
        this.displayRegister = true;
        this.conference.organizationId = 0;
        this.conference.cityId = 0;
      }
    
      search(){
        let ProductIds = [];
        let BUIds = [];
        if (this.selectedProdcucts.length > 0) {
          this.selectedProdcucts.forEach((item) => {
            ProductIds.push(item.id);
          });
        }
        if (this.buId > 0) {
          BUIds.push(this.buId);
        }
        let obj ={
          CRStatus:this.CRStatus,
          OrganizationId:this.orgId,
          TodaysDate:this.TodaysDate,
          PageNo:1,
          PageSize:1000,
          Requestor:this.Requestor,
          ConfrenceDate:this.ConfrenceDate,
          CRSubmittedDateFrom:this.CRSubmittedDateFrom,
          CRSubmittedDateTo:this.CRSubmittedDateTo,
          CRId:this.crId,
          ProductIds:ProductIds,
          
        }

        obj = this.clean(obj);
        this.loadCOnferenceData(obj);
      }
      clean(obj) {
        for (var propName in obj) {
          if (obj[propName] === null || obj[propName] === undefined || obj[propName] === 0) {
            delete obj[propName];
          }
        }
        return obj
      }
      cancelCR(id){
        this.conferenceService.cancelCR(id).then((data)=>{
          let obj ={
            PageNo:1,
            PageSize:1000
          }
          this.loadCOnferenceData(obj);
        })
      }
  }