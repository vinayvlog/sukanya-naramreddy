export interface role {
  id: number;
  roleName: string;
  description: string;
  status: boolean;
}

export interface rolesJsonModel {
  // noOfPages:number;
  // organizations:organisation[];
}
