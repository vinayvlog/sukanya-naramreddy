export interface eventguide {
    id: number;
    title: string;
    content: string;  
    status: boolean;   
}
