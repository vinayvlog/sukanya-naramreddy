export interface conference {
  id: 0;
  conferenceName: string;
  fileName: string;
  venue: string;
  organizationId: any;
  cityId: 0;
  noOfPeople: 0;
  startDate: any;
  endDate: any;
  time: any;
  status: 0;
  codesCity: {};
  organization: {};
  statusName: string;
  city: string;
  organizationName: string;
  booths: [];
  banners: [];
  advertisements: [];
  babCommons: babCommon[];
  registeredBy: string;
  conferenceId: any;
}
export interface conferenceCR {
  id: 0;
  crConferenceName: string;
  crVenue: string;
  crOrganizationId: 0;
  crCityId: 0;
  crNoOfPeople: 0;
  crStartDate: any;
  crEndDate: any;
  crTime: string;
  crIsDeleted: boolean;
  remark: string;
  crDate: any;
  approvedBy: 0;
  crFileName: string;
  remarkDate: any;
  type: 0;
  crStatus: 0;
  conferenceStatus: 0;
}
export interface boothCR {
  id: 0;
  crProductId: 0;
  crExpectedAmount: 0;
  crExpectedPaymentDate: any;
  crActualAmount: 0;
  crActualPaymentDate: any;
  crePay: string;
  crUserId: 0;
  crIsDeleted: boolean;
  remark: string;
  crDate: any;
  crFileName: string;
  remarkDate: any;
  type: 0;
  crStatus: 0;
}
export interface bannerCR {
  id: 0;
  crConferenceId: 0;
  crProductId: 0;
  crUrlOfSite: string;
  crStartDate: any;
  crEndDate: any;
  crExpectedPaymentDate: any;
  crExpectedAmount: 0;
  crActualAmount: 0;
  crActualPaymentDate: any;
  crePay: string;
  crUserId: 0;
  crIsDeleted: boolean;
  remark: string;
  crDate: any;
  crFileName: string;
  remarkDate: any;
  type: 0;
}
export interface addCR {
  id: 0;
  conferenceId: any;
  oldAdvertisementId: 0;
  crId: 0;
  productId: 0;
  adTypeId: 0;
  noOfAd: 0;
  expectedAmount: 0;
  expectedPaymentDate: any;
  actualAmount: 0;
  actualPaymentDate: any;
  ePayCode: any;
  userId: 0;
  isDeleted: true;
  remark: any;
  crDate: any;
  fileName: any;
  remarkDate: any;
  type: 0;
  crStatus: 0;
}
export interface conditionalSearchGet {
  checkBoxes: checkbox[];
  categories: [];
  searchType: [];
}
export interface checkbox {
  name: string;
  value: string;
  checked: boolean
}

export interface babCommon {
  checked: false;
  id: 0;
  category: string;
  conferenceId: 0;
  productId: 0;
  expectedAmount: 0;
  expectedPaymentDate: any;
  actualAmount: 0;
  actualPaymentDate: any;
  ePay: any;
  userId: 0;
  status: 0;
  isDeleted: false;
  productName: string;
  statusName: string;
  approvedBy: string;
  conferenceName: any;
}
export interface Booth {
  id: 0;
  conferenceId: any;
  productId: 0;
  expectedAmount: 0;
  expectedPaymentDate: any;
  actualAmount: 0;
  actualPaymentDate: any;
  reportDate: any;
  krpiaReportDate: any;
  fileName: string;
  ePay: string;
  userId: 0;
  isDeleted: any;
  statusName: any;
}
export interface OnlineAdd {
  id: 0;
  conferenceId: any;
  productId: 0;
  expectedAmount: 0;
  expectedPaymentDate: any;
  actualAmount: 0;
  actualPaymentDate: any;
  reportDate: any;
  krpiaReportDate: any;
  fileName: string;
  ePay: string;
  userId: 0;
  remarkDate: any;
  isDeleted: any;
  statusName: any;
}
export interface Banner {
  id: 0;
  conferenceId: any;
  fileName: string;
  productId: 0;
  urlOfSite: string;
  startDate: any;
  endDate: any;
  expectedPaymentDate: any;
  expectedAmount: 0;
  actualAmount: 0;
  actualPaymentDate: any;
  ePay: string;
  userId: 0;
  isDeleted: any;
  statusName: any;
}
export interface Advertisement {
  id: 0;
  conferenceId: any;
  productId: 0;
  adTypeId: 0;
  noOfAd: 0;
  expectedAmount: 0;
  expectedPaymentDate: any;
  actualAmount: 0;
  actualPaymentDate: any;
  ePay: string;
  reportDate: any;
  krpiaReportDate: any;
  fileName: string;
  userId: 0;
  isDeleted: false;
  statusName: any;
}
