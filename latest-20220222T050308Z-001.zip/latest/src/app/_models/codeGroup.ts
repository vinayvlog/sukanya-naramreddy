export interface codewithgroup {
  id: number;
  name: string;
  description: string;
  serialNumber: number;
  codeGroupId: number;
  status: boolean;
  }
