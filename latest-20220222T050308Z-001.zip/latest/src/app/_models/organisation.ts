export interface organisation {
    id: number;
    organizationName: string;
    type: string;
    remarks: string;
    status: boolean;   
    organizationTypeId:number;
}

export interface organisationJsonModel {
    noOfPages:number;
    organizations:organisation[]; 
}


