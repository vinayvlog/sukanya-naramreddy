export interface errormanagement {
    id: number;
    title: string;
    content: string;  
    status: boolean;   
    errorCode:string;
}
