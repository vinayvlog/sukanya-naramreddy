import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  Advertisement,
  Banner,
  Booth,
  conference,
  OnlineAdd,
} from '../_models';
import { ConferenceService } from '../_services/conference.service';
import { OrganisationService } from '../_services/organisation.service';
import { State, Store } from '../store';
import { Product } from '../_services/products/product.service';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import { User, UserService } from '../_services/users/user.service';
import { GetUsers } from '../store/stores/users/users.actions';
import { getUsers } from '../store/stores/users/users.store';
import { throwError } from 'rxjs';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { APP_DI_CONFIG } from '../app-config.modules';
import { EventGuideService } from '../_services/eventguide.service';

@Component({
  selector: 'app-pm-conference-details',
  templateUrl: './pm-conference-details.component.html',
  styleUrls: ['./pm-conference-details.component.scss'],
})
export class PmConferenceDetailsComponent implements OnInit {
  conference: conference = <conference>{};
  guidelines: any = [];
  products: Product[] = [];
  displayBooth: boolean = false;
  displayBanner: boolean = false;
  displayAdd: boolean = false;
  displayOnlineAdd: boolean = false;
  displayDelete: boolean = false;
  booth: Booth = <Booth>{};
  onlineAdd: OnlineAdd = <OnlineAdd>{};
  banner: Banner = <Banner>{};
  advertisement: Advertisement = <Advertisement>{};
  verifedData: any = [];
  usersAll: any;
  addTypes: any = [];
  users: User[] = [];
  today: any = new Date();
  displayRegister: boolean = false;
  progress: number;
  cities: any = [];
  displayViewBooth: boolean = false;
  displayViewBanner: boolean = false;
  displayViewAdd: boolean = false;
  displayErrorModel: boolean = false;
  displayApprBtns: boolean = true;
  displayRemarks: boolean = false;
  isSaveBtn: boolean = false;
  DeleteComment:any;
  filePath: any;
  errorData: any = [];
  selectedcategory: any;
  @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;
  files: any[] = [];
  reason: any;
  currentUserId: number = 0;
  currentUser: any = {};
  constructor(
    private route: ActivatedRoute,
    private conferenceService: ConferenceService,
    private orgService: OrganisationService,
    private store: Store<State>,
    private router: Router,
    public datepipe: DatePipe,
    private userService: UserService,
    private http: HttpClient,
    private eventGuideService: EventGuideService
  ) {}

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('userDetails'));
    this.currentUserId = this.currentUser.id;
    this.today = this.datepipe.transform(this.today, 'yyyy-MM-dd');
    const id = this.route.snapshot.paramMap.get('id');
    this.conferenceService.getDetails(id).then((data) => {
      this.conference = data;
      console.log(this.conference);
      this.loadcodeWithGuildelines();
      this.loadProductsData();
      this.loadUsersData();
      this.loadAddTypes();
      this.loadcodeWithCities();
    });
  }
  loadcodeWithCities() {
    this.orgService.getcodeWithGroup(9).then((result) => {
      this.cities = result;
    });
  }
  loadAddTypes() {
    this.conferenceService.getAddTypesData().then((data) => {
      this.addTypes = data;
    });
  }
  setNoOfAdds(data) {
    this.addTypes.forEach((item) => {
      console.log('addTypes' + item.id + '' + data);
      if (item.id == data) {
        this.advertisement.noOfAd = item.noOfPages;
      }
    });
  }
  loadUsersData() {
    this.conferenceService.getUserData().then((data) => {
      this.usersAll = data;
      this.users = this.usersAll.users;
      this.users = this.users.filter((item)=> item.roleName==='PM')
    });
  }

  loadConferenceData() {
    const id = this.route.snapshot.paramMap.get('id');
    this.conferenceService.getDetails(id).then((data) => {
      this.conference = data;
    });
  }
  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
    });
  }
  getPrevPage() {}
  loadcodeWithGuildelines() {
    this.eventGuideService.geteventData().then((result) => {
      this.guidelines = result;
    });
  }
  boothModel() {
    this.conferenceService
      .validateBoothCreation(this.conference.id)
      .then((data) => {
        this.errorData = data;
        if (this.errorData.length > 0) {
          this.displayErrorModel = true;
        } else {
          this.displayBooth = true;
          this.booth.id = 0;
          this.booth.productId = 0;
          this.booth.userId = 0;
          this.booth.expectedAmount = null;
          this.booth.actualAmount = 0;
          this.booth.expectedPaymentDate = null;
          this.booth.actualPaymentDate= undefined;
          this.booth.ePay= null;
          this.files = []
        }
      });
  }
  bannerModel() {
    this.banner.conferenceId = this.conference.id;
    // this.conferenceService.validateBannerCreation(this.banner).then((data) => {
    //   this.errorData = data;
    //   if (this.errorData.length > 0) {
    //     this.displayErrorModel = true;
    //   } else {
    //     this.displayBanner = true;
    //     this.banner.productId = 0;
    //     this.banner.userId = 0;
    //     this.banner.id = 0;
    //   }
    // });
    this.displayBanner = true;
    this.banner.productId = 0;
    this.banner.userId = 0;
    this.banner.id = 0;
    this.banner.urlOfSite = '';
    this.banner.ePay = '';
    this.banner.expectedAmount=null
    this.banner.actualAmount = 0;
    this.banner.expectedPaymentDate = null;
    this.banner.actualPaymentDate= undefined;
    this.banner.startDate = null;
    this.banner.endDate= null;
    this.files = []
  }
  showRemarks(data) {
    this.displayRemarks = true;
    this.DeleteComment = data.deleteComment
  }
  addModel() {
    this.displayAdd = true;
    this.advertisement.id = 0;
    this.advertisement.productId = 0;
    this.advertisement.userId = 0;
    this.advertisement.adTypeId = 0;
    this.advertisement.expectedAmount=null
    this.advertisement.actualAmount = 0;
    this.advertisement.expectedPaymentDate = null;
    this.advertisement.actualPaymentDate= undefined;
    this.advertisement.noOfAd = null;
    this.files = []
  }
  saveBooth() {
    this.booth.conferenceId = this.route.snapshot.paramMap.get('id');
    if (this.booth.id > 0) {
      if (this.booth.actualAmount == 0) {
        alert('Enster Actual Amount');
      } else if (!this.booth.actualPaymentDate) {
        alert('Select Actual Pay Date');
      } else if (!this.booth.ePay) {
        alert('Enster E-pay code');
      } else if (this.booth.actualAmount!=this.booth.expectedAmount) {
        alert('Expected Amount and Actual Amount should be same');
      }
       else {
        this.updateBoothData();
      }
    } else {
      if (this.booth.productId == 0) {
        alert('Select a Product');
      } else if (!this.booth.expectedAmount) {
        alert('Enter Expected Amount');
      } else if (!this.booth.expectedPaymentDate) {
        alert('Select Expected Pay Date');
      } else if (this.booth.userId === 0) {
        alert('Select PM User');
      } else {
        this.saveBoothData();
      }
    }
  }
  saveBoothData() {
    this.conferenceService.validateBooth(this.booth).then((data) => {
      this.errorData = data;
      if (this.errorData.length > 0) {
        this.displayErrorModel = true;
      } else {
        this.conferenceService.saveBoothData(this.booth).then((data) => {
          if (this.files.length > 0) {
            this.uploadFile('booth', data.id);
          }
          this.loadConferenceData();
          this.displayBooth = false;
        });
      }
    });
  }

  view(item: any) {
    this.selectedcategory = { ...item };
    if (item.category === 'Banner') {
      this.conferenceService.getBannerDetails(item.id).then((data) => {
        this.banner = { ...data };
        this.displayViewBanner = true;
      });
    } else if (item.category === 'Booth') {
      this.conferenceService.getBoothDetails(item.id).then((data) => {
        this.booth = { ...data };
        this.displayViewBooth = true;
      });
    } else {
      this.conferenceService.getAddDetails(item.id).then((data) => {
        this.advertisement = { ...data };
        this.displayViewAdd = true;
      });
    }
  }
  edit(item: any) {
    if (item.category === 'Banner') {
      this.conferenceService.getBannerDetails(item.id).then((data) => {
        this.banner = { ...data };
        this.displayViewBanner = false;
        this.displayBanner = true;
      });
    } else if (item.category === 'Booth') {
      this.conferenceService.getBoothDetails(item.id).then((data) => {
        this.booth = { ...data };
        this.displayViewBooth = false;
        this.displayBooth = true;
      });
    } else if (item.category === 'Online Advertisement') {
      this.conferenceService.getOnlineAddDetails(item.id).then((data) => {
        this.onlineAdd = { ...data };
        this.displayOnlineAdd = true;
        // this.displayBooth = true;
      });
    } else {
      this.conferenceService.getAddDetails(item.id).then((data) => {
        this.advertisement = { ...data };
        this.displayViewAdd = false;
        this.displayAdd = true;
      });
    }
  }
  updateBoothData() {
    this.conferenceService.updateBoothData(this.booth).then((data) => {
      this.displayBooth = false;
      if (this.files.length > 0) {
        this.uploadFile('booth', this.booth.id);
      }
      this.loadConferenceData();
    });
  }

  saveBanner() {
    this.banner.conferenceId = this.route.snapshot.paramMap.get('id');
    if (this.banner.id > 0) {
      if (this.banner.actualAmount == 0) {
        alert('Enster Actual Amount');
      } else if (!this.banner.actualPaymentDate) {
        alert('Select Actual Pay Date');
      } else if (!this.banner.ePay) {
        alert('Enster E-pay code');
      } else if (this.banner.actualAmount!=this.banner.expectedAmount) {
        alert('Actual Amount and Expected Amount should be same');
      } 
      else {
        this.updateBannerData();
      }
    } else {
      if (this.banner.productId == 0) {
        alert('Select a Product');
      } else if (!this.banner.urlOfSite) {
        alert('Enter URL of site');
      } else if (!this.banner.startDate) {
        alert('Select Start Date');
      } else if (!this.banner.endDate) {
        alert('Select End Date');
      } else if (!this.banner.expectedPaymentDate) {
        alert('Select Expected Pay Date');
      } else if (!this.banner.expectedAmount) {
        alert('Enter Expected Amount');
      } else if (this.banner.userId === 0) {
        alert('Select PM User');
      } else {
        this.saveBannerData();
      }
    }
  }
  verify() {
    this.banner.conferenceId = this.conference.id;
    this.conferenceService.validateBanner(this.banner).then((data) => {
      this.verifedData = data;
      const arrayLength = this.verifedData.filter(
        (item) => !item.result
      ).length;
      if (arrayLength > 0) {
        this.isSaveBtn = false;
      } else {
        this.isSaveBtn = true;
      }
    });
  }
  saveBannerData() {
    this.conferenceService.validateBanner(this.banner).then((data) => {
      this.verifedData = data;
      const arrayLength = this.verifedData.filter(
        (item) => !item.result
      ).length;
      if (arrayLength > 0) {
      } else {
        this.conferenceService.saveBannerData(this.banner).then((data) => {
          if (this.files.length > 0) {
            this.uploadFile('banner', data.id);
          }
          this.loadConferenceData();
          this.displayBanner = false;
        });
      }
    });
  }
  updateBannerData() {
    this.conferenceService.updateBannerData(this.banner).then((data) => {
      this.displayBanner = false;
      if (this.files.length > 0) {
        this.uploadFile('banner', this.banner.id);
      }
      this.loadConferenceData();
    });
  }

  saveAdd() {
    this.advertisement.conferenceId = this.route.snapshot.paramMap.get('id');
    if (this.advertisement.id > 0) {
      if (this.advertisement.actualAmount == 0) {
        alert('Enster Actual Amount');
      } else if (!this.advertisement.actualPaymentDate) {
        alert('Select Actual Pay Date');
      } else if (!this.advertisement.ePay) {
        alert('Enster E-pay code');
      } else if (this.advertisement.actualAmount!=this.advertisement.expectedAmount) {
        alert('Actual Amount and Expected Amount should be same');
      }  else {
        this.updateAddData();
      }
    } else {
      this.advertisement.ePay = 'NA';
      if (this.advertisement.productId == 0) {
        alert('Select a Product');
      } else if (!this.advertisement.expectedAmount) {
        alert('Enter Expected Amount');
      } else if (!this.advertisement.expectedPaymentDate) {
        alert('Select Expected Pay Date');
      } else if (this.advertisement.userId === 0) {
        alert('Select PM User');
      } else {
        this.saveAddData();
      }
    }
  }
  saveAddData() {
    this.conferenceService
      .validateAdvertisement(this.advertisement)
      .then((data) => {
        this.errorData = data;
        if (this.errorData.length > 0) {
          this.displayErrorModel = true;
        } else {
          this.conferenceService
            .saveAdvertisementData(this.advertisement)
            .then((data) => {
              if (this.files.length > 0) {
                this.uploadFile('add', data.id);
              }
              this.loadConferenceData();
              this.displayAdd = false;
            });
        }
      });
  }
  updateAddData() {
    this.conferenceService
      .updateAdvertisementData(this.advertisement)
      .then((data) => {
        this.displayAdd = false;
        if (this.files.length > 0) {
          this.uploadFile('add', this.advertisement.id);
        }
        this.loadConferenceData();
      });
  }
  save() {
    this.displayDelete = true;
  }
  cancel() {
    this.displayDelete = false;
  }
  editConference() {
    this.conference.endDate = this.datepipe.transform(
      this.conference.endDate,
      'yyyy-MM-dd'
    );
    this.conference.startDate = this.datepipe.transform(
      this.conference.startDate,
      'yyyy-MM-dd'
    );
    this.displayRegister = true;
  }
  saveConference() {
    if (
      !this.conference.conferenceName ||
      this.conference.conferenceName == ''
    ) {
      alert('Enter Conference Name');
    } else if (!this.conference.venue || this.conference.venue == '') {
      alert('Enter Place');
    } else if (this.conference.cityId === 0) {
      alert('Select City');
    } else if (!this.conference.startDate) {
      alert('Select Start Date');
    } else if (!this.conference.endDate) {
      alert('Select End Date');
    } else if (this.conference.noOfPeople === 0) {
      alert('Enter No. of Attendees');
    } else if (!this.conference.time) {
      alert('Enter No. of Minutes');
    } else {
      this.conference.startDate = this.datepipe.transform(
        this.conference.startDate,
        'yyyy-MM-dd'
      );
      this.conference.endDate = this.datepipe.transform(
        this.conference.endDate,
        'yyyy-MM-dd'
      );
      this.conference.organizationId = parseInt(this.conference.organizationId);
      this.conferenceService
        .updateConference(this.conference)
        .then((data) => {
          if (this.files.length > 0) {
            this.uploadFile('conference', this.conference.id);
          }
          this.loadConferenceData();
          this.displayRegister = false;
        })
        .catch((error) => {});
    }
  }
  onFileDropped($event) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile(index: number) {
    this.files = [];
  }

  /**
   * Simulate the upload process
   */
  uploadFile(type: any, id) {
    this.progress = 10;
    const formData = new FormData();
    formData.append('file', this.files[0]);
    let path = '';
    if (type == 'conference') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadFileConference +
        '?id=' +
        id;
    } else if (type == 'booth') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadBoothFile +
        '?id=' +
        id;
    } else if (type == 'banner') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadBannerFile +
        '?id=' +
        id;
    } else if (type == 'add') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadAdvertisementFile +
        '?id=' +
        id;
    } else if (type == 'onlineAdd') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadOnlineAdd +
        '?id=' +
        id;
    }

    this.http
      .put(path, formData, {
        reportProgress: true,
        observe: 'events',
      })
      .pipe(
        map((event: any) => {
          if (event.type == HttpEventType.UploadProgress) {
            this.progress = Math.round((100 / event.total) * event.loaded);
          } else if (event.type == HttpEventType.Response) {
            this.files = [];
            this.progress = null;
          }
        }),
        catchError((err: any) => {
          alert(err.message);
          return throwError(err.message);
        })
      )
      .toPromise();
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      item.progress = 0;

      this.files[0] = item;
    }
    this.fileDropEl.nativeElement.value = '';
    //  this.uploadFilesSimulator(0);
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  download(filename: any) {
    const path =
      APP_DI_CONFIG.parentDomain +
      APP_DI_CONFIG.apiEndPoint +
      APP_DI_CONFIG.endPoints.contenferance.confereceFileDownload +
      '?fileName=' +
      this.conference.fileName;
    window.open(path, '_blank');
  }
  deleteAdd() {
    if (this.displayAdd) {
      let obj = {
        id: this.advertisement.id,
        deleteComment: this.reason,
      };
      this.conferenceService.deleteAdd(obj).then((data) => {
        this.displayDelete = false;
        this.displayAdd = false;
      });
    } else if (this.displayBooth) {
      let obj = {
        id: this.booth.id,
        deleteComment: this.reason,
      };
      this.conferenceService.deleteBooth(obj).then((data) => {
        this.displayDelete = false;
        this.displayBooth = false;
      });
    } else if (this.displayBanner) {
      let obj = {
        id: this.banner.id,
        deleteComment: this.reason,
      };
      this.conferenceService.deleteBanner(obj).then((data) => {
        this.displayDelete = false;
        this.displayBanner = false;
      });
    } else if (this.displayOnlineAdd) {
      let obj = {
        id: this.onlineAdd.id,
        deleteComment: this.reason,
      };
      this.conferenceService.deleteOnlineADD(obj).then((data) => {
        this.displayDelete = false;
        this.displayOnlineAdd = false;
      });
    }
  }
  changeRequest() {
    this.router.navigateByUrl('/home/viewchangerequest/' + this.conference.id);
  }
  onlineAddModel() {
    this.conferenceService
      .validateOnlineAddCreation(this.conference.id)
      .then((data) => {
        this.errorData = data;
        if (this.errorData.length > 0) {
          this.displayErrorModel = true;
        } else {
          this.displayOnlineAdd = true;
          this.onlineAdd.id = 0;
          this.onlineAdd.productId = 0;
          this.onlineAdd.userId = 0;
          this.onlineAdd.expectedAmount = null;
          this.onlineAdd.actualAmount = 0;
          this.onlineAdd.expectedPaymentDate = null;
          this.onlineAdd.actualPaymentDate= undefined;
          this.onlineAdd.ePay= null;
          this.files = []
        }
      });
  }
  saveOnlineAdd() {
    this.onlineAdd.conferenceId = this.route.snapshot.paramMap.get('id');
    if (this.onlineAdd.id > 0) {
      if (this.onlineAdd.actualAmount == 0) {
        alert('Enster Actual Amount');
      } else if (!this.onlineAdd.actualPaymentDate) {
        alert('Select Actual Pay Date');
      } else if (!this.onlineAdd.ePay) {
        alert('Enster E-pay code');
      } else if (this.onlineAdd.actualAmount!=this.onlineAdd.expectedAmount) {
        alert('Actual Amount and Expected Amount should be same');
      } else {
        this.updateOnlineAdd();
      }
    } else {
      if (this.onlineAdd.productId == 0) {
        alert('Select a Product');
      } else if (!this.onlineAdd.expectedAmount) {
        alert('Enter Expected Amount');
      } else if (!this.onlineAdd.expectedPaymentDate) {
        alert('Select Expected Pay Date');
      } else if (this.onlineAdd.userId === 0) {
        alert('Select PM User');
      } else {
        this.saveOnlineAddData();
      }
    }
  }
  updateOnlineAdd() {
    this.conferenceService.updateOnlineAdd(this.onlineAdd).then((data) => {
      this.displayOnlineAdd = false;
      if (this.files.length > 0) {
        this.uploadFile('onlineAdd', this.onlineAdd.id);
      }
      this.loadConferenceData();
    });
  }
  saveOnlineAddData() {
    this.conferenceService.validateOnlineAdd(this.onlineAdd).then((data) => {
      this.errorData = data;
      if (this.errorData.length > 0) {
        this.displayErrorModel = true;
      } else {
        this.conferenceService  
          .saveOnilneAddData(this.onlineAdd)
          .then((data) => {
            if (this.files.length > 0) {
              this.uploadFile('onlineAdd', data.id);
            }
            this.loadConferenceData();
            this.displayOnlineAdd = false;
          });
      }
    });
  }

  boothApproval() {
    this.conferenceService.boothApproval(this.booth.id).then((data) => {
      this.loadConferenceData();
      this.displayBooth = false;
    });
  }
  bannerApproval() {
    this.conferenceService.bannerApproval(this.banner.id).then((data) => {
      this.loadConferenceData();
      this.displayBanner = false;
    });
  }
  addApproval() {
    this.conferenceService.addApproval(this.advertisement.id).then((data) => {
      this.loadConferenceData();
      this.displayAdd = false;
    });
  }
  onlineAddApproval() {
    this.conferenceService.onlineAddApproval(this.onlineAdd.id).then((data) => {
      this.loadConferenceData();
      this.displayOnlineAdd = false;
    });
  }

  fileDownload(item: any) {
    if (item.category === 'Banner') {
      const path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.downloadBanner +
        '?fileName=' +
        item.fileName;
      window.open(path, '_blank');
    } else if (item.category === 'Booth') {
      const path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.downloadBooth +
        '?fileName=' +
        item.fileName;
      window.open(path, '_blank');
    } else if (item.category === 'Online Advertisement') {
      const path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.downloadOnlineAdd +
        '?fileName=' +
        item.fileName;
      window.open(path, '_blank');
    } else {
      const path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.downloadAdd +
        '?fileName=' +
        item.fileName;
      window.open(path, '_blank');
    }
  }
}
