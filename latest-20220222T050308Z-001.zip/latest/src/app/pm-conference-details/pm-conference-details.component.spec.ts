import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmConferenceDetailsComponent } from './pm-conference-details.component';

describe('PmConferenceDetailsComponent', () => {
  let component: PmConferenceDetailsComponent;
  let fixture: ComponentFixture<PmConferenceDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmConferenceDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmConferenceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
