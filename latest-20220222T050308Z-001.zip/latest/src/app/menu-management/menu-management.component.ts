import { Component, OnInit } from '@angular/core';
import {
  Menumanagement,
  MenumanagementService,
} from '../_services/menumanagement/menumanagement.service';
import { State, Store } from '../store';
import { Subject } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../_services/users/user.service';
import { Role, RoleService } from '../_services/roles/role.service';

@Component({
  selector: 'app-menu-management',
  templateUrl: './menu-management.component.html',
  styleUrls: ['./menu-management.component.scss'],
})
export class MenuManagementComponent implements OnInit {
  menumanagements: Menumanagement[] = [];
  menumanagement: Menumanagement = <Menumanagement>{};
  menuList: any = [];
  displayBasic: boolean;
  private readonly destroy = new Subject<void>();
  display: boolean = false;
  groups: Role[] = [];
  usergroup: User[] = [];
  submenu: submenu = <submenu>{};
  selectedGroups: Role[] = [];
  parentMenu:any

  constructor(
    private store: Store<State>,
    private route: ActivatedRoute,
    private menumanagementService: MenumanagementService,
    private roleService: RoleService
  ) {}

  ngOnInit(): void {
    this.loadMenumanagementData();
    this.loadUserGroup();
  }
  loadMenumanagementData() {
    this.menumanagementService.list().subscribe((data) => {
      this.menuList = data;
    });
  }
  loadUserGroup() {
    this.roleService.list().subscribe((data) => {
      this.groups = data;
    });
  }

  showBasicDialog() {
    this.submenu.roles.forEach((item1) =>{
      this.selectedGroups.push(this.groups.find((item)=>item.id ===item1))
    })
    this.displayBasic = true;
  }
  getsubmenu(item) {
    console.log(item);
    this.submenu = item;
    this.parentMenu = this.menuList.find((item)=>item.id===this.submenu.parentMenuId).name
  }
  getMainMenu(item){
    this.submenu = item;
  }
  roleSelect(ev) {
    this.selectedGroups = ev.value
  }
  updateMenu() {
    let ids = [];
    if (this.selectedGroups.length > 0) {
      this.selectedGroups.forEach((item) => {
        ids.push(item.id);
      });
    } else {
      ids = this.submenu.roles;
    }
    let data = {
      id: this.submenu.id,
      name: this.submenu.name,
      //serialNumber: this.submenu.serialNumber,
      url: this.submenu.url,
      parentMenuId: this.submenu.parentMenuId,
      status: this.submenu.isActive,
      roleList: ids,
    };
    this.menumanagementService.updatesubMneu(data).subscribe((data) => {
      if (data) {
        this.loadMenumanagementData();
        this.displayBasic = false;
      }
    });
  }
 
}
export interface submenu {
  id: 0;
  name: string;
  serialNumber: 0;
  url: string;
  parentMenuId: 0;
  isActive: boolean;
  isDeleted: boolean;
  updatedBy: 0;
  createdDate: any;
  updatedDate: any;
  roles: [];
  status:any;
}
