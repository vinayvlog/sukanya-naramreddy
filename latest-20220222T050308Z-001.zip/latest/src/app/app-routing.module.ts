import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrganisationComponent } from './organisation/organisation.component';
import { EventguideComponent } from './eventguide/eventguide.component';
import { ErrormessagemnmgtComponent } from './errormessagemnmgt/errormessagemnmgt.component';
import { UsersComponent } from './user-management/users/users.component';
import { CodeManagementComponent } from './code-management/code-management/code-management.component';
import { NotificationManagementComponent } from './notification-management/notification-management.component';
import { AccessManagementComponent } from './access-management/access-management/access-management.component';
import { ProductManagementComponent } from './product-management/product-management.component';
import { MenuManagementComponent } from './menu-management/menu-management.component';
import { MenuComponent } from './_shared/menu/menu.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { AuthManagementComponent } from './auth-management/auth-management.component';
import { ValueSettingsComponent } from './value-settings/value-settings.component';
import { HomepageComponent } from './homepage/homepage.component';

import { NotificationComponent } from './notification/notification.component';
import { MarketingAdminComponent } from './marketing-admin/marketing-admin.component';
import { ConferenceDetailsComponent } from './conference-details/conference-details.component';
import { ChangeRequestView } from './changerequestview/changerequestview.component';
import { ViewChangeRequest } from './viewchangerequest/viewchangerequest.component';
import { ChangeRequestApproval } from './changerequestapproval/changerequestapproval.component';
import { ViewChangeRequestApproval } from './viewchangerequestapproval/viewchangerequestapproval.component';
import { ConditionalSearchComponent } from './conditionalsearch/conditionalsearch.component';
import { KRPIAReportComponent } from './KRPIA_report/krpia_report.component';
import { OtherEventsComponent } from './other_events/otherevents.component';
import { ViewOtherEventsComponent } from './view-other-events/view-other-events.component';
import { PmEventsComponent } from './pm-events/pm-events.component';
import { LoginComponent } from './login/login.component';
import { PmConferenceDetailsComponent } from './pm-conference-details/pm-conference-details.component';
import { CrViewComponent } from './cr-view/cr-view.component';
import { ChangeRequestApprovalViewComponent } from './change-request-approval-view/change-request-approval-view.component';
import { EventSearchComponent } from './event-search/event-search.component';
import { EventSearchViewComponent } from './event-search-view/event-search-view.component';
// const routes: Routes = [
//   { path: 'home', component: LayoutComponent, children: [
//   { path: 'organisation', component: OrganisationComponent },
//   { path: 'eventguide', component: EventguideComponent },
//   { path: 'errormsgmgmt', component: ErrormessagemnmgtComponent },
//   { path: 'user-management', component:UsersComponent},
//   { path: 'code-management', component:CodeManagementComponent},
//   { path: 'notification-management', component:NotificationManagementComponent},
//   { path: 'access-management', component:AccessManagementComponent},
//   { path: 'product-management', component:ProductManagementComponent},
//   { path: 'menu-management', component:MenuManagementComponent}
// ]];

const routes: Routes = [
  { path: '', redirectTo: '/auth/login', pathMatch: 'full' },
  {
    path: 'home',
    component: MenuComponent,
    children: [
      { path: 'organisation', component: OrganisationComponent },
      { path: 'eventguide', component: EventguideComponent },
      { path: 'errormsgmgmt', component: ErrormessagemnmgtComponent },
      { path: 'user-management', component: UsersComponent },
      { path: 'code-management', component: CodeManagementComponent },
      {
        path: 'notification-management',
        component: NotificationManagementComponent,
      },
      { path: 'access-management', component: AccessManagementComponent },
      { path: 'product-management', component: ProductManagementComponent },
      { path: 'menu-management', component: MenuManagementComponent },
      { path: 'values-settings', component: ValueSettingsComponent },
      { path: 'home-page', component: HomepageComponent },
      { path: 'notification', component: NotificationComponent },
      { path: 'marketing-admin', component: MarketingAdminComponent },
      { path: 'marketing-admin/:id', component: ConferenceDetailsComponent },
      { path: 'changerequestview', component: ChangeRequestView },
      { path: 'changerequestview/:id', component: CrViewComponent },
      { path: 'viewchangerequest/:id', component: ViewChangeRequest },
      { path: 'changerequestapproval', component: ChangeRequestApproval },
      { path: 'changerequestapproval/:id', component: ChangeRequestApprovalViewComponent },
      { path: 'viewchangerequestapproval', component: ViewChangeRequestApproval },
      { path: 'conditionalsearch', component: ConditionalSearchComponent },
      { path: 'krpia_report', component: KRPIAReportComponent },
      { path: 'other-events', component: OtherEventsComponent },
      { path: 'view-other-events', component: ViewOtherEventsComponent },
      { path: 'pm-events', component: PmEventsComponent },
      { path: 'pm-events/:id', component: PmConferenceDetailsComponent },
      { path: 'event-search', component: EventSearchComponent },
      { path: 'event-search/:id', component: EventSearchViewComponent },
     
      { path: 'login', component: LoginComponent },

    ],
  },

  {
    path: 'auth',
    component: AuthManagementComponent,
    children: [
      { path: 'access-denied', component: AccessDeniedComponent },
      { path: 'user-register', component: UserRegisterComponent },
      { path: 'login', component: LoginComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
