import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../_services/users/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  fieldTextType: boolean;
  emailId: any;
  response: any;
  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {}
  toggleFieldTextType1() {
    this.fieldTextType = !this.fieldTextType;
  }
  login() {
    this.userService.login(this.emailId).subscribe(
      (data) => {
        //Next callback
        this.response = data;
        localStorage.setItem('token', this.response.jwt_token);
        localStorage.setItem('userDetails',JSON.stringify(this.response.user));
        localStorage.setItem('menuList',JSON.stringify(this.response.menuList));
        this.router.navigateByUrl('/home/home-page');

      },
      (error) => {
        //Error callback
        console.error('error caught in component');
        this.router.navigateByUrl('/auth/access-denied');
      }
    );
  }
}
