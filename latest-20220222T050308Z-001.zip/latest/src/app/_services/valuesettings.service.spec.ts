import { TestBed } from '@angular/core/testing';

import { ValuesettingsService } from './valuesettings.service';

describe('ValuesettingsService', () => {
  let service: ValuesettingsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ValuesettingsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
