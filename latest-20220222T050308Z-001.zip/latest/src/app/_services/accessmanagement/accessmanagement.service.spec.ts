import { TestBed } from '@angular/core/testing';

import { AccessmanagementService } from './accessmanagement.service';

describe('AccessmanagementService', () => {
  let service: AccessmanagementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AccessmanagementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
