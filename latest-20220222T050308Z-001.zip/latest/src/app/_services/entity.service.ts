import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

const httpOptions = {
  headers: new HttpHeaders({
    'content-type': 'application/json',
  }),
};
const httpOptions1 = {
  headers: new HttpHeaders({
    'content-type': 'multipart/form-data; boundary=----WebKitFormBoundarysQQN1x4ujek7Yb38',
  }),
};


export interface Entity {
  id?: number;
}

@Injectable({ providedIn: 'root' })
export class EntityService<T extends Entity> {
  constructor(private httpClient: HttpClient) {}

  get(url: string, id: string) {
    return this.httpClient.get<T>(`${url}/${id}`);
  }
  login(url: string) {
    return this.httpClient.get<T>(`${url}`);
  }

  list(url: string, params?: Record<string, any>) {
    return this.httpClient.get<T[]>(url, { params });
  }

  create(url: string, entity: Partial<T>) {
    return this.httpClient.post<T>(url, entity, httpOptions);
  }
  upload(url: string, entity: Partial<T>) {
    return this.httpClient.post<T>(url, entity, httpOptions);
  }

  update(url: string, entity: T) {
    return this.httpClient.put<T>(`${url}`, { ...entity }, httpOptions);
  }

  delete(url: string, id: string) {
    return this.httpClient.delete<void>(`${url}/${id}`, httpOptions);
  }
  fileUpload(url: string, entity: any) {
    return this.httpClient.put<any>(url, entity, httpOptions1);
  }
  fileDownload(url: string) {
    return this.httpClient.get<any>(url);
  }

}
