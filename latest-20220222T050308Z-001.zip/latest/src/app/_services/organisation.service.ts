import { Inject, Injectable, Injector } from '@angular/core';
import {organisation,organisationJsonModel} from './../_models/organisation';
import {HttpClient} from '@angular/common/http';
import {  APP_DI_CONFIG} from '../app-config.modules';
import { codewithgroup } from '../_models/codeGroup';

@Injectable({
  providedIn: 'root'
})
export class OrganisationService {

  constructor(private http:HttpClient) { }

  async getOrgData():Promise<organisation[]>{
    
    // let org:organisation[]=[];
    // org.push({id:1,orgname:'Korean Women doctor Association.​',orgtype:'Academic institutions or research institutes related to medical science.​',
    // remarks:'test shdbsdhjcghgsdh',status:true});
    // org.push({id:2,orgname:'Korea Herbal Cancer Management Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:false});
    // org.push({id:3,orgname:'Korean Pharmaceutical Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'432-42-65789',status:true});
    // org.push({id:4,orgname:'Korean Women doctor Association.​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:true});
    // org.push({id:5,orgname:'Korea Herbal Cancer Management Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:false});
    // org.push({id:6,orgname:'Korean Pharmaceutical Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'432-42-65789',status:true});
    // org.push({id:7,orgname:'Korean Women doctor Association.​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:true});
    // org.push({id:8,orgname:'Korea Herbal Cancer Management Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:false});
    // org.push({id:9,orgname:'Korean Pharmaceutical Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'432-42-65789',status:true});
    // org.push({id:10,orgname:'Korean Women doctor Association.​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:true});
    // org.push({id:1,orgname:'Korea Herbal Cancer Management Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:false});
    // org.push({id:1,orgname:'Korean Pharmaceutical Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'432-42-65789',status:true});
    // org.push({id:1,orgname:'Korean Women doctor Association.​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:true});
    // org.push({id:1,orgname:'Korea Herbal Cancer Management Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'test',status:false});
    // org.push({id:1,orgname:'Korean Pharmaceutical Association​',orgtype:'Academic institutions or research institutes related to medical science.​',remarks:'432-42-65789',status:true});
    let org=await this.http.get<organisationJsonModel>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.Organisation.getOrganisation+'?pageNo=1'+'&pagesize=1000').toPromise();
   // let org=await this.http.get<organisationJsonModel>('https:/localhost:44334/api/Organization/getAllOrganizations?pageNo=1&pageSize=1000').toPromise();
    let orr=org.organizations;
    
    return orr;
   }
   saveOrgData(org:organisation){     
     return this.http.post<organisation>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.Organisation.saveOrganisation,org).toPromise();

   }
   updateOrgData(org:organisation){
    return this.http.put<organisation>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.Organisation.updateOrganisation,org).toPromise();
  }
  async getcodeWithGroup(id:number):Promise<any>{
    
    let types=await this.http.get<any>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.Code.codeWithGroup+'?groupId='+id).toPromise();
    const list =types
    return list
   }
}
