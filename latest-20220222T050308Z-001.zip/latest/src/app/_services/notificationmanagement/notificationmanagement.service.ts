import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APP_DI_CONFIG } from 'src/app/app-config.modules';
import { EntityService } from '../entity.service';

export interface NotificationManagement {
  id: number;
  notificationTitle: string;
  content: string;
  code: number;
  status: boolean;
  popupStatus: boolean;
  uploadedFile?: string;
  isDeleted?: boolean;
  updatedBy?: number;
  createdDate?: string;
  updatedDate?: string;
}

@Injectable({
  providedIn: 'root'
})
export class NotificationmanagementService {

  constructor(private entitySvc: EntityService<any>) { }

  list(params?: Record<string, any>): Observable<NotificationManagement[]> {
    return this.entitySvc.list(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Notificationmanagement.getNotificationmanagement,
      params
    );
  }

  create(notificationManagement: NotificationManagement): Observable<NotificationManagement> {
    return this.entitySvc.create(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Notificationmanagement.saveNotificationmanagement,
        notificationManagement
    );
  }

  update(notificationManagement: NotificationManagement): Observable<NotificationManagement> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Notificationmanagement.updateNotificationmanagement,
      {...notificationManagement}
    );
  }
  fileUpload(file,ntId){
    return this.entitySvc.fileUpload(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Notificationmanagement.fileUpload+'?id='+ntId,
        file
    );
  }
  fileDownload(fileName){
    return this.entitySvc.fileDownload(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Notificationmanagement.fileDownload+'?fileName='+fileName
        
    );
  }
}
