import { TestBed } from '@angular/core/testing';

import { NotificationmanagementService } from './notificationmanagement.service';

describe('NotificationmanagementService', () => {
  let service: NotificationmanagementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NotificationmanagementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
