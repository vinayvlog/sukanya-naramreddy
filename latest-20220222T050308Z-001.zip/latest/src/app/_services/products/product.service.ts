import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EntityService } from '../entity.service';

import { APP_DI_CONFIG } from '../../app-config.modules';

export interface Product {
  id: number;
  productName: string;
  buId: number;
  status: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  constructor(private entitySvc: EntityService<any>) {}

  list(params?: Record<string, any>): Observable<Product[]> {
    return this.entitySvc.list(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Product.getProducts,
      params
    );
  }

  create(product: Product): Observable<Product> {
    return this.entitySvc.create(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Product.saveProduct,
      product
    );
  }

  update(product: Product): Observable<Product> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Product.updateProduct,
      {...product}
    );
  }
}
