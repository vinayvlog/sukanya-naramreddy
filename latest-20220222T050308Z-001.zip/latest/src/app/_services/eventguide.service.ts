import { Injectable } from '@angular/core';
import {eventguide} from '../_models/eventguide';
import {HttpClient, HttpParams} from '@angular/common/http';
import {  APP_DI_CONFIG} from '../app-config.modules';
import { Valuesettings } from './valuesettings.service';

@Injectable({
  providedIn: 'root'
})
export class EventGuideService {

  constructor(private http:HttpClient) { }

  async geteventData(){
       return await this.http.get<eventguide[]>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.EventGuide.getevents+'?pageNo=1'+'&pagesize=1000').toPromise();    
    
   }
  async saveEventData(event:eventguide){
    return await this.http.post<eventguide>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.EventGuide.saveevents,event).toPromise();    
   }
  async updateEventData(event:eventguide){
    return await this.http.put<eventguide>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.EventGuide.updateevents,event).toPromise();    
  }
  
  async getvalueSettingsData(params1:any){
    
    let params = new HttpParams();
    params = params.append('pageNo', params1.pageNo.toString());
    params = params.append('pageSize', params1.pageSize.toString());
    params = params.append('eventTypeId', params1.eventTypeId.toString());
    params = params.append('organizationTypeId', params1.organizationTypeId.toString());

    return await this.http.get<Valuesettings[]>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.Valuesettings.getValuesettings,{params:params}).toPromise();    
 
}
}

