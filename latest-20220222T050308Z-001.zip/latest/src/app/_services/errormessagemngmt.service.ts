import { Injectable } from '@angular/core';
import {errormanagement} from '../_models/index';
import {HttpClient} from '@angular/common/http';
import {  APP_DI_CONFIG} from '../app-config.modules';



@Injectable({
  providedIn: 'root'
})
export class ErrormessagemngmtService {

  constructor(private http:HttpClient) { }

  async getErrData(){
    // let org:errormanagement[]=[];
    // org.push({id:1,title:'Event Guide Title​',errorCode:'ttt', content:'Only the booth conditions are met_If apply for the 2nd booth, Legal Department’s approval required with a previously registered applicant.​',
    // status:true});
    
    // return org;
    return await this.http.get<errormanagement[]>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.ErrorMessage.geterrors+'?pageNo=1'+'&pagesize=1000').toPromise();    
   }
   async saveErrorData(err:errormanagement){
    return await this.http.post<errormanagement>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.ErrorMessage.saveerrors,err).toPromise();    
   }
   async updateErrorData(err:errormanagement){
    return await this.http.put<errormanagement>(APP_DI_CONFIG.parentDomain+APP_DI_CONFIG.apiEndPoint+APP_DI_CONFIG.endPoints.ErrorMessage.updateerrors,err).toPromise(); 
  }
}
