import { Injectable } from '@angular/core';
import {
  addCR,
  Advertisement,
  Banner,
  bannerCR,
  Booth,
  boothCR,
  conference,
  conferenceCR,
  OnlineAdd,
} from '../_models/index';
import { HttpClient, HttpParams } from '@angular/common/http';
import { APP_DI_CONFIG } from '../app-config.modules';
import { EntityService } from './entity.service';

@Injectable({
  providedIn: 'root',
})
export class ConferenceService {
  constructor(
    private http: HttpClient,
    private entitySvc: EntityService<any>
  ) {}

  async getConferenceData(params1) {
     return await this.http
      .get<conference[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.getAllConferences,
        { params: params1 }
      )
      .toPromise();
  }
  async crListView(params1?) {
    return await this.http
     .get<conference[]>(
       APP_DI_CONFIG.parentDomain +
         APP_DI_CONFIG.apiEndPoint +
         APP_DI_CONFIG.endPoints.changeRequest.crListView,
       { params: params1 }
     )
     .toPromise();
 }
 async crListForApprove(params1?) {
  return await this.http
   .get<conference[]>(
     APP_DI_CONFIG.parentDomain +
       APP_DI_CONFIG.apiEndPoint +
       APP_DI_CONFIG.endPoints.changeRequest.crListForApprove,
     { params: params1 }
   )
   .toPromise();
}
async conditionalSearchGet(params1?) {
  return await this.http
   .get<any>(
     APP_DI_CONFIG.parentDomain +
       APP_DI_CONFIG.apiEndPoint +
       APP_DI_CONFIG.endPoints.contenferance.conditionalSearchGet,
     { params: params1 }
   )
   .toPromise();
}
  async deleteAdd(params) {
    return await this.http
      .delete<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteAdd,
        { params: params }
      )
      .toPromise();
  }
  async deleteConferenceCR(params) {
    return await this.http
      .delete<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteConferenceCR,
        { params: params }
      )
      .toPromise();
  }
  async deleteBoothCR(params) {
    return await this.http
      .delete<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteBoothCR,
        { params: params }
      )
      .toPromise();
  }
  async deleteAddCR(params) {
    return await this.http
      .delete<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteAddCR,
        { params: params }
      )
      .toPromise();
  }
  async deleteOnlineAddCR(params) {
    return await this.http
      .delete<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteOnlineAddCR,
        { params: params }
      )
      .toPromise();
  }
  async deleteBannerCR(params) {
    return await this.http
      .post<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteBannerCR,null,
        { params: params }
      )
      .toPromise();
  }
  async deleteBooth(params) {
    return await this.http
      .delete<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteBooth,
        { params: params }
      )
      .toPromise();
  }
  async deleteBanner(params) {
    return await this.http
      .delete<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteBanner,
        { params: params }
      )
      .toPromise();
  }
  async deleteOnlineADD(params) {
    return await this.http
      .delete<Advertisement[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.deleteOnlineADD,
        { params: params }
      )
      .toPromise();
  }
  async approveCRBanner(params) {
    return await this.http
      .put<any[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.bannerCRApproval+"/"+params.id,null,
        { params: params }
      )
      .toPromise();
  }
  async aapproveCRBooth(params) {
    return await this.http
      .put<any[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.boothCRApproval+"/"+params.id,null,
        { params: params }
      )
      .toPromise();
  }
  async cancelCR(id) {
    return await this.http
      .put<any[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.cancelCR+"/"+id,null,
       
      )
      .toPromise();
  }
  
  
  async approveCRAdd(params) {
    return await this.http
      .put<any[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.addCRApproval+"/"+params.id,null,
        { params: params }
      )
      .toPromise();
  }
  async approveCROnlineAdd(params) {
    return await this.http
      .put<any[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.approveOnlineAddCR+"/"+params.id,null,
        { params: params }
      )
      .toPromise();
  }
  async approveCRCOnference(params) {
    return await this.http
      .put<any[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.conferenceCRApproval+"/"+params.id,null,
        { params: params }
      )
      .toPromise();
  }
  async getUserData(params?) {
    // let org:errormanagement[]=[];
    // org.push({id:1,title:'Event Guide Title​',errorCode:'ttt', content:'Only the booth conditions are met_If apply for the 2nd booth, Legal Department’s approval required with a previously registered applicant.​',
    // status:true});

    // return org;
    return await this.http
      .get<any[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.User.getUsers +
          '?pageNo=1' +
          '&pagesize=1000',{params:params}
      )
      .toPromise();
  }
  async getKRPAListData(params) {
    return await this.http
      .get<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.getkrpaList,
        { params: params }
      )
      .toPromise();
  }
  async getAddTypesData() {
    return await this.http
      .get<any[]>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.getAddTypes
      )
      .toPromise();
  }
  async saveConferenceData(data: conference) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.saveConference,
        data
      )
      .toPromise();
  }
  async updateConferenceCR(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.updateConferenceCR,
        data
      )
      .toPromise();
  }
  async editBanner(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.editBanner,
        data
      )
      .toPromise();
  }
  async editBooth(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.editBooth,
        data
      )
      .toPromise();
  }
  async editAdvertisement(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.editAdvertisement,
        data
      )
      .toPromise();
  }
  async editOnlineAdvertisement(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.editOnlineAdvertisement,
        data
      )
      .toPromise();
  }
  async saveBoothData(data: Booth) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.saveBooth,
        data
      )
      .toPromise();
  }
  async createBoothCR(data: any) {
    return await this.http
      .post<boothCR>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.createBoothCR,
        data
      )
      .toPromise();
  }
  async updateBoothCR(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.updateBoothCR,
        data
      )
      .toPromise();
  }
  async createBannerCR(data: any) {
    return await this.http
      .post<bannerCR>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.createBannerCR,
        data
      )
      .toPromise();
  }
  async updateBannerCR(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.updateBannerCR,
        data
      )
      .toPromise();
  }
  async createaddCR(data: any) {
    return await this.http
      .post<addCR>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.createaddCR,
        data
      )
      .toPromise();
  }
  async updateaddCR(data: addCR) {
    return await this.http
      .put<addCR>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.updateaddCR,
        data
      )
      .toPromise();
  }
  async createOnlineAddCR(data: any) {
    return await this.http
      .post<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.createOnlineAddCR,
        data
      )
      .toPromise();
  }
  async updateOnlineAdd(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.updateOnlineAdd,
        data
      )
      .toPromise();
  }
  async updateOnlineAddCR(data: any) {
    return await this.http
      .put<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.updateOnlineAddCR,
        data
      )
      .toPromise();
  }
  async setPaymentDate(data: any) {
    return await this.http
      .post<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.setPaymentDate,
        data
      )
      .toPromise();
  }
  async saveOnilneAddData(data: OnlineAdd) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.createOnlineAdvertisement,
        data
      )
      .toPromise();
  }
  async validateBoothCreation(id) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.validateBoothCreation +
          '?conferenceId=' +
          id,
        null
      )
      .toPromise();
  }
  async validateBannerCreation(data) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.validateBannerCreation,
        data
      )
      .toPromise();
  }
  async validateAdvertisement(data) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.validateAdvertisement,
        data
      )
      .toPromise();
  }
  async validateBanner(data) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.bannerVerification,
        data
      )
      .toPromise();
  }
  async validateOnlineAddCreation(id) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.validateOnlineAdCreation +
          '?conferenceId=' +
          id,
        null
      )
      .toPromise();
  }
  async getCRConferenceDetails(id) {
    return await this.http
      .get<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.getConferenceDetailedById +
          '/' +
          id
      )
      .toPromise();
  }
  async getConferenceCRForView(id) {
    return await this.http
      .get<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.getConferenceCRForView +
          '/' +
          id
      )
      .toPromise();
  }
  async boothApproval(id) {
    return await this.http
      .put<Booth>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.boothApproval +
          '/' +
          id,
        null
      )
      .toPromise();
  }
  async CRSubmitApproval(id) {
    return await this.http
      .put<Booth>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.CRSubmitApproval +
          '/' +
          id,
        null
      )
      .toPromise();
  }
  async submittCR(id) {
    return await this.http
      .put<Booth>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.changeRequest.submittCR +
          '/' +
          id,
        null
      )
      .toPromise();
  }
  async userApproval(params) {
    return await this.http
      .get<Booth>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.User.approveRejectUser,{params:params}
              )
      .toPromise();
  }
  async bannerApproval(id) {
    return await this.http
      .put<Booth>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.bannerApproval +
          '/' +
          id,
        null
      )
      .toPromise();
  }
  async addApproval(id) {
    return await this.http
      .put<Booth>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.addApproval +
          '/' +
          id,
        null
      )
      .toPromise();
  }
  async onlineAddApproval(id) {
    return await this.http
      .put<Booth>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.onlineAddApproval +
          '/' +
          id,
        null
      )
      .toPromise();
  }

  async validateBooth(data: Booth) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.validateBooth,
        data
      )
      .toPromise();
  }
  async validateOnlineAdd(data: OnlineAdd) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.validateOnlineAd,
        data
      )
      .toPromise();
  }
  async updateConference(data: conference) {
    return await this.http
      .put<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.updateConference,
        data
      )
      .toPromise();
  }
  async updateBoothData(data: Booth) {
    return await this.http
      .put<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.updateBooth,
        data
      )
      .toPromise();
  }
  async updateOnlineAddData(data: OnlineAdd) {
    return await this.http
      .put<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.updateOnlineAdvertisement,
        data
      )
      .toPromise();
  }
  async saveBannerData(data: Banner) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.saveBanner,
        data
      )
      .toPromise();
  }
  
  async updateBannerData(data: Banner) {
    return await this.http
      .put<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.updateBanner,
        data
      )
      .toPromise();
  }
  async saveAdvertisementData(data: Advertisement) {
    return await this.http
      .post<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.saveAdvertisement,
        data
      )
      .toPromise();
  }
  async updateAdvertisementData(data: Advertisement) {
    return await this.http
      .put<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.updateAdvertisement,
        data
      )
      .toPromise();
  }
  async getDetails(id: any) {
    return await this.http
      .get<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.getDetails +
          '/' +
          id
      )
      .toPromise();
  }
  async getBoothDetails(id: any) {
    return await this.http
      .get<Booth>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.getBoothDetails +
          '/' +
          id
      )
      .toPromise();
  }
  async getOnlineAddDetails(id: any) {
    return await this.http
      .get<any>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.onlineAddDetails +
          '/' +
          id
      )
      .toPromise();
  }
  async getBannerDetails(id: any) {
    return await this.http
      .get<Banner>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.getBannerDetails +
          '/' +
          id
      )
      .toPromise();
  }
  async getAddDetails(id: any) {
    return await this.http
      .get<Advertisement>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.getAddDetails +
          '/' +
          id
      )
      .toPromise();
  }
  async updateErrorData(err: conference) {
    return await this.http
      .put<conference>(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.ErrorMessage.updateerrors,
        err
      )
      .toPromise();
  }

  fileDownload(fileName) {
    return this.entitySvc.fileDownload(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.confereceFileDownload +
        '?fileName=' +
        fileName
    );
  }
}
