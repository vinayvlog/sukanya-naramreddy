import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APP_DI_CONFIG } from 'src/app/app-config.modules';
import { EntityService } from '../entity.service';

export interface Menumanagement {
  id: number;
  name: string;
  serialNumber: number;
  url: string;
  parentMenuId: number;
  isActive?: boolean;
  isDeleted?: boolean;
  updatedBy?: number;
  createdDate?: string;
  updatedDate?: string;
  subMenues?: any;
}

@Injectable({
  providedIn: 'root'
})
export class MenumanagementService {

  constructor(private entitySvc: EntityService<any>) { }

  list(params?: Record<string, any>): Observable<any[]> {
    return this.entitySvc.list(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Menumanagement.getMenumanagement,
      params
    );
  }
   getMenuById(id) {
    return  this.entitySvc
      .list(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.Menumanagement.getMenumanagementById+"/"+id       
      )
      .toPromise();
  }

  create(menumanagement: Menumanagement): Observable<Menumanagement> {
    return this.entitySvc.create(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Menumanagement.saveMenumanagement,
        menumanagement
    );
  }

  update(menumanagement: Menumanagement): Observable<Menumanagement> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Menumanagement.updateMenumanagement,
      {...menumanagement}
    );
  }
  updatesubMneu(menu: any): Observable<Menumanagement> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Menumanagement.updateSubMenut,
      {...menu}
    );
  }
}
