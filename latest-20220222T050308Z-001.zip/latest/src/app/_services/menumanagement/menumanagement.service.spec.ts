import { TestBed } from '@angular/core/testing';

import { MenumanagementService } from './menumanagement.service';

describe('MenumanagementService', () => {
  let service: MenumanagementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MenumanagementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
