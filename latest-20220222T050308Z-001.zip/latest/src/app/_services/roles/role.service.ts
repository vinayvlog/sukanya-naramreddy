import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EntityService } from '../entity.service';

import { APP_DI_CONFIG } from '../../app-config.modules';

export interface Role {
  id: number;
  roleName: string;
  description: string;
  status: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class RoleService {
  constructor(
    private readonly http: HttpClient,
    private entitySvc: EntityService<any>
  ) {}

  list(params?: Record<string, any>): Observable<Role[]> {
    return this.entitySvc.list(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Role.getRoles,
      params
    );
  }

  create(role: Role): Observable<Role> {
    return this.entitySvc.create(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Role.saveRole,
        role
    );
  }

  update(role: Role): Observable<Role> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Role.updateRole,
        role
    );
  }
}
