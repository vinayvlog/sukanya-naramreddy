import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APP_DI_CONFIG } from '../app-config.modules';
import { EntityService } from './entity.service';

export interface Valuesettings {
  id: number;
  eventTypeId: number;
  organizationTypeId: number;
  validationDescription: string;
  validationValue: number;
  errorMessageId: number;
  isDeleted?: boolean;
  updatedBy?: number;
  createdDate?: string;
  updatedDate?: string;
  eventType?: string;
  organizationType?: string;
  errorMessageTitle?: string;
}

@Injectable({
  providedIn: 'root',
})
export class ValuesettingsService {
  constructor(private entitySvc: EntityService<any>) {}

  list(params?: Record<string, any>): Observable<Valuesettings[]> {
    return this.entitySvc.list(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Valuesettings.getValuesettings,
      params
    );
  }

  update(valuesettings: Valuesettings): Observable<Valuesettings> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Valuesettings.updateValuesettings,
      { ...valuesettings }
    );
  }
}
