import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { TestBed, inject } from "@angular/core/testing";

import { UserService } from "./user.service";

describe("UserService", () => {
  let service: UserService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [UserService],
    });
    service = TestBed.inject(UserService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(inject(
    [HttpTestingController],
    (httpMock: HttpTestingController) => {
      // Finally, assert that there are no outstanding requests.
      httpMock.verify();
    }
  ));

  it("should be created", () => {
    expect(service).toBeTruthy();
  });
});
