import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EntityService } from '../entity.service';
import { APP_DI_CONFIG } from '../../app-config.modules';

export interface User {
  id: number;
  name: string;
  ntid: string;
  contactNumber: string;
  emailId: string;
  buId: number;
  roleId: number;
  status?: boolean;
  roleName: any;
  bu: any;
  isActive: boolean;
  displayStatus: any;
}

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(
    private readonly http: HttpClient,
    private entitySvc: EntityService<any>
  ) {}

  list(params?: Record<string, any>): Observable<any[]> {
    return this.entitySvc.list(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.User.getUsers +
        '?pageNo=1' +
        '&pagesize=1000',
      params
    );
  }
  login(emailId?: Record<string, any>): Observable<any[]> {
    return this.entitySvc.login(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.User.authenticate +
        '?emailId=' +
        emailId
    );
  }

  create(user: User): Observable<User> {
    return this.entitySvc.create(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.User.saveUser,
      user
    );
  }

  update(user: User): Observable<User> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.User.updateUser,
      user
    );
  }
}
