import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APP_DI_CONFIG } from 'src/app/app-config.modules';
import { EntityService } from '../entity.service';

export interface CodeGroup {
  id: number;
  name: string;
  description: string;
  status: boolean;
  isDeleted?: boolean;
  updatedBy?: number;
  createdDate?: string;
  updatedDate?: string;
  codes?:any
}
export interface Code {
  id: number;
  name: string;
  description: string;
  serialNumber: number;
  codeGroupId: number;
  status: boolean;
  isDeleted?: boolean;
  updatedBy?: number;
  createdDate?: string;
  updatedDate?: string;
  type?: string;
}

@Injectable({ 
  providedIn: 'root'
})
export class CodemanagementService {

  constructor(private entitySvc: EntityService<any>) { }

  list(params?: Record<string, any>): Observable<CodeGroup[]> {
    return this.entitySvc.list(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Codemanagement.getCodemanagement,
      params
    );
  }

  create(codeGroup: CodeGroup): Observable<CodeGroup> {
    return this.entitySvc.create(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Codemanagement.saveCodemanagement,
        codeGroup
    );
  }

  update(codeGroup: CodeGroup): Observable<CodeGroup> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Codemanagement.updateCodemanagement,
      {...codeGroup}
    );
  }
  createCode(codeGroup: Code): Observable<Code> {
    return this.entitySvc.create(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Code.saveCode,
        codeGroup
    );
  }
  updateCode(codeGroup: Code): Observable<Code> {
    return this.entitySvc.update(
      APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Code.updateCode,
        codeGroup
    );
  }
}
