import { TestBed } from '@angular/core/testing';

import { CodemanagementService } from './codemanagement.service';

describe('CodemanagementService', () => {
  let service: CodemanagementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CodemanagementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
