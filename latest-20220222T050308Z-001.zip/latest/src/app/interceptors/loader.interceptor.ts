import { Injectable } from '@angular/core';
import {
    HttpErrorResponse,
    HttpResponse,
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from "rxjs/operators";
import { LoaderService } from '../_services/loader.service';

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {
    constructor(public loaderService: LoaderService) { }
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
       // const token = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImF1dGgiOiJST0xFX0FETUlOLFJPTEVfVVNFUiIsImV4cCI6MTYwNzgzNzYyOX0.BHoFM2fPjLWJYLWB8XcXnWuNGYXRdyOi9X_acXf2sKbtuNbufhu_iZhLzSxjDzv87XPB1llZpWHQxWZufuHAWA";
    
        this.loaderService.show();
        req = req.clone({
           //  var headers_object = new HttpHeaders().set("auth_token", "Bearer " + t);
             setHeaders: {
                Authorization: 'Bearer ' + localStorage.getItem('token')
             }
           });
        return next.handle(req).pipe(
            finalize(() => this.loaderService.hide())
        );
    }

}
