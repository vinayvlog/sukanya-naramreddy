import { Component, OnInit } from '@angular/core';
import { ConferenceService } from 'src/app/_services/conference.service';
import { User } from 'src/app/_services/users/user.service';

@Component({
  selector: 'app-access-management',
  templateUrl: './access-management.component.html',
  styleUrls: ['./access-management.component.scss'],
})
export class AccessManagementComponent implements OnInit {
  errormsgAll: any = [];
  usersAll: any;
  addTypes: any = [];
  users: User[] = [];
  ntid: any = null;
  submittedDateFrom: any = null;
  submittedDateTo: any = null;
  status: any = 0;
  userdisplay: boolean = false;
  user: User = <User>{};
  reason: any;
  constructor(private conferenceService: ConferenceService) {}

  ngOnInit(): void {
    this.loadUsersData();
  }
  loadUsersData() {
    this.conferenceService.getUserData().then((data) => {
      this.usersAll = data;
      this.users = this.usersAll.users;
      this.users.sort((one, two) => (one > two ? -1 : 1));
    });
  }
  saveUser() {
    let statusId = 0;
    if (this.user.isActive) {
      statusId = 2;
    } else {
      statusId = 3;
    }
    let obj = {
      userId: this.user.id,
      comment: this.reason,
      statusId: statusId,
    };
    this.conferenceService.userApproval(obj).then((data) => {
      this.loadUsersData();
      this.userdisplay = false;
    });
  }
  showDialog(id: any) {
    this.user = { ...this.users.find((f1) => f1.id === id) };
    if (this.user.displayStatus === 'Rejected') {
      this.user.isActive = false;
    } else {
      this.user.isActive = true;
    }
    this.userdisplay = true;
  }
  searchUsers() {
    let obj = {
      ntid: this.ntid,
      status: this.status,
      submittedDateFrom: this.submittedDateFrom,
      submittedDateTo: this.submittedDateTo,
    };
    obj = this.clean(obj);
    this.conferenceService.getUserData(obj).then((data) => {
      this.usersAll = data;
      this.users = this.usersAll.users;
    });
  }
  clean(obj) {
    for (var propName in obj) {
      if (obj[propName] === null || obj[propName] === undefined) {
        delete obj[propName];
      }
    }
    return obj;
  }
}
