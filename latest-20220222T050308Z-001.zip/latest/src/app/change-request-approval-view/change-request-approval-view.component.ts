import { MenuItem } from 'primeng/api';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { State, Store } from '../store';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import {
  addCR,
  Advertisement,
  Banner,
  bannerCR,
  Booth,
  boothCR,
  conference,
  conferenceCR,
} from '../_models';
import { ConferenceService } from '../_services/conference.service';
import { EventGuideService } from '../_services/eventguide.service';
import { OrganisationService } from '../_services/organisation.service';
import { Product } from '../_services/products/product.service';
import { User, UserService } from '../_services/users/user.service';


export interface Car {
  existingdata;
  newdata;
  guidelines;
}
@Component({
  selector: 'app-change-request-approval-view',
  templateUrl: './change-request-approval-view.component.html',
  styleUrls: ['./change-request-approval-view.component.scss'],
})
export class ChangeRequestApprovalViewComponent implements OnInit {
  displayBasic: boolean;
  collapsed = false;
  cars = [{}];
  conference: any = {};
  conferencenew: conferenceCR = <conferenceCR>{};
  boothnew: boothCR = <boothCR>{};
  bannernew: bannerCR = <bannerCR>{};
  advertisementnew: addCR = <addCR>{};
  guidelines: any = [];
  products: Product[] = [];
  displayBooth: boolean = false;
  displayConference: boolean = false;
  displayBanner: boolean = false;
  displayAdd: boolean = false;
  isSaveBtn: boolean = false;
  displayDelete: boolean = false;
  displayRemarksTable: boolean = false;
  booth: Booth = <Booth>{};
  banner: Banner = <Banner>{};
  advertisement: addCR = <addCR>{};
  verifedData: any = [];
  usersAll: any;
  addTypes: any = [];
  users: User[] = [];
  today: any = new Date();
  displayRegister: boolean = false;
  progress: number;
  cities: any = [];
  displayViewBooth: boolean = false;
  displayViewBanner: boolean = false;
  displayViewAdd: boolean = false;
  displayErrorModel: boolean = false;
  displayCommetBox: boolean = false;
  filePath: any;
  selectedcategory: any;
  errorData: any = [];
  @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;
  files: any[] = [];
  orgData: any[] = [];
  reason: any;
  selectedId: 0;
  isApproved: any;
  table1Data: any = [];
  table2Data: any = [];
  remarksData: any;
  constructor(
    private route: ActivatedRoute,
    private conferenceService: ConferenceService,
    private orgService: OrganisationService,
    private store: Store<State>,
    private router: Router,
    public datepipe: DatePipe,
    private userService: UserService,
    private http: HttpClient,
    private eventGuideService: EventGuideService
  ) {}
  onClick(event: Event, menu) {
    menu.toggle(event);
    event.stopPropagation();
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.conferenceService.getConferenceCRForView(id).then((data) => {
      this.conference = data;
      this.loadcodeWithGuildelines();
      this.loadProductsData();
      this.loadUsersData();
      this.loadAddTypes();
      this.loadcodeWithCities();
      this.loadOrganisation();
      this.conferencenew.crOrganizationId = 0;
      this.conferencenew.crCityId = 0;
    });
  }
  showBasicDialog() {
    this.displayBasic = true;
  }

  close() {
    // this.loadOrganisation();
  }
  loadOrganisation() {
    this.orgService.getOrgData().then((result) => {
      this.orgData = result;
    });
  }
  loadConferenceData() {
    const id = this.route.snapshot.paramMap.get('id');
    this.conferenceService.getCRConferenceDetails(id).then((data) => {
      this.conference = data;
    });
  }
  loadcodeWithCities() {
    this.orgService.getcodeWithGroup(9).then((result) => {
      this.cities = result;
    });
  }
  loadAddTypes() {
    this.conferenceService.getAddTypesData().then((data) => {
      this.addTypes = data;
    });
  }
  loadUsersData() {
    this.conferenceService.getUserData().then((data) => {
      this.usersAll = data;
      this.users = this.usersAll.users;
    });
  }

  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
    });
  }
  loadcodeWithGuildelines() {
    this.eventGuideService.geteventData().then((result) => {
      this.guidelines = result;
    });
  }

  saveBootCR(data) {
    this.displayCommetBox = true;
    this.displayBooth = true;
    this.selectedId = data.crItemId;
    this.isApproved = true;
  }

  saveBanner(data) {
    console.log()
    this.displayCommetBox = true;
    this.displayBanner = true;
    this.selectedId = data.crItemId;
    this.isApproved = true;
  }

  saveAdd(data) {
    this.displayCommetBox = true;
    this.displayAdd = true;
    this.selectedId = data.crItemId;
    this.isApproved = true;
  }

  cancel() {
    this.displayCommetBox = false;
  }

  submittCR() {
    this.conferenceService
      .CRSubmitApproval(this.conference.conferenceDetail.crId)
      .then((data) => {
        this.router.navigateByUrl('/home/changerequestapproval');
      });
  }
  saveConference(data) {
    this.displayCommetBox = true;
    this.displayConference = true;
    this.selectedId = data.id;
    this.isApproved = true;
  }

  rejectConference(data) {
    this.displayCommetBox = true;
    this.displayConference = true;
    this.selectedId = data.id;
    this.isApproved = false;
  }
  rejectBooth(data) {
    this.displayCommetBox = true;
    this.displayBooth = true;
    this.selectedId = data.crItemId;
    this.isApproved = false;
  }
  rejectBanner(data) {
    this.displayCommetBox = true;
    this.displayBanner = true;
    this.selectedId = data.crItemId;
    this.isApproved = false;
  }
  rejectAdd(data) {
    this.displayCommetBox = true;
    this.displayAdd = true;
    this.selectedId = data.crItemId;
    this.isApproved = false;
  }
  confirm() {
    let obj = {
      approverRemark: this.reason,
      id: this.selectedId,
      isApproved: this.isApproved,
    };
    if (this.displayConference) {
      this.conferenceService.approveCRCOnference(obj).then((data) => {
        this.displayCommetBox = false;
      });
    } else if (this.displayAdd) {
      this.conferenceService.approveCRAdd(obj).then((data) => {
        this.displayCommetBox = false;
      });
    } else if (this.displayBanner) {
      this.conferenceService.approveCRBanner(obj).then((data) => {
        this.displayCommetBox = false;
      });
    } else if (this.displayBooth) {
      this.conferenceService.aapproveCRBooth(obj).then((data) => {
        this.displayCommetBox = false;
      });
    }
  }
  showComentsBoth(data) {
    this.table1Data = [];
    this.table2Data = [];
    this.remarksData = data;
    var obj1 = {
      requester: data.newBooth.registeredBy,
      date: data.newBooth.createdDate,
      remarks: data.remark,
    };
    this.table1Data.push(obj1);
    var obj2 = {
      event: data.newBooth.conferenceName,
      type: data.typeName,
      approver: data.newBooth.approvedBy,
      status: data.statusName,
      date: data.newBooth.updatedDate,
      remarks: data.approverRemark,
    };
    this.table2Data.push(obj2);
    this.displayRemarksTable = true;
  }
}
