import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeRequestApprovalViewComponent } from './change-request-approval-view.component';

describe('ChangeRequestApprovalViewComponent', () => {
  let component: ChangeRequestApprovalViewComponent;
  let fixture: ComponentFixture<ChangeRequestApprovalViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeRequestApprovalViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeRequestApprovalViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
