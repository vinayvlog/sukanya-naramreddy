import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventSearchViewComponent } from './event-search-view.component';

describe('EventSearchViewComponent', () => {
  let component: EventSearchViewComponent;
  let fixture: ComponentFixture<EventSearchViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventSearchViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventSearchViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
