import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'app-viewchangerequestapproval',
    templateUrl: './viewchangerequestapproval.component.html',
    styleUrls: ['./viewchangerequestapproval.component.scss'],
  })
  export class ViewChangeRequestApproval implements OnInit {

    constructor() {
      }

      ngOnInit(): void {
      }
  }