import { Component, OnInit } from '@angular/core';

import { Observable, Subject } from 'rxjs';
import { Role } from '../../_services/roles/role.service';
import {
  GetRoles,
  CreateRole,
  UpdateRole,
} from 'src/app/store/stores/roles/roles.actions';
import {
  getRoles,
  getRoleCreated,
  getRoleUpdated,
} from 'src/app/store/stores/roles/roles.store';
import { State, Store } from '../../store';
import { takeUntil } from 'rxjs/operators';
import {
  CreateUser,
  GetUsers,
  UpdateUser,
} from 'src/app/store/stores/users/users.actions';
import {
  getUserCreated,
  getUsers,
  getUserUpdated,
} from 'src/app/store/stores/users/users.store';
import { User } from 'src/app/_services/users/user.service';
import { OrganisationService } from 'src/app/_services/organisation.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
})
export class UsersComponent implements OnInit {
  isLoading$: Observable<boolean>;
  group: Role = <Role>{};
  display: boolean = false;
  userdisplay: boolean = false;
  groups: Role[] = [];
  users: User[] = [];
  user: User = <User>{};
  private readonly destroy = new Subject<void>();
  codeGroups: any = [];

  constructor(
    private store: Store<State>,
    private orgService: OrganisationService
  ) {
  //  this.store.dispatch(new GetUsers());
  }

  ngOnInit(): void {
    this.loadRoleData();
    this.loadcodeWithGroup();
  }
  loadRoleData() {
    this.store.dispatch(new GetRoles());
    this.store.select(getRoles).subscribe((data) => {
      this.groups = data;
    });
  }
  // loadUserData() {
  //   this.store.select(getUsers).subscribe((data) => {
  //     this.users = data;
  //   });
  // }

  showDialog(id: number) {
    if (id > 0) {
      this.group = {...this.groups.find((fl) => fl.id === id)};
    } else {
      this.group.id = 0;
      this.group.roleName = '';
      this.group.description = '';
      this.group.status = true;
    }
    //  this.loadRoleForm();
    this.display = true;
  }
  showUserDialog(id: number) {
    if (id > 0) {
      this.user = {...this.users.find((f1) => f1.id === id)};
    } else {
      this.user.id = 0;
      this.user.roleId = 0;
      this.user.name = '';
      this.user.buId = 0;
      this.user.contactNumber = '';
      this.user.emailId = '';
      this.user.ntid = '';
      this.user.status = true;
    }
    this.userdisplay = true;
  }
  showUserDialog1(user: any) {
    this.user = { ...user };

    this.userdisplay = true;
  }
  loadcodeWithGroup() {
    this.orgService.getcodeWithGroup(7).then((result) => {
      this.codeGroups = result;
    });
  }
  saveRole() {
    if (this.group.id>0) {
      this.updateRole(this.group);
    } else {
      this.createRole(this.group);
    }
  }
  private createRole(role: Role): void {
    this.store.dispatch(new CreateRole(role));
    this.store
      .select(getRoleCreated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.loadRoleData()
          this.display = false;
        }
      });
  }
  private updateRole(role: Role): void {
    this.store.dispatch(new UpdateRole(role));
    this.store
      .select(getRoleUpdated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.loadRoleData()
          this.display = false;
        }
      });
  }
  saveUser() {
    if (this.user.id>0) {
      this.updateUser(this.user);
    } else {
      this.createUser(this.user);
    }
  }
  private createUser(user: User): void {
    this.store.dispatch(new CreateUser(user));
    this.store
      .select(getUserCreated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.loadRoleData();
          this.userdisplay = false;
        }
      });
  }
  private updateUser(user: User): void {
    this.store.dispatch(new UpdateUser(user));
    this.store
      .select(getUserUpdated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.loadRoleData();
          this.userdisplay = false;
        }
      });
  }
}
