import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-management',
  templateUrl: './auth-management.component.html',
  styleUrls: ['./auth-management.component.scss']
})
export class AuthManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
