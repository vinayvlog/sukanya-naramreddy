import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { errormanagement } from '../_models';
import { State, Store } from '../store';
import {
  NotificationManagement,
  NotificationmanagementService,
} from '../_services/notificationmanagement/notificationmanagement.service';
import {
  CreateNotificationManagement,
  GetNotificationManagement,
  UpdateNotificationManagement,
} from '../store/stores/notificationmanagement/notificationmanagement.actions';
import {
  getNotificationManagement,
  getNotificationManagementCreated,
  getNotificationManagementUpdated,
} from '../store/stores/notificationmanagement/notificationmanagement.store';
import { catchError, map, takeUntil } from 'rxjs/operators';
import { Subject, throwError } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { APP_DI_CONFIG } from '../app-config.modules';
declare var Quill: any;
@Component({
  selector: 'app-notification-management',
  templateUrl: './notification-management.component.html',
  styleUrls: ['./notification-management.component.scss'],
})
export class NotificationManagementComponent implements OnInit {
  notifications: NotificationManagement[] = [];
  notification: NotificationManagement = <NotificationManagement>{};
  display: boolean = false;
  text: any;
  val: boolean = true;
  inactive: boolean = false;
  active: boolean = true;
  popupStatus: boolean = true;
  files: File[];
  fileName: any;
  filterednotification: any[];
  propagateChange = (_: any) => {};
  propagateTouched = () => {};
  registerOnChange(fn: (_: any) => void): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: () => void): void {
    this.propagateTouched = fn;
  }
  public value: string;
  private readonly destroy = new Subject<void>();
  @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;

  constructor(
    private store: Store<State>,
    private notificationmanagementService: NotificationmanagementService,
    private http: HttpClient
  ) {
    var fontSizeStyle = Quill.import('attributors/style/size');
    fontSizeStyle.whitelist = [
      '0.75em',
      '1em',
      '1.5em',
      '2.5em',
      '24px',
      '48px',
      '100px',
      '200px',
    ];
    Quill.register(fontSizeStyle, true);
  }

  ngOnInit(): void {
    this.fileName = 'Select Your File';
    this.loadNotificarionsData();
  }

  loadNotificarionsData() {
    this.store.dispatch(new GetNotificationManagement());
    this.store.select(getNotificationManagement).subscribe((data) => {
      this.notifications = data;
      console.log(this.notifications);
    });
  }
  showDialog(id: number) {
    if (id > 0) {
      this.notification = { ...this.notifications.find((fl) => fl.id === id) };
    } else {
     
      this.notification = {...this.notification};
      this.notification.id = 0;
      this.notification.content = '';
      this.notification.status = true;
      this.notification.notificationTitle = '';
      this.files = [];
    }
    this.display = true;
  }
  async saveerror(notification: NotificationManagement) {
    if (notification.id > 0) {
      this.updateNotification(notification);
    } else {
      this.createNotification(notification);
    }
  }
  private createNotification(notification: NotificationManagement): void {
    this.store.dispatch(new CreateNotificationManagement(notification));
    this.store
      .select(getNotificationManagementCreated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.display = false;
          if (this.files.length > 0) {
            this.uploadFile();
          } else {
            this.loadNotificarionsData();
          }
        }
      });
  }
  private uploadFile() {
    if (this.notification.id > 0 && this.files.length) {
      var id = Math.max.apply(
        Math,
        this.notifications.map(function (o) {
          return o.id;
        })
      );
      const formData = new FormData();
      formData.append('file', this.files[0]);
      // this.notificationmanagementService
      //   .fileUpload(formData, this.notification.id)
      //   .subscribe((data) => {});
      const path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Notificationmanagement.fileUpload +
        '?id=' +
        this.notification.id;
      this.http
        .put(path, formData, {
          reportProgress: true,
          observe: 'events',
        })
        .pipe(
          map((event: any) => {
            this.files = [];
            this.loadNotificarionsData();
          }),
          catchError((err: any) => {
            alert(err.message);
            return throwError(err.message);
          })
        )
        .toPromise();
    } else if (this.files.length) {
      var id = Math.max.apply(
        Math,
        this.notifications.map(function (o) {
          return o.id;
        })
      );
      const formData = new FormData();

      formData.append('file', this.files[0]);
      const path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.Notificationmanagement.fileUpload +
        '?id=' +
        this.notification.id;
      this.http
        .put(path, formData, {
          reportProgress: true,
          observe: 'events',
        })
        .pipe(
          map((event: any) => {
            this.files = [];
            this.loadNotificarionsData();
          }),
          catchError((err: any) => {
            alert(err.message);
            return throwError(err.message);
          })
        )
        .toPromise();
    }
  }

  private updateNotification(notification: NotificationManagement): void {
    this.store.dispatch(new UpdateNotificationManagement({ ...notification }));
    this.store
      .select(getNotificationManagementUpdated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.display = false;
          this.uploadFile();
          this.loadNotificarionsData();
        }
      });
  }
  close() {
    this.loadNotificarionsData();
  }
  writeValue(value: any) {
    this.value = value;
  }

  onTextChanged(event) {
    this.propagateChange(event.htmlValue);
  }
  handleChange(e) {
    this.val = e.checked;
  }

  onBasicUpload(files: File[]) {
    this.files = files;
    console.log('files', this.files[0]);
    this.fileName = this.files[0].name;
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      item.progress = 0;

      this.files[0] = item;
    }
    this.fileDropEl.nativeElement.value = '';
    //  this.uploadFilesSimulator(0);
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  filternotification(event) {
    //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.notifications.length; i++) {
      let notf = this.notifications[i];
      if (notf.content.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(notf);
      }
    }

    this.filterednotification = filtered;
  }
  selectEvent(item) {
    // do something with selected item
  }

  onChangeSearch(search: string) {
    // fetch remote data from here
    // And reassign the 'data' which is binded to 'data' property.
  }

  onFocused(e) {
    // do something
  }
  onSelect(event: any) {
    this.onSelect = event.id;
  }

  onFileDropped($event) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile(index: number) {
    this.files = [];
  }
}
