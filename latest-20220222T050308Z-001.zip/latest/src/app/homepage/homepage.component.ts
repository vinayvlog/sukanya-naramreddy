import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin, { Draggable } from '@fullcalendar/interaction';
import { FullCalendarComponent } from '@fullcalendar/angular';
import timeGridPlugin from '@fullcalendar/timegrid';
import resourceTimeGridPlugin from '@fullcalendar/resource-timegrid';
import esLocale from '@fullcalendar/core/locales/es';
import frLocale from '@fullcalendar/core/locales/fr';
import { ConferenceService } from '../_services/conference.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { GetNotificationManagement } from '../store/stores/notificationmanagement/notificationmanagement.actions';
import { getNotificationManagement } from '../store/stores/notificationmanagement/notificationmanagement.store';
import { State, Store } from '../store';
import { NotificationManagement } from '../_services/notificationmanagement/notificationmanagement.service';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss'],
})
export class HomepageComponent implements OnInit {
  notifications: NotificationManagement[] = [];
  notification: NotificationManagement = <NotificationManagement>{};
  options: any;
  eventsModel: any = [];
  conferenceData: any = [];
  selectedconferences: any = [];
  getAllConference: any;
  @ViewChild('fullcalendar') fullcalendar: FullCalendarComponent;
  @ViewChild('external') external: ElementRef;
  constructor(
    private conferenceService: ConferenceService,
    public datepipe: DatePipe,
    private router:Router,
    private store: Store<State>,
  ) {
    // let obj = {
    //   pageNo: 1,
    //   pageSize: 1000,
    // };
    // this.conferenceService.getConferenceData(obj).then((result) => {
    //   this.getAllConference = result;
    //   this.conferenceData = this.getAllConference.conferences;
    //   this.conferenceData.forEach((item) => {
    //     // var startDate = this.datepipe.transform(item.startDate,'yyyy-MM-DD')
    //     var obj = {
    //       title: item.conferenceName,
    //       start: this.datepipe
    //         .transform(item.startDate, 'yyyy-MM-dd')
    //         .toString(),
    //       end: this.datepipe.transform(item.endDate, 'yyyy-MM-dd').toString(),
    //       id: item.id,
    //     };
    //     this.eventsModel.push(obj);
    //   });
    // });
  }

  ngOnInit(): void {
    this.loadCOnferenceData();
    this.loadNotificarionsData();
    this.options = {
      editable: true,

      theme: 'standart', // default view, may be bootstrap
      header: {
        left: 'prev,next myCustomButton',
        center: 'title',
        right: '',
      },
      // columnHeaderHtml: () => {
      //     return '<b>Friday!</b>';
      // },
      locales: [esLocale, frLocale],
      locale: 'en',
      // add other plugins
      plugins: [
        dayGridPlugin,
        interactionPlugin,
        timeGridPlugin,
        resourceTimeGridPlugin,
      ],
    };
    this.updateEvents();
    new Draggable(this.external.nativeElement, {
      itemSelector: '.fc-event',
      eventData: function (eventEl) {
        return {
          title: eventEl.innerText,
        };
      },
    });
  }
  loadNotificarionsData() {
    this.store.dispatch(new GetNotificationManagement());
    this.store.select(getNotificationManagement).subscribe((data) => {
      this.notifications = data;
      this.notifications = [...this.notifications.filter((fl) => fl.status === true) ];

    });
  }
  eventClick(model) {
    this.router.navigateByUrl("/home/marketing-admin")

    console.log(model);
  }
  eventDragStop(model) {
    
    console.log(model);
  }
  dateClick(model) {
    console.log(model);
  }
  updateHeader() {
    this.options.header = {
      left: 'prev,next myCustomButton',
      center: 'title',
      right: '',
    };
  }
  updateEvents() {
  
    // this.eventsModel = [{
    //   title: 'Event 1',
    //   start: '2022-02-14',
    //   end: '2022-02-17'
    // },
    // {
    //   title: 'Event 2',
    //   start: '2022-02-14',
    //   end: '2022-02-14'
    // }];
  }
  get yearMonth(): string {
    const dateObj = new Date();
    return dateObj.getUTCFullYear() + '-' + (dateObj.getUTCMonth() + 1);
  }
  dayRender(ev) {
    ev.el.addEventListener('dblclick', () => {
      this.router.navigateByUrl("/home/marketing-admin")
    });
  }
  clickButton(model: any) {
    this.router.navigateByUrl("/home/marketing-admin")
  }
  loadCOnferenceData() {
    let obj = {
      pageNo: 1,
      pageSize: 1000,
    };
    this.conferenceService.getConferenceData(obj).then((result) => {
      this.getAllConference = result;
      this.conferenceData = this.getAllConference.conferences;
      this.conferenceData.forEach((item)=>{
        var obj = {
           title: item.conferenceName,
           start: this.datepipe.transform(item.startDate,'yyyy-MM-dd'),
           end: this.datepipe.transform(item.endDate,'yyyy-MM-dd'),
         }
         this.eventsModel.push(obj)
         
       })

    });
  }
}
