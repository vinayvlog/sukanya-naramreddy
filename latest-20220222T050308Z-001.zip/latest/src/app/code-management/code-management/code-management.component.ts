import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import {
  CreateCodeGroup,
  GetCodeGroups,
  UpdateCodeGroup,
} from 'src/app/store/stores/codemanagement/codemanagement.actions';
import {
  getCodeGroup,
  getCodeGroupCreated,
  getCodeGroupUpdated,
} from 'src/app/store/stores/codemanagement/codemanagement.store';
import {
  Code,
  CodeGroup,
  CodemanagementService,
} from 'src/app/_services/codemanagement/codemanagement.service';
import { State, Store } from '../../store';

@Component({
  selector: 'app-code-management',
  templateUrl: './code-management.component.html',
  styleUrls: ['./code-management.component.scss'],
})
export class CodeManagementComponent implements OnInit {
  groups: CodeGroup[] = [];
  group: CodeGroup = <CodeGroup>{};
  code: Code = <Code>{};
  display: boolean = false;
  userdisplay: boolean = false;
  search: boolean = false;
  private readonly destroy = new Subject<void>();

  constructor(
    private store: Store<State>,
    private codemanagementService: CodemanagementService
  ) {
    this.store.dispatch(new GetCodeGroups());
  }

  ngOnInit(): void {
    this.getCodesData();
  }
  getCodesData() {
    this.codemanagementService.list().subscribe((data) => {
      this.groups = data;
    });
    // this.store.select(getCodeGroup).subscribe((data) => {
    //   this.groups = data;
    // });
  }
  showDialog(id: number) {
    if (id > 0) {
      this.group = this.groups.find((fl) => fl.id === id);
    } else {
      this.group.id = 0;
      this.group.status = true;
      this.group.description = '';
      this.group.name=''
    }
    this.display = true;
  }
  showUserDialog(id: number) {
    if (id > 0) {
      // this.eventguide=this.eventguideAll.find(fl=>fl.id===id);
    } else {
      this.code.id = 0;
      this.code.codeGroupId = 0;
      this.code.status = true;
      this.code.description='';
      this.code.name=''
    }
    this.userdisplay = true;
  }

  showUserDialog1(code: any) {
    this.code = { ...code };
    this.userdisplay = true;
  }
  saveGroup() {
    if (this.group.id > 0) {
      this.updateGroup(this.group);
    } else {
      this.createGroup(this.group);
    }
  }
  private createGroup(group: CodeGroup): void {
    this.store.dispatch(new CreateCodeGroup(group));
    this.store
      .select(getCodeGroupCreated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.getCodesData();
          this.display = false;
        }
      });
  }
  private updateGroup(group: CodeGroup): void {
    this.store.dispatch(new UpdateCodeGroup(group));
    this.store
      .select(getCodeGroupUpdated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.getCodesData();
          this.display = false;
        }
      });
  }
  saveCode(){
    if(this.code.id>0){
      this.codemanagementService.updateCode(this.code).subscribe((data)=>{
        this.getCodesData();
        this.userdisplay = false
      })
    }else{
      this.codemanagementService.createCode(this.code).subscribe((data)=>{
        this.getCodesData();
        this.userdisplay = false
      })
    }
  }
}
