import { Component, OnInit } from '@angular/core';
import { eventguide } from './../_models/index';
import { EventGuideService } from './../_services/eventguide.service';
import { SortEvent } from 'primeng/api';
import { DialogModule } from 'primeng/dialog';
import { RadioButtonModule } from 'primeng/radiobutton';

@Component({
  selector: 'app-eventguide',
  templateUrl: './eventguide.component.html',
  styleUrls: ['./eventguide.component.scss'],
})
export class EventguideComponent implements OnInit {
  eventguides: eventguide[] = [];
  eventguideAll: any;
  eventguide: eventguide = <eventguide>{};
  display: boolean = false;
  propagateChange = (_: any) => {};
  propagateTouched = () => {};
  registerOnChange(fn: (_: any) => void): void {
    this.propagateChange = fn;
  }
  constructor(private eventservService: EventGuideService) {}

  ngOnInit(): void {
    this.loadEvents();
  }
  loadEvents() {
    this.eventservService.geteventData().then((result) => {
      this.eventguideAll = result;
      this.eventguides = this.eventguideAll.eventGuidelineResponses;
      for(let i=0;i < this.eventguides.length;i++){
        this.eventguides[i].content =  this.eventguides[i].content.replace(/<[^>]*>/g, '');
      }   
    });
  }

  showDialog(id: number) {
    if (id > 0) {
      this.eventguide = this.eventguides.find((fl) => fl.id === id);
    } else {
      this.eventguide.id = 0;
      this.eventguide.content = '';
      this.eventguide.title = '';
      this.eventguide.status = true;
    }
    this.display = true;
  }
  async saveevent(evt: eventguide) {
    if (evt.title == '') {
      alert('Eventguide title Required');
      return;
    } else if (evt.content == '') {
      alert('Event content Required');
      return;
    }

    if (evt.id > 0) {
      //update
      await this.eventservService.updateEventData(evt);
      this.display = false;
      this.loadEvents();
    } else {
      //save
      await this.eventservService.saveEventData(evt);
      this.display = false;
      this.loadEvents();
    }
  }
  close() {
    this.loadEvents();
  }

  onTextChanged(event) {
    this.propagateChange(event.htmlValue);
  }
}
