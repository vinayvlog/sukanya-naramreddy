import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

export interface User {
    eventid;
    eventname;
    eventtype;
    venue;
    city;
    startdate;
    enddate;
    registeredby;
    status;
  
  }
@Component({
    selector: 'app-view-other-events',
    templateUrl: './view-other-events.component.html',
    styleUrls: ['./view-other-events.component.scss'],
  })
  export class ViewOtherEventsComponent implements OnInit {
    files: any[] = [];
    @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;
    users: User[];
    displayRemark:boolean;
    displayApprove: boolean;

      constructor(){}
      ngOnInit(): void {
        this.users = [
            { eventid: '1', eventname: 'kiran',eventtype:'Event Type3',venue:'online',
            city:'Seoul Metropolitan City',startdate:'2021/10/19',enddate:'2021/10/19',registeredby:'Jeong-Ok Im',status:'New' },
            { eventid: '1', eventname: 'kiran',eventtype:'Event Type3',venue:'online',
            city:'Seoul Metropolitan City',startdate:'2021/10/19',enddate:'2021/10/19',registeredby:'Jeong-Ok Im',status:'New' },
            { eventid: '1', eventname: 'kiran',eventtype:'Event Type3',venue:'online',
            city:'Seoul Metropolitan City',startdate:'2021/10/19',enddate:'2021/10/19',registeredby:'Jeong-Ok Im',status:'New' },  
        ];
          
      }
        /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      item.progress = 0;

      this.files[0] = item;
    }
    this.fileDropEl.nativeElement.value = '';
    //  this.uploadFilesSimulator(0);
  }

    onFileDropped($event) {
      this.prepareFilesList($event);
    }
  
    /**
     * handle file from browsing
     */
    fileBrowseHandler(files) {
      this.prepareFilesList(files);
    }
  
    /**
     * Delete file from files list
     * @param index (File index)
     */
    deleteFile(index: number) {
      this.files = [];
    }

    showBasicDialog(){
      this.displayRemark = true;
    }
    showBasicDialog1(){
      this.displayApprove = true;
    }
  }