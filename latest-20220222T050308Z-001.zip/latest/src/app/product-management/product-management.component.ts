import { Component, OnInit } from '@angular/core';
import { errormanagement } from '../_models';
import { Product } from '../_services/products/product.service';
import { State, Store } from '../store';
import {
  CreateProduct,
  GetProducts,
  UpdateProduct,
} from '../store/stores/products/product.actions';
import {
  getProductCreated,
  getProducts,
  getProductUpdated,
} from '../store/stores/products/product.store';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { OrganisationService } from '../_services/organisation.service';

@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html',
  styleUrls: ['./product-management.component.scss'],
})
export class ProductManagementComponent implements OnInit {
  products: Product[] = [];
  product: Product = <Product>{};
  display: boolean = false;
  codeGroups: any = [];
  private readonly destroy = new Subject<void>();

  constructor(
    private store: Store<State>,
    private orgService: OrganisationService
  ) {}

  ngOnInit(): void {
    this.loadProductsData();
    this.loadcodeWithGroup();
  }
  loadcodeWithGroup() {
    this.orgService.getcodeWithGroup(11).then((result) => {
      this.codeGroups = result;
    });
  }
  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
      console.log(this.products);
    });
  }
  showDialog(id: number) {
    if (id > 0) {
      this.product = { ...this.products.find((f1) => f1.id === id) };
    } else {
      this.product.id = null;
      this.product.status = true;
      this.product.buId = 0;
      this.product.productName = '';
    }
    this.display = true;
  }

  saveProduct() {
    if (this.product.id > 0) {
      this.updateProduct(this.product);
    } else {
      this.product.id = 0;
      this.createProduct(this.product);
    }
  }

  private createProduct(product: Product): void {
    this.store.dispatch(new CreateProduct(product));
    this.store
      .select(getProductCreated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.display = false;
          this.loadProductsData();
        }
      });
  }
  private updateProduct(product: Product): void {
    this.store.dispatch(new UpdateProduct({ ...product }));
    this.store
      .select(getProductUpdated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.display = false;
          this.loadProductsData();
        }
      });
  }
  close(){
    this.loadProductsData();
  }
}
