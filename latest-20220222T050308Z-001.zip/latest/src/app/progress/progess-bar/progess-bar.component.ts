import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-progess-bar',
  templateUrl: './progess-bar.component.html',
  styleUrls: ['./progess-bar.component.scss']
})
export class ProgessBarComponent implements OnInit {
  @Input() progress = 0;

  constructor() { }

  ngOnInit(): void {
  }

}
