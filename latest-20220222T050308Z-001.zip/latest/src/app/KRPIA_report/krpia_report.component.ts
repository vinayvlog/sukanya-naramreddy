import { Component, OnInit } from '@angular/core';
import { conference, organisation } from '../_models';
import { OrganisationService } from '../_services/organisation.service';
import { State, Store } from '../store';
import { Product } from '../_services/products/product.service';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import { ConferenceService } from '../_services/conference.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { APP_DI_CONFIG } from '../app-config.modules';

@Component({
  selector: 'app-krpia_report',
  templateUrl: './krpia_report.component.html',
  styleUrls: ['./krpia_report.component.scss'],
})
export class KRPIAReportComponent implements OnInit {
  products: Product[] = [];
  orgId: number = 0;
  buId: number = 1;
  orgData: organisation[] = [];
  codeGroups: any = [];
  cities: any = [];
  guidelines: any = [];
  productId: number = 0;
  getAllConference: any = [];
  conferences: conference[] = [];
  conference: any = [];
  displayRegister: boolean = false;
  checked: boolean = false;
  displayBasic: boolean;
  displayReport: boolean;
  displayExport: boolean;
  params: {};
  reportDate: any;
  today: any = new Date();
  qtrStartDate: any = new Date();
  qtrEndDate: any = new Date();
  krpiaDate:any = new Date();
  quater: number = 0;
  constructor(
    private orgService: OrganisationService,
    private store: Store<State>,
    private conferenceService: ConferenceService,
    private router: Router,
    public datepipe: DatePipe
  ) {}
  ngOnInit(): void {
    let obj = {
      buIds: ['1'],
      periodSearchType: '1',
      quarter: this.quater,
    };
    this.today = this.datepipe.transform(this.today, 'yyyy-MM-dd');
    this.params = obj;
    this.loadCOnferenceData();
    //this.loadOrganisation();
    this.loadcodeWithGroup();
    //this.loadProductsData();
    //this.loadcodeWithCities();
    //this.loadcodeWithGuildelines();
  }

  loadCOnferenceData() {
    this.conferenceService.getKRPAListData(this.params).then((data) => {
      this.conference = data;
    });
  }
  cancel(){
    this.displayBasic = false;

  }
  search(){
    let obj = {
      buIds: ['1'],
      periodSearchType: this.orgId,
      quarter: this.quater,
    };
    this.params = obj;
    this.loadCOnferenceData();

  }
  loadOrganisation() {
    this.orgService.getOrgData().then((result) => {
      this.orgData = result;
    });
  }
  loadcodeWithGroup() {
    this.orgService.getcodeWithGroup(11).then((result) => {
      this.codeGroups = result;
      this.buId = this.codeGroups[0].id
    });
  }
  loadcodeWithCities() {
    this.orgService.getcodeWithGroup(2).then((result) => {
      this.cities = result;
    });
  }
  loadcodeWithGuildelines() {
    this.orgService.getcodeWithGroup(5).then((result) => {
      this.guidelines = result;
    });
  }
  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
    });
  }
  getDetailsPage(id: any) {
    this.router.navigateByUrl('/home/marketing-admin/' + id);
  }
  register() {
    this.displayRegister = true;
    this.conference.organizationId = 0;
    this.conference.cityId = 0;
  }
  saveConference() {
    this.conference.endDate = this.datepipe.transform(
      this.conference.endDate,
      'yyyy-MM-dd'
    );
    this.conference.endDate = this.datepipe.transform(
      this.conference.endDate,
      'yyyy-MM-dd'
    );
    this.conference.organizationId = parseInt(this.conference.organizationId);
    this.conferenceService
      .saveConferenceData(this.conference)
      .then((data) => {
        this.loadCOnferenceData();
        this.displayRegister = false;
      })
      .catch((error) => {});
  }

  showBasicDialog() {
    let obj = {
      quarter: this.quater,
      periodSearchType: this.orgId,
      buIds: ['1'],
    };
    this.params = obj;
    if (
      this.conference.filter((item) => item.statusName == 'Approved')
        .length > 0
    ) {
      this.loadCOnferenceData();
    } else {
      this.displayBasic = true;
    }
  }
  // proceed() {
  //   this.loadCOnferenceData();
  // }
  showBasicDialog1() {
    this.displayReport = true;
  }
  showBasicDialog2() {
    this.displayExport = true;
  }
  submittKRPPA() {
    let selectedItems = this.conference.filter(
      (item) => item.checked
    );
    let obj = {
      events: [],
      reportDate: this.reportDate,
    };

    if (this.checked) {
      var array = [];
      this.conference.babCommons.forEach((item) => {
        var obj = {
          category: 1,
          id: item.id,
        };
        array.push(obj);
      });
      obj.events = array;
      this.setPaymentDate(obj);
    } else if (selectedItems.length > 0) {
      var array = [];
      selectedItems.forEach((item) => {
        var obj = {
          category: 1,
          id: item.id,
        };
        array.push(obj);
      });
      obj.events = array;
      this.setPaymentDate(obj);
    } else {
      alert('No selected items');
    }
  }
  setPaymentDate(data) {
    this.conferenceService.setPaymentDate(data).then((data) => {
      this.loadCOnferenceData();
      this.displayReport=false
    });
  }
  Quarter1() {
    this.quater = 1;
    let dateString1 = '2022-01-01T00:00:00';
    let dateString2 = '2022-03-31T00:00:00';
    this.qtrStartDate = this.datepipe.transform(dateString1, 'yyyy-MM-dd');
    this.qtrEndDate = this.datepipe.transform(dateString2, 'yyyy-MM-dd');
  }
  Quarter2() {
    this.quater = 2;
    let dateString1 = '2022-04-01T00:00:00';
    let dateString2 = '2022-06-30T00:00:00';
    this.qtrStartDate = this.datepipe.transform(dateString1, 'yyyy-MM-dd');
    this.qtrEndDate = this.datepipe.transform(dateString2, 'yyyy-MM-dd');
  }
  Quarter3() {
    this.quater = 3;
    let dateString1 = '2022-07-01T00:00:00';
    let dateString2 = '2022-09-30T00:00:00';
    this.qtrStartDate = this.datepipe.transform(dateString1, 'yyyy-MM-dd');
    this.qtrEndDate = this.datepipe.transform(dateString2, 'yyyy-MM-dd');
  }
  Quarter4() {
    this.quater = 4;
    let dateString1 = '2022-10-01T00:00:00';
    let dateString2 = '2022-12-31T00:00:00';
    this.qtrStartDate = this.datepipe.transform(dateString1, 'yyyy-MM-dd');
    this.qtrEndDate = this.datepipe.transform(dateString2, 'yyyy-MM-dd');
  }
  downloadAll() {
    const path =
      APP_DI_CONFIG.parentDomain +
      APP_DI_CONFIG.apiEndPoint +
      APP_DI_CONFIG.endPoints.contenferance.exportAllKRPIAData 
      ;
    window.open(path, '_blank');
  }
  download(){
    const path =
    APP_DI_CONFIG.parentDomain +
    APP_DI_CONFIG.apiEndPoint +
    APP_DI_CONFIG.endPoints.contenferance.exportKRPIA+"?krpiaDate="+ this.krpiaDate
    ;
  window.open(path, '_blank');
  this.displayExport = false;
  }
}
