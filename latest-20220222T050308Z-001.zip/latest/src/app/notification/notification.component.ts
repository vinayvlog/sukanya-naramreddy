import { Component, OnInit } from '@angular/core';
import { State, Store } from '../store';
import {
  NotificationManagement,
  NotificationmanagementService,
} from '../_services/notificationmanagement/notificationmanagement.service';
import { GetNotificationManagement } from '../store/stores/notificationmanagement/notificationmanagement.actions';
import { getNotificationManagement } from '../store/stores/notificationmanagement/notificationmanagement.store';
import { Subject } from 'rxjs';
import { APP_DI_CONFIG } from 'src/app/app-config.modules';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
})
export class NotificationComponent implements OnInit {
  notifications: NotificationManagement[] = [];
  notification: NotificationManagement = <NotificationManagement>{};
  display: boolean = false;
  text: any;
  val: boolean = true;
  inactive: boolean = false;
  active: boolean = true;
  popupStatus: boolean = true;
  files: File[];
  fileName: any;
  displayFile: boolean = false;
  filePath: any;
  private readonly destroy = new Subject<void>();

  constructor(
    private store: Store<State>,
    private notificationmanagementService: NotificationmanagementService
  ) {}

  ngOnInit(): void {
    this.fileName = 'Select Your File';

    this.loadNotificarionsData();
  }

  loadNotificarionsData() {
    this.store.dispatch(new GetNotificationManagement());
    this.store.select(getNotificationManagement).subscribe((data) => {
      this.notifications = data;
      this.notifications = [...this.notifications.filter((fl) => fl.status === true) ];

    });
  }
  showDialog(id: number) {
    this.notification = { ...this.notifications.find((fl) => fl.id === id) };
    this.display = true;
  }
  showDialog2(id: number) {
    this.notification = { ...this.notifications.find((fl) => fl.id === id) };
    this.filePath =
      APP_DI_CONFIG.parentDomain +
      APP_DI_CONFIG.apiEndPoint +
      APP_DI_CONFIG.endPoints.Notificationmanagement.fileDownload +
      '?fileName=' +
      this.notification.uploadedFile;
    this.displayFile = true;
  }
  download(filename: any) {
    this.filePath =
    APP_DI_CONFIG.parentDomain +
    APP_DI_CONFIG.apiEndPoint +
    APP_DI_CONFIG.endPoints.Notificationmanagement.fileDownload +
    '?fileName=' +
    filename;
    window.open(this.filePath, '_blank');
  }
}
