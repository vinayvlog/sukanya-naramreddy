import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValueSettingsComponent } from './value-settings.component';

describe('ValueSettingsComponent', () => {
  let component: ValueSettingsComponent;
  let fixture: ComponentFixture<ValueSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValueSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValueSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
