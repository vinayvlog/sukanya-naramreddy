import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { errormanagement, eventguide, organisation } from '../_models';
import { ErrormessagemngmtService } from '../_services/errormessagemngmt.service';
import { EventGuideService } from '../_services/eventguide.service';
import { Valuesettings } from '../_services/valuesettings.service';
import { State, Store } from '../store';
import { UpdateValuesettings } from '../store/stores/valuesettings/valuesettings.actions';
import { getValuesettingUpdated } from '../store/stores/valuesettings/valuesettings.store';
import { OrganisationService } from '../_services/organisation.service';

@Component({
  selector: 'app-value-settings',
  templateUrl: './value-settings.component.html',
  styleUrls: ['./value-settings.component.scss'],
})
export class ValueSettingsComponent implements OnInit {
  valuesList: Valuesettings[] = [];
  errormsgAll: any;
  errormsgs: errormanagement[] = [];
  allvaluesList: any;
  modelDisplay: boolean = false;
  valuesettings: Valuesettings = <Valuesettings>{};
  organizationTypeId: any;
  eventTypeId: any;
  eventguides: eventguide[] = [];
  eventTypes: any;
  orgData: organisation[] = [];
  orgTypes: any = [];
  private readonly destroy = new Subject<void>();
  constructor(
    private store: Store<State>,
    private eventGuideService: EventGuideService,
    private errorservice: ErrormessagemngmtService,
    private eventservService: EventGuideService,
    private orgService: OrganisationService
  ) {}
  ngOnInit(): void {
    this.eventTypeId = 0
    this.organizationTypeId =0
    this.getValuesList();
    this.loadErrors();
    this.loadEvents();
    this.loadOrganisation();
  }
  loadOrganisation() {
    this.orgService.getcodeWithGroup(7).then((result) => {
      this.orgTypes = result;
      this.orgTypes = this.orgTypes.filter((item)=>item.status)
      
    });
  }
  loadErrors() {
    this.errorservice.getErrData().then((result) => {
      this.errormsgAll = result;
      this.errormsgs = this.errormsgAll.errorMessageResponses;
      this.errormsgs = this.errormsgs.filter((item)=>item.status===true)
    });
  }
  getValuesList() {
    console.log("organizationTypeId",this.organizationTypeId)
    var params = {
      pageNo: 1,
      pageSize: 1000,
      organizationTypeId: this.organizationTypeId,
      eventTypeId: this.eventTypeId,
    };
    this.eventGuideService.getvalueSettingsData(params).then((result) => {
      this.allvaluesList = result;
      this.valuesList = this.allvaluesList.sysMenuValidationResponses;
    });
  }
  showDialog(id: number) {
    this.valuesettings = { ...this.valuesList.find((f1) => f1.id === id) };
    this.modelDisplay = true;
  }
  save() {
    this.store.dispatch(new UpdateValuesettings(this.valuesettings));

    this.store.select(getValuesettingUpdated).subscribe((updated) => {
      if (updated) {
        this.modelDisplay = false;
        this.getValuesList();
      }
    });
  }
  loadEvents() {
    this.orgService.getcodeWithGroup(8).then((result) => {
      this.eventTypes = result;
      
    });
  }
}
