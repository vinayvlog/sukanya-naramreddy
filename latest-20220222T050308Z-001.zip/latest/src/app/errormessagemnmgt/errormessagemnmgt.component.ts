import { Component, OnInit } from '@angular/core';
import { errormanagement } from './../_models/index';
import { ErrormessagemngmtService } from './../_services/errormessagemngmt.service';
import { SortEvent } from 'primeng/api';
import { DialogModule } from 'primeng/dialog';
import { RadioButtonModule } from 'primeng/radiobutton';

@Component({
  selector: 'app-errormessagemnmgt',
  templateUrl: './errormessagemnmgt.component.html',
  styleUrls: ['./errormessagemnmgt.component.scss'],
})
export class ErrormessagemnmgtComponent implements OnInit {
  errormsgAll: any;
  errormsgs: errormanagement[] = [];
  errormsg: errormanagement = <errormanagement>{};
  display: boolean = false;

  propagateChange = (_: any) => {};
  propagateTouched = () => {};
  registerOnChange(fn: (_: any) => void): void {
    this.propagateChange = fn;
  }
  constructor(private errorservice: ErrormessagemngmtService) {}

  ngOnInit(): void {
    this.loadErrors();
  }
  loadErrors() {
    this.errorservice.getErrData().then((result) => {
      this.errormsgAll = result;
      this.errormsgs = this.errormsgAll.errorMessageResponses;
    });
  }
  showDialog(id: number) {
    if (id > 0) {
      this.errormsg = this.errormsgs.find((fl) => fl.id === id);
    } else {
      this.errormsg.id = 0;
      this.errormsg.content = '';
      this.errormsg.title = '';
      this.errormsg.status = true;
    }
    this.display = true;
  }
  async saveerror(error: errormanagement) {
    if (error.title == '') {
      alert('Error title Required');
      return;
    } else if (error.content == '') {
      alert('Error content Required');
      return;
    }

    if (error.id > 0) {
      //update
      await this.errorservice.updateErrorData(error);
      this.display = false;
      this.loadErrors();
    } else {
      //save
      await this.errorservice.saveErrorData(error);
      this.display = false;
      this.loadErrors();
    }
  }
  close() {
    this.loadErrors();
  }

  onTextChanged(event) {
    this.propagateChange(event.htmlValue);
  }
}
