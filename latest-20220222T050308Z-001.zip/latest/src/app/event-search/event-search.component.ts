import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { conference, organisation } from '../_models';
import { OrganisationService } from '../_services/organisation.service';
import { State, Store } from '../store';
import { Product } from '../_services/products/product.service';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import { ConferenceService } from '../_services/conference.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { EventGuideService } from '../_services/eventguide.service';
import {
  HttpClient,
  HttpEventType,
  HttpErrorResponse,
} from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { APP_DI_CONFIG } from '../app-config.modules';
@Component({
  selector: 'app-event-search',
  templateUrl: './event-search.component.html',
  styleUrls: ['./event-search.component.scss']
})
export class EventSearchComponent implements OnInit {

  products: Product[] = [];
  orgId: number = 0;
  buId: number = 15;
  orgData: organisation[] = [];
  codeGroups: any = [];
  cities: any = [];
  guidelines: any = [];
  productId: number = 0;
  getAllConference: any = [];
  conferences: conference[] = [];
  conference: conference = <conference>{};
  startDate: any =new Date();
  displayRegister: boolean = false;
  displayAttachment: boolean = false;
  progress: number;
  selectedId: any;
  today: any = new Date();
  selectedOrg: any;
  filteredOrgs: any = [];
  selectedProdcucts: any = [];
  keyword = 'name';
  thisDate:boolean=true;

  @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;
  files: any[] = [];
  constructor(
    private orgService: OrganisationService,
    private store: Store<State>,
    private conferenceService: ConferenceService,
    private router: Router,
    public datepipe: DatePipe,
    private eventGuideService: EventGuideService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.today = this.datepipe.transform(this.today, 'yyyy-MM-dd');
    this.startDate =this.today
    this.loadCOnferenceData();
    this.loadOrganisation();
    this.loadcodeWithGroup();
    this.loadProductsData();
    this.loadcodeWithCities();
    this.loadcodeWithGuildelines();
  }
  loadCOnferenceData() {
    let obj = {
      pageNo: 1,
      pageSize: 1000,
    };
    this.conferenceService.getConferenceData(obj).then((result) => {
      this.getAllConference = result;
      this.conferences = this.getAllConference.conferences;
    });
  }
  loadOrganisation() {
    this.orgService.getOrgData().then((result) => {
      this.orgData = result;
    });
  }
  loadcodeWithGroup() {
    this.orgService.getcodeWithGroup(11).then((result) => {
      this.codeGroups = result; 
      this.codeGroups = this.codeGroups.filter((item)=>item.status == true)
      
    });
  }
  loadcodeWithCities() {
    this.orgService.getcodeWithGroup(9).then((result) => {
      this.cities = result;
    });
  }
  loadcodeWithGuildelines() {
    this.eventGuideService.geteventData().then((result) => {
      this.guidelines = result;
    });
  }
  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
      this.products = this.products.filter((item)=>item.status == true)

    });
  }
  getDetailsPage(id: any) {
    this.router.navigateByUrl('/home/event-search/' + id);
  }
  register() {
    this.displayRegister = true;
    this.conference.organizationId = this.orgId;
    this.conference.cityId = 0;
  }
  showAttachementModel(id: any) {
    this.displayAttachment = true;
    this.selectedId = id;
  }
  search() {
    let obj = {};
    let ProductIds = [];
    let BUIds = [];
    if (this.selectedProdcucts.length > 0) {
      this.selectedProdcucts.forEach((item) => {
        ProductIds.push(item.id);
      });
    }
    if (this.buId > 0) {
      BUIds.push(this.buId);
    }
    obj = {
      organizationId: this.orgId,
      confrenceDate: this.startDate,
      ProductIds: ProductIds,
      BUIds: BUIds,
      pageNo: 1,
      pageSize: 1000,
      TodaysDate:this.thisDate
    };
    this.conferenceService.getConferenceData(obj).then((result) => {
      this.getAllConference = result;
      this.conferences = this.getAllConference.conferences;
    });
  
  }
  saveConference() {
    if (
      !this.conference.conferenceName ||
      this.conference.conferenceName == ''
    ) {
      alert('Enter Conference Name');
    } else if (!this.conference.venue || this.conference.venue == '') {
      alert('Enter Place');
    } else if (this.conference.cityId === 0) {
      alert('Select City');
    } else if (!this.conference.startDate) {
      alert('Select Start Date');
    } else if (!this.conference.endDate) {
      alert('Select End Date');
    } else if (this.conference.noOfPeople === 0) {
      alert('Enter No. of Attendees');
    } else if (!this.conference.time) {
      alert('Enter No. of Minutes');
    } else {
      this.conference.startDate = this.datepipe.transform(
        this.conference.startDate,
        'yyyy-MM-dd'
      );
      this.conference.endDate = this.datepipe.transform(
        this.conference.endDate,
        'yyyy-MM-dd'
      );
      this.conference.organizationId = parseInt(this.conference.organizationId);
      this.conferenceService
        .saveConferenceData(this.conference)
        .then((data) => {
          if (this.files.length > 0) {
            this.selectedId = data.id;
            this.uploadFile();
          }
          this.loadCOnferenceData();
          this.displayRegister = false;
        })
        .catch((error) => {});
    }
  }
  onFileDropped($event) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile(index: number) {
    this.files = [];
  }

  /**
   * Simulate the upload process
   */
  uploadFile() {
    this.progress = 10;
    const formData = new FormData();
    formData.append('file', this.files[0]);

    this.http
      .put(
        APP_DI_CONFIG.parentDomain +
          APP_DI_CONFIG.apiEndPoint +
          APP_DI_CONFIG.endPoints.contenferance.uploadFileConference +
          '?id=' +
          this.selectedId,
        formData,
        {
          reportProgress: true,
          observe: 'events',
        }
      )
      .pipe(
        map((event: any) => {
          if (event.type == HttpEventType.UploadProgress) {
            this.progress = Math.round((100 / event.total) * event.loaded);
          } else if (event.type == HttpEventType.Response) {
            this.loadCOnferenceData();
            this.files = [];
            this.progress = null;
            this.displayAttachment = false;
          }
        }),
        catchError((err: any) => {
          alert(err.message);
          return throwError(err.message);
        })
      )
      .toPromise();
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      item.progress = 0;

      this.files[0] = item;
    }
    this.fileDropEl.nativeElement.value = '';
    //  this.uploadFilesSimulator(0);
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  filterOrgs(event) {
    //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    let filtered: any[] = [];
    let query = event.query;
    for (let i = 0; i < this.orgData.length; i++) {
      let org = this.orgData[i];
      if (
        org.organizationName.toLowerCase().indexOf(query.toLowerCase()) == 0
      ) {
        filtered.push(org);
      }
    }

    this.filteredOrgs = filtered;
  }
  selectEvent(item) {
    // do something with selected item
  }

  onChangeSearch(search: string) {
    // fetch remote data from here
    // And reassign the 'data' which is binded to 'data' property.
  }

  onFocused(e) {
    // do something
  }
  onSelect(event: any) {
    this.orgId = event.id;
  }
  download(filename: any) {
    const path =
      APP_DI_CONFIG.parentDomain +
      APP_DI_CONFIG.apiEndPoint +
      APP_DI_CONFIG.endPoints.contenferance.confereceFileDownload +
      '?fileName=' +
      filename;
    window.open(path, '_blank');
  }

}
