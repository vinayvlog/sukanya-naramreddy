import { MenuItem } from 'primeng/api';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { State, Store } from '../store';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import {
  addCR,
  Advertisement,
  Banner,
  bannerCR,
  Booth,
  boothCR,
  conference,
  conferenceCR,
} from '../_models';
import { ConferenceService } from '../_services/conference.service';
import { EventGuideService } from '../_services/eventguide.service';
import { OrganisationService } from '../_services/organisation.service';
import { Product } from '../_services/products/product.service';
import { User, UserService } from '../_services/users/user.service';
import { catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { APP_DI_CONFIG } from '../app-config.modules';

export interface Car {
  existingdata;
  newdata;
  guidelines;
}
@Component({
  selector: 'app-cr-view',
  templateUrl: './cr-view.component.html',
  styleUrls: ['./cr-view.component.scss'],
})
export class CrViewComponent implements OnInit {
  displayBasic: boolean;
  collapsed = false;
  cars = [{}];
  conference: any = {};
  conferencenew: conferenceCR = <conferenceCR>{};
  boothnew: boothCR = <boothCR>{};
  bannernew: bannerCR = <bannerCR>{};
  advertisementnew: addCR = <addCR>{};
  guidelines: any = [];
  products: Product[] = [];
  displayBooth: boolean = false;
  displayBanner: boolean = false;
  displayAdd: boolean = false;
  isSaveBtn: boolean = false;
  displayDelete: boolean = false;
  booth: Booth = <Booth>{};
  banner: Banner = <Banner>{};
  advertisement: addCR = <addCR>{};
  verifedData: any = [];
  usersAll: any;
  addTypes: any = [];
  users: User[] = [];
  today: any = new Date();
  displayRegister: boolean = false;
  progress: number;
  cities: any = [];
  displayViewBooth: boolean = false;
  displayViewBanner: boolean = false;
  displayViewAdd: boolean = false;
  displayRemarksTable: boolean = false;
  displayErrorModel: boolean = false;
  filePath: any;
  selectedcategory: any;
  errorData: any = [];
  @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;
  files: any[] = [];
  orgData: any[] = [];
  table1Data: any = [];
  table2Data: any = [];
  remarksData: any;
  reason: any;
  constructor(
    private route: ActivatedRoute,
    private conferenceService: ConferenceService,
    private orgService: OrganisationService,
    private store: Store<State>,
    private router: Router,
    public datepipe: DatePipe,
    private userService: UserService,
    private http: HttpClient,
    private eventGuideService: EventGuideService
  ) {}
  onClick(event: Event, menu) {
    menu.toggle(event);
    event.stopPropagation();
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.conferenceService.getConferenceCRForView(id).then((data) => {
      this.conference = data;
      this.loadcodeWithGuildelines();
      this.loadProductsData();
      this.loadUsersData();
      this.loadAddTypes();
      this.loadcodeWithCities();
      this.loadOrganisation();
      this.conferencenew.crOrganizationId = 0;
      this.conferencenew.crCityId = 0;
    });
  }
  showBasicDialog() {
    this.displayBasic = true;
  }

  close() {
    // this.loadOrganisation();
  }
  showComentsBoth(data) {
    this.table1Data = [];
    this.table2Data = [];
    this.remarksData = data;
    var obj1 = {
      requester: data.newBooth.registeredBy,
      date: data.newBooth.createdDate,
      remarks: data.remark,
    };
    this.table1Data.push(obj1);
    var obj2 = {
      event: data.newBooth.conferenceName,
      type: data.typeName,
      approver: data.newBooth.approvedBy,
      status: data.statusName,
      date: data.newBooth.updatedDate,
      remarks: data.approverRemark,
    };
    this.table2Data.push(obj2);
    this.displayRemarksTable = true;
  }
  showComentsBanner(data) {
    this.table1Data = [];
    this.table2Data = [];
    this.remarksData = data;
    var obj1 = {
      requester: data.newBanner.registeredBy,
      date: data.newBanner.createdDate,
      remarks: data.remark,
    };
    this.table1Data.push(obj1);
    var obj2 = {
      event: data.newBanner.conferenceName,
      type: data.typeName,
      approver: data.newBanner.approvedBy,
      status: data.statusName,
      date: data.newBanner.updatedDate,
      remarks: data.approverRemark,
    };
    this.table2Data.push(obj2);
    this.displayRemarksTable = true;
  }
  showComentsAdd(data) {
    this.table1Data = [];
    this.table2Data = [];
    this.remarksData = data;
    var obj1 = {
      requester: data.newAdvertisement.registeredBy,
      date: data.newAdvertisement.createdDate,
      remarks: data.remark,
    };
    this.table1Data.push(obj1);
    var obj2 = {
      event: data.newAdvertisement.conferenceName,
      type: data.typeName,
      approver: data.newAdvertisement.approvedBy,
      status: data.statusName,
      date: data.newAdvertisement.updatedDate,
      remarks: data.approverRemark,
    };
    this.table2Data.push(obj2);
    this.displayRemarksTable = true;
  }
  showComents(data) {
    this.remarksData = data;
    var obj1 = {
      requester: 'John',
      date: '',
      remarks: 'Teast remarks by requester',
    };
    this.table1Data.push(obj1);
    var obj2 = {
      event: 'Main Event',
      type: 'new',
      approver: 'PM',
      status: 'Submitted',
      date: '',
      remarks: 'Teast remarks by requester',
    };
    this.table2Data.push(obj2);
    this.displayRemarksTable = true;
  }
  loadOrganisation() {
    this.orgService.getOrgData().then((result) => {
      this.orgData = result;
    });
  }
  loadConferenceData() {
    const id = this.route.snapshot.paramMap.get('id');
    this.conferenceService.getCRConferenceDetails(id).then((data) => {
      this.conference = data;
    });
  }
  loadcodeWithCities() {
    this.orgService.getcodeWithGroup(9).then((result) => {
      this.cities = result;
    });
  }
  loadAddTypes() {
    this.conferenceService.getAddTypesData().then((data) => {
      this.addTypes = data;
    });
  }
  loadUsersData() {
    this.conferenceService.getUserData().then((data) => {
      this.usersAll = data;
      this.users = this.usersAll.users;
    });
  }

  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
    });
  }
  loadcodeWithGuildelines() {
    this.eventGuideService.geteventData().then((result) => {
      this.guidelines = result;
    });
  }

  onFileDropped($event) {
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(files) {
    this.prepareFilesList(files);
  }

  /**
   * Delete file from files list
   * @param index (File index)
   */
  deleteFile(index: number) {
    this.files = [];
  }

  /**
   * Simulate the upload process
   */
  uploadFile(type: any, id) {
    this.progress = 10;
    const formData = new FormData();
    formData.append('file', this.files[0]);
    let path = '';
    if (type == 'conference') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadFileConference +
        '?id=' +
        id;
    } else if (type == 'booth') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadBoothFile +
        '?id=' +
        id;
    } else if (type == 'banner') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadBannerFile +
        '?id=' +
        id;
    } else if (type == 'add') {
      path =
        APP_DI_CONFIG.parentDomain +
        APP_DI_CONFIG.apiEndPoint +
        APP_DI_CONFIG.endPoints.contenferance.uploadAdvertisementFile +
        '?id=' +
        id;
    }

    this.http
      .put(path, formData, {
        reportProgress: true,
        observe: 'events',
      })
      .pipe(
        map((event: any) => {
          if (event.type == HttpEventType.UploadProgress) {
            this.progress = Math.round((100 / event.total) * event.loaded);
          } else if (event.type == HttpEventType.Response) {
            this.files = [];
            this.progress = null;
          }
        }),
        catchError((err: any) => {
          alert(err.message);
          return throwError(err.message);
        })
      )
      .toPromise();
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      item.progress = 0;

      this.files[0] = item;
    }
    this.fileDropEl.nativeElement.value = '';
    //  this.uploadFilesSimulator(0);
  }

  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  boothModel() {
    this.conferenceService
      .validateBoothCreation(this.conference.id)
      .then((data) => {
        this.errorData = data;
        if (this.errorData.length > 0 && this.conference.booths.length > 0) {
          this.displayErrorModel = true;
        } else {
          this.displayBooth = true;
          this.booth.id = 0;
          this.booth.productId = 0;
          this.booth.userId = 0;
        }
      });
  }
  bannerModel() {
    if (this.conference.banners.length > 0) {
      this.displayBanner = true;
      this.banner.productId = 0;
      this.banner.userId = 0;
      this.banner.id = 0;
    }
    this.displayBanner = true;
    this.banner.productId = 0;
    this.banner.userId = 0;
    this.banner.id = 0;
  }
  addModel() {
    if (this.conference.advertisements.length > 0) {
      this.displayAdd = true;
      this.advertisement.id = 0;
      this.advertisement.productId = 0;
      this.advertisement.userId = 0;
      this.advertisement.adTypeId = 0;
    }
  }
  saveBooth() {
    this.booth.conferenceId = this.route.snapshot.paramMap.get('id');
    if (this.booth.id > 0) {
      if (this.booth.actualAmount == 0) {
        alert('Enster Actual Amount');
      } else if (!this.booth.actualPaymentDate) {
        alert('Select Actual Pay Date');
      } else if (!this.booth.ePay) {
        alert('Enster E-pay code');
      } else {
        this.updateBoothData();
      }
    } else {
      if (this.booth.productId == 0) {
        alert('Select a Product');
      } else if (!this.booth.expectedAmount) {
        alert('Enter Expected Amount');
      } else if (!this.booth.expectedPaymentDate) {
        alert('Select Expected Pay Date');
      } else if (this.booth.userId === 0) {
        alert('Select PM User');
      } else {
        this.saveBoothData();
      }
    }
  }
  saveBoothData() {
    this.conferenceService.validateBooth(this.booth).then((data) => {
      this.errorData = data;
      if (this.errorData > 0) {
        this.displayErrorModel = true;
      } else {
        this.conferenceService.createBoothCR(this.booth).then((data) => {
          if (this.files.length > 0) {
            this.uploadFile('booth', data.id);
          }
          this.loadConferenceData();
          this.displayBooth = false;
        });
      }
    });
  }
  updateBoothData() {
    this.conferenceService.updateBoothData(this.booth).then((data) => {
      this.displayBooth = false;
      if (this.files.length > 0) {
        this.uploadFile('booth', this.booth.id);
      }
      this.loadConferenceData();
    });
  }
  verify() {
    this.conferenceService.validateBanner(this.banner).then((data) => {
      this.verifedData = data;
      const arrayLength = this.verifedData.filter(
        (item) => !item.result
      ).length;
      if (arrayLength > 0) {
        this.isSaveBtn = false;
      } else {
        this.isSaveBtn = true;
      }
    });
  }
  saveBanner() {
    this.banner.conferenceId = this.route.snapshot.paramMap.get('id');
    if (this.banner.id > 0) {
      if (this.banner.actualAmount == 0) {
        alert('Enster Actual Amount');
      } else if (!this.banner.actualPaymentDate) {
        alert('Select Actual Pay Date');
      } else if (!this.banner.ePay) {
        alert('Enster E-pay code');
      } else {
        this.updateBannerData();
      }
    } else {
      if (this.banner.productId == 0) {
        alert('Select a Product');
      } else if (!this.banner.urlOfSite) {
        alert('Enter URL of site');
      } else if (!this.banner.startDate) {
        alert('Select Start Date');
      } else if (!this.banner.endDate) {
        alert('Select End Date');
      } else if (!this.banner.expectedPaymentDate) {
        alert('Select Expected Pay Date');
      } else if (!this.banner.expectedAmount) {
        alert('Enter Expected Amount');
      } else if (this.banner.userId === 0) {
        alert('Select PM User');
      } else {
        this.saveBannerData();
      }
    }
  }
  saveBannerData() {
    this.banner['crId'] = this.conference.conferenceDetail.crId;
    this.conferenceService.createBannerCR(this.banner).then((data) => {
      if (this.files.length > 0) {
        this.uploadFile('banner', data.id);
      }
      this.loadConferenceData();
      this.displayBanner = false;
    });
  }
  updateBannerData() {
    this.conferenceService.updateBannerData(this.banner).then((data) => {
      this.displayBanner = false;
      if (this.files.length > 0) {
        this.uploadFile('banner', this.banner.id);
      }
      this.loadConferenceData();
    });
  }

  saveAdd() {
    // this.advertisement.crConferenceId = this.route.snapshot.paramMap.get('id');
    if (this.advertisement.id > 0) {
      if (this.advertisement.actualAmount == 0) {
        alert('Enster Actual Amount');
      } else if (!this.advertisement.actualPaymentDate) {
        alert('Select Actual Pay Date');
      } else if (!this.advertisement.ePayCode) {
        alert('Enster E-pay code');
      } else {
        this.updateAddData();
      }
    } else {
      this.advertisement.ePayCode = 'NA';
      if (this.advertisement.productId == 0) {
        alert('Select a Product');
      } else if (!this.advertisement.expectedAmount) {
        alert('Enter Expected Amount');
      } else if (!this.advertisement.expectedPaymentDate) {
        alert('Select Expected Pay Date');
      } else if (this.advertisement.userId === 0) {
        alert('Select PM User');
      } else {
        this.saveAddData();
      }
    }
  }
  saveAddData() {
    this.conferenceService.createaddCR(this.advertisement).then((data) => {
      if (this.files.length > 0) {
        this.uploadFile('add', data.id);
      }
      this.loadConferenceData();
      this.displayAdd = false;
    });
  }
  updateAddData() {
    this.conferenceService.updateaddCR(this.advertisement).then((data) => {
      this.displayAdd = false;
      if (this.files.length > 0) {
        this.uploadFile('add', this.advertisement.id);
      }
      this.loadConferenceData();
    });
  }
  cancel() {
    this.displayDelete = false;
  }
  deleteAdd() {
    let obj = {
      id: this.advertisement.id,
      deleteComment: this.reason,
    };
    this.conferenceService.deleteAdd(obj).then((data) => {
      this.displayDelete = false;
      this.displayAdd = false;
    });
  }
  approveBanner(id) {
    let params = {
      id: id,
      approverRemark: this.reason,
    };
    this.conferenceService.approveCRBanner(params).then((data) => {});
  }
  rejectBanner() {}
  aapproveBooth(id) {
    let params = {
      id: id,
      approverRemark: this.reason,
    };
    this.conferenceService.aapproveCRBooth(params).then((data) => {});
  }
  rejecteBooth() {}
  approveAdd(id) {
    let params = {
      id: id,
      approverRemark: this.reason,
    };
    this.conferenceService.approveCRAdd(params).then((data) => {});
  }
  rejectAdd() {}
  deleteModel() {
    this.displayDelete = true;
  }
  submittCR() {
    this.conferenceService
      .submittCR(this.conference.conferenceDetail.crId)
      .then((data) => {
        this.router.navigateByUrl('/home/changerequestview');
      });
  }
  saveConference(data) {
    this.conferenceService.updateConferenceCR(data).then((data) => {
      this.loadConferenceData();
    });
  }
  saveBootCR(data) {
    this.conferenceService.updateBoothCR(data).then((data) => {
      this.loadConferenceData();
    });
  }
  saveBannerCR(data) {
    this.conferenceService.updateBannerCR(data).then((data) => {
      this.loadConferenceData();
    });
  }
  saveAddCR() {
    this.conferenceService.updateaddCR(this.advertisementnew).then((data) => {
      this.loadConferenceData();
    });
  }
}
