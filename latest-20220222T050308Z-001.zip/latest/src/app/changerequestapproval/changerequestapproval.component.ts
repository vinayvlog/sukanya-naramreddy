import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { State, Store } from '../store';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import { Advertisement, Banner, Booth, conference } from '../_models';
import { ConferenceService } from '../_services/conference.service';
import { EventGuideService } from '../_services/eventguide.service';
import { OrganisationService } from '../_services/organisation.service';
import { Product } from '../_services/products/product.service';
import { User, UserService } from '../_services/users/user.service';

@Component({
  selector: 'app-changerequestapproval',
  templateUrl: './changerequestapproval.component.html',
  styleUrls: ['./changerequestapproval.component.scss'],
})
export class ChangeRequestApproval implements OnInit {
  conference: conference = <conference>{};
  conferences: any[] = [];
  guidelines: any = [];
  products: Product[] = [];
  displayBooth: boolean = false;
  displayBanner: boolean = false;
  displayAdd: boolean = false;
  displayDelete: boolean = false;
  booth: Booth = <Booth>{};
  banner: Banner = <Banner>{};
  advertisement: Advertisement = <Advertisement>{};
  verifedData: any = [];
  usersAll: any;
  addTypes: any = [];
  users: User[] = [];
  today: any = new Date();
  displayRegister: boolean = false;
  progress: number;
  cities: any = [];
  displayViewBooth: boolean = false;
  displayViewBanner: boolean = false;
  displayViewAdd: boolean = false;
  filePath: any;
  selectedcategory: any;
  @ViewChild('fileDropRef', { static: false }) fileDropEl: ElementRef;
  files: any[] = [];
  reason: any;
  constructor(
    private route: ActivatedRoute,
    private conferenceService: ConferenceService,
    private orgService: OrganisationService,
    private store: Store<State>,
    private router: Router,
    public datepipe: DatePipe,
    private userService: UserService,
    private http: HttpClient,
    private eventGuideService: EventGuideService
  ) {}

  ngOnInit(): void {
   this.loadConferenceData()
  }
  loadConferenceData() {
    let obj = {
      PageNo:1,
      PageSize:1000
    }
    this.conferenceService.crListForApprove(obj).then((data) => {
      this.usersAll = data;
      this.conferences =  this.usersAll.conferences
    });
  }
  loadcodeWithCities() {
    this.orgService.getcodeWithGroup(9).then((result) => {
      this.cities = result;
    });
  }
  loadAddTypes() {
    this.conferenceService.getAddTypesData().then((data) => {
      this.addTypes = data;
    });
  }
  loadUsersData() {
    this.conferenceService.getUserData().then((data) => {
      this.usersAll = data;
      this.users = this.usersAll.users;
    });
  }

  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
    });
  }
  loadcodeWithGuildelines() {
    this.eventGuideService.geteventData().then((result) => {
      this.guidelines = result;
    });
  }
}
