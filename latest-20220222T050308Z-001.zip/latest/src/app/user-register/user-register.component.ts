import { Component, OnInit } from '@angular/core';
import { User } from '../_services/users/user.service';
import { State, Store } from '../store';
import { Role } from '../_services/roles/role.service';
import { OrganisationService } from '../_services/organisation.service';
import { getRoles } from '../store/stores/roles/roles.store';
import { GetRoles } from '../store/stores/roles/roles.actions';
import { CreateUser } from '../store/stores/users/users.actions';
import { getUserCreated } from '../store/stores/users/users.store';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';


@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.scss']
})
export class UserRegisterComponent implements OnInit {

  user:User = <User>{};
  groups:Role[] =[]
  codeGroups:any = []
  private readonly destroy = new Subject<void>();

  constructor(private store: Store<State>,
    private orgService: OrganisationService,
    private router:Router) { }

  ngOnInit(): void {
    this.user.roleId = 0;
    this.user.buId = 0;
    this.loadGroupsData();
    this.loadcodeWithGroup();
  }
  loadcodeWithGroup() {
    this.orgService.getcodeWithGroup(11).then((result) => {
      this.codeGroups = result;
    });
  }
  loadGroupsData() {
    this.store.dispatch(new GetRoles());
    this.store.select(getRoles).subscribe((data) => {
      this.groups = data;
    });
  }
  saveUser(){
    this.store.dispatch(new CreateUser(this.user));
    this.store
      .select(getUserCreated)
      .pipe(takeUntil(this.destroy))
      .subscribe((created) => {
        if (created) {
          this.router.navigateByUrl("/home/organisation")
        }
      });
  }
  
}
