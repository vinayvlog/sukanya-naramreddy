import { Component, OnInit } from '@angular/core';
import { conditionalSearchGet, organisation } from '../_models';
import { ConferenceService } from '../_services/conference.service';
import { OrganisationService } from '../_services/organisation.service';
import { State, Store } from '../store';
import { Product } from '../_services/products/product.service';
import { GetProducts } from '../store/stores/products/product.actions';
import { getProducts } from '../store/stores/products/product.store';
import { APP_DI_CONFIG } from '../app-config.modules';

@Component({
  selector: 'app-conditionalsearch',
  templateUrl: './conditionalsearch.component.html',
  styleUrls: ['./conditionalsearch.component.scss'],
})
export class ConditionalSearchComponent implements OnInit {
  selectedOrganizations: string[] = [];
  codeGroups: any[];
  searchTypes: any = [];
  dropdownData: conditionalSearchGet = <conditionalSearchGet>{};
  searchType: any;
  checked: boolean = false;
  pclass: any;
  startDate: any;
  endDate: any;
  selectedOrgs: any = [];
  orgData: organisation[] = [];
  conferenceData: any = [];
  selectedconferences: any = [];
  getAllConference: any;
  selectedProducts: any = [];
  products: Product[] = [];
  buId: number = 0;
  usersAll: any;
  eventCategory: any;
  users: any = [];
  selectedUsers: any = [];
  quarter: number = 1;
  constructor(
    private conferenceService: ConferenceService,
    private orgService: OrganisationService,
    private store: Store<State>
  ) {
    this.codeGroups = [
      { name: 'New York', code: 'NY' },
      { name: 'Rome', code: 'RM' },
      { name: 'London', code: 'LDN' },
      { name: 'Istanbul', code: 'IST' },
      { name: 'Paris', code: 'PRS' },
    ];
  }
  ngOnInit(): void {
    this.conferenceService.conditionalSearchGet().then((data) => {
      this.dropdownData = data;
      this.searchTypes = this.dropdownData.searchType;
      this.searchType = 'All';
    });
    this.loadOrganisation();
    this.loadCOnferenceData();
    this.loadProductsData();
    this.loadcodeWithGroup();
    this.loadUsersData();
  }
  loadOrganisation() {
    this.orgService.getOrgData().then((result) => {
      this.orgData = result;
      this.orgData = this.orgData.filter((item) => item.status);
    });
  }
  loadCOnferenceData() {
    let obj = {
      pageNo: 1,
      pageSize: 1000,
    };
    this.conferenceService.getConferenceData(obj).then((result) => {
      this.getAllConference = result;
      this.conferenceData = this.getAllConference.conferences;
    });
  }
  loadProductsData() {
    this.store.dispatch(new GetProducts());
    this.store.select(getProducts).subscribe((data) => {
      this.products = data;
      this.products = this.products.filter((item) => item.status == true);
    });
  }
  loadcodeWithGroup() {
    this.orgService.getcodeWithGroup(11).then((result) => {
      this.codeGroups = result;
      this.codeGroups = this.codeGroups.filter((item) => item.status == true);
      this.buId = this.codeGroups[0].id;
    });
  }
  loadUsersData() {
    this.conferenceService.getUserData().then((data) => {
      this.usersAll = data;
      this.users = this.usersAll.users;
      // this.users.sort((one, two) => (one > two ? -1 : 1));
    });
  }
  resetValues() {
    this.selectedOrganizations = [];
    this.selectedProducts = [];
    this.selectedUsers = [];
    this.selectedconferences = [];
    this.selectedOrgs = [];
    this.eventCategory = '';
    this.startDate = null;
    this.endDate = null;
  }
  quator1() {
    this.quarter = 1;
  }
  quator2() {
    this.quarter = 2;
  }
  quator3() {
    this.quarter = 3;
  }
  quator4() {
    this.quarter = 4;
  }
  export() {
    const ret = [];
    var params = {
      endDate: this.endDate,
      startDate: this.startDate,
      quarter: this.quarter,
      Value: this.eventCategory,
      SearctType: this.searchType,
    };
    var data = this.dropdownData.checkBoxes.filter((item) => item.checked);
    data.forEach((item) => {
      // params.SearctBoxValues.push(item.value);
      ret.push(
        encodeURIComponent('SearctBoxValues') +
          '=' +
          encodeURIComponent(item.value)
      );
    });
    if (this.selectedOrgs.length > 0) {
      this.selectedOrgs.forEach((item) => {
        // params.Ids.push(item.id);
        ret.push(
          encodeURIComponent('Ids') +
            '=' +
            encodeURIComponent(item.id.toString())
        );
      });
    } else if (this.selectedUsers.length > 0) {
      this.selectedUsers.forEach((item) => {
        //  params.Ids.push(item.id);
        ret.push(
          encodeURIComponent('Ids') +
            '=' +
            encodeURIComponent(item.id.toString())
        );
      });
    } else if (this.selectedProducts.length > 0) {
      this.selectedProducts.forEach((item) => {
        // params.Ids.push(item.id);
        ret.push(
          encodeURIComponent('Ids') +
            '=' +
            encodeURIComponent(item.id.toString())
        );
      });
    } else {
      //  delete params['Ids'];
    }
    for (const key in params) {
      if (params[key] === null || params[key] === undefined) {
        delete params[key];
      }
    }
    const url = this.encodeQueryData(params) + '&' + ret.join('&');
    const path =
      APP_DI_CONFIG.parentDomain +
      APP_DI_CONFIG.apiEndPoint +
      APP_DI_CONFIG.endPoints.contenferance.conditionalSearch +
      '?' +
      url;

    window.open(path, '_blank');
  }
  encodeQueryData(data) {
    const ret = [];
    for (let d in data)
      ret.push(encodeURIComponent(d) + '=' + encodeURIComponent(data[d]));
    return ret.join('&');
  }
  selectAll(){
    if(this.checked){
    this.dropdownData.checkBoxes.forEach((item)=>{
      item.checked =true
    })
    }else{
      this.dropdownData.checkBoxes.forEach((item)=>{
        item.checked =false
      })
    }
  }
}
